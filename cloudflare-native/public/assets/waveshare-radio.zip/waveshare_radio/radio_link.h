#pragma once
#include <esp_random.h>

// HTTPS only. The credential is generated on the radio and never shown or logged.
String radioLinkId,radioLinkSecret,radioLinkPin,radioLinkMessage;
String radioRemoteId,radioRemoteCode,radioAckId,radioAckStatus,radioLastCommand,radioLastResult;
String radioPendingClaim,radioPendingCheck,radioPairDecision,radioPendingScope;
String radioControlId,radioControlAction,radioControlAck,radioControlAckStatus,radioLastControl,radioLastControlStatus,radioControlValidId;
bool radioControlNeedsValidation=false;
int radioControlValue=0;bool radioControlBoolean=false;uint32_t radioControlUntil=0,radioControlAckAt=0;
bool radioPhoneLinked=false,radioRemoteRunning=false,radioLinkResetConfirm=false;
bool radioLinkResetPending=false,radioStableCodeRegistered=false;
uint32_t radioLinkPinUntil=0,radioLinkPollAt=0,radioLinkTaskAt=0,radioLinkIdentityAttemptAt=0;
uint32_t radioRemoteUntil=0;
uint32_t radioLinkCodeAttemptAt=0;
int radioDeviceCodeDigits=4;
int radioLinkRequestedMode=0;
QueueHandle_t radioLinkResults=nullptr;
TaskHandle_t radioLinkTask=nullptr;
StationJsonAllocator radioLinkAllocator;
struct RadioLinkJob {
 String id,secret,ack,status,claim,decision,pin,playingCode;int mode;
 String controlAck,controlStatus,pairScope,currentCode;int volume=0;bool muted=false;
 String savedCodes[MAX_STATIONS];int savedCodeCount=0;bool inventoryComplete=false;
};
// Capture on the UI task after persistent station updates. The network worker
// receives an immutable complete snapshot, including a genuinely empty list.
void snapshotRadioSavedStations(RadioLinkJob& job) {
 if(stationCount<0 || stationCount>MAX_STATIONS)return;
 for(int i=0;i<stationCount;++i)if(validListenerCode(stationCodes[i].c_str())) {
  job.savedCodes[job.savedCodeCount]=stationCodes[i];
  if(job.savedCodes[job.savedCodeCount]!=stationCodes[i])return;
  ++job.savedCodeCount;
 }
 job.inventoryComplete=true;
}
String radioUsageCode;
bool radioUsageTracking=false;
uint32_t radioUsageSince=0;
bool monthlyPlaybackQualified() {
 return radioOn && !radioMuted && stationCount>0 && audioReady && !uiPaused && !safeRecoveryMode &&
        !stationPending && !portalActive && !voiceBusy() && WiFi.status()==WL_CONNECTED && audio.isRunning();
}
void updateMonthlyRadioUsage() {
 String code=stationCount>0?stationCodes[selected]:"";
 bool playing=monthlyPlaybackQualified() && validListenerCode(code.c_str());
 if(!playing || !radioUsageTracking || code!=radioUsageCode){
  radioUsageCode=code;radioUsageSince=millis();radioUsageTracking=playing;
 }
}
String monthlyRadioUsageCode() {
 return radioUsageTracking && monthlyPlaybackQualified() && uint32_t(millis()-radioUsageSince)>=60000?radioUsageCode:"";
}

bool radioLinkHex(const String& value,int length) {
 if(value.length()!=unsigned(length))return false;
 for(unsigned i=0;i<value.length();++i)if(!((value[i]>='0'&&value[i]<='9')||(value[i]>='a'&&value[i]<='f')))return false;
 return true;
}
String radioLinkRandom(int bytes) {
 String value;value.reserve(bytes*2);
 for(int i=0;i<bytes;++i){uint8_t b=uint8_t(esp_random());value+=char("0123456789abcdef"[b>>4]);value+=char("0123456789abcdef"[b&15]);}
 return value;
}
bool numericDeviceCode(const String& code) {
 if(code.length()<4 || code.length()>10)return false;
 for(unsigned i=0;i<code.length();++i)if(code[i]<'0'||code[i]>'9')return false;
 return true;
}
bool validRadioPairCode(const String& code) {
 if(numericDeviceCode(code))return true;
 if(code.length()!=8)return false;
 for(unsigned i=0;i<code.length();++i)if(!strchr("ABCDEFGHJKLMNPQRSTUVWXYZ23456789",code[i]))return false;
 return true;
}
String formattedDeviceCode() {
 return numericDeviceCode(radioLinkPin)?radioLinkPin:radioLinkPin.substring(0,4)+"-"+radioLinkPin.substring(4);
}
uint32_t radioCodeResetAfter=0;
bool radioCodeResetLocked() {
 return radioLinkResetPending || (radioCodeResetAfter && time(nullptr)<radioCodeResetAfter);
}
bool homeRadioLinkCodeLive() {
 return WiFi.status()==WL_CONNECTED && time(nullptr)>=1700000000 && !radioLinkResetPending &&
        validRadioPairCode(radioLinkPin) && radioStableCodeRegistered;
}
bool shouldRefreshHomeLinkCode() {
 if(!radioOn || portalActive || (uiPage!=6 && uiPage!=0) || WiFi.status()!=WL_CONNECTED || time(nullptr)<1700000000 ||
    radioLinkResetPending || radioPendingClaim.length() || radioPairDecision.length() || radioRemoteId.length())return false;
 if(radioStableCodeRegistered && homeRadioLinkCodeLive())return false;
 return !radioLinkCodeAttemptAt || millis()-radioLinkCodeAttemptAt>=60000;
}
String compactHomeLinkLabel() {
 if(radioPendingClaim.length())return "Approve phone";
 if(homeRadioLinkCodeLive())return formattedDeviceCode();
 return "";
}
void drawHomeRadioLinkCode() {
 screen.fillRoundRect(174,104,128,93,8,UI_PANEL);
 screen.drawRoundRect(174,104,128,93,8,UI_SKY);
 if(radioPendingClaim.length()) {
  uiText("Phone approval",196,110,1,UI_SKY);uiText(radioPendingCheck,190,134,4,UI_WHITE);
  uiText("Tap to approve",196,179,1,UI_MUTED);return;
 }
 uiText("Device Code",208,108,1,UI_SKY);
 if(homeRadioLinkCodeLive()) {
  uiText(radioLinkPin.substring(0,4),190,122,4,UI_WHITE);
  uiText("-",235,154,1,UI_MUTED);
  uiText(radioLinkPin.substring(4),190,162,4,UI_WHITE);
 }else {
  String label=WiFi.status()!=WL_CONNECTED?"No Wi-Fi":radioLinkResetPending?"Unlinking...":time(nullptr)<1700000000?"Syncing clock":!radioLinkResults?"Unavailable":"Preparing...";
  uiText(label,238-int(label.length())*3,145,1,UI_MUTED);
 }
}
void initRadioLink() {
 Preferences prefs;if(!prefs.begin("cf-link",false))return;
 radioLinkId=prefs.getString("id","");radioLinkSecret=prefs.getString("secret","");
 radioLinkPin=prefs.getString("pair_code","");
 radioPhoneLinked=prefs.getBool("linked",false);
 radioLinkResetPending=prefs.getBool("unlink",false);
 radioCodeResetAfter=prefs.getULong("reset_after",0);
 if(radioLinkResetPending)radioPhoneLinked=false;
 radioLastCommand=prefs.getString("last_cmd","");radioLastResult=prefs.getString("last_result","");
 String controlRecord=prefs.getString("control_last","");
 if(controlRecord.length()>33 && controlRecord[32]==':'){radioLastControl=controlRecord.substring(0,32);radioLastControlStatus=controlRecord.substring(33);}
 if(!radioLinkHex(radioLastControl,32) || (radioLastControlStatus!="applied" && radioLastControlStatus!="failed")){radioLastControl="";radioLastControlStatus="";}
 if(!radioLinkHex(radioLinkId,32)||!radioLinkHex(radioLinkSecret,64)) {
  radioLinkId="";radioLinkSecret="";
 }
 prefs.end();radioLinkResults=xQueueCreate(1,sizeof(JsonDocument*));
}
void ensureRadioLinkIdentity() {
 if(radioLinkId.length() || WiFi.status()!=WL_CONNECTED || (radioLinkIdentityAttemptAt && millis()-radioLinkIdentityAttemptAt<60000))return;
 radioLinkIdentityAttemptAt=millis(); // Generate only while RF entropy is active.
 String id=radioLinkRandom(16),secret=radioLinkRandom(32);Preferences prefs;
 if(!prefs.begin("cf-link",false))return;
 bool saved=prefs.putString("id",id)==id.length() && prefs.putString("secret",secret)==secret.length();prefs.end();
 if(saved){radioLinkId=id;radioLinkSecret=secret;}
}
bool prepareStableRadioCode(bool reset=false) {
 if(!reset && validRadioPairCode(radioLinkPin))return true;
 if(WiFi.status()!=WL_CONNECTED)return false;
 String pin;for(int i=0;i<radioDeviceCodeDigits;++i)pin+=char('0'+esp_random()%10);
 if(pin==radioLinkPin)pin.setCharAt(pin.length()-1,char('0'+(pin[pin.length()-1]-'0'+1)%10));
 Preferences prefs;if(!prefs.begin("cf-link",false))return false;
 bool saved=prefs.putString("pair_code",pin)==pin.length();prefs.end();
 if(saved){radioLinkPin=pin;radioStableCodeRegistered=false;radioLinkCodeAttemptAt=0;}
 return saved;
}
void rememberPhoneLinked(bool linked) {
 if(radioPhoneLinked==linked)return;
 radioPhoneLinked=linked;Preferences prefs;if(prefs.begin("cf-link",false)){prefs.putBool("linked",linked);prefs.end();}
}
void radioLinkWorker(void* parameter) {
 RadioLinkJob* job=static_cast<RadioLinkJob*>(parameter);
 JsonDocument* result=new(std::nothrow) JsonDocument(&radioLinkAllocator);int status=0;
 if(result)do {
  if(WiFi.status()!=WL_CONNECTED || time(nullptr)<1700000000)break;
  DeadlineStationClient client;client.setCACert(WEBSITE_ROOT_CA);client.setHandshakeTimeout(5);client.setTimeout(1000);
  HTTPClient http;http.useHTTP10(true);http.setConnectTimeout(4000);http.setTimeout(4000);
  String endpoint=String(RADIO_SERVICE_ORIGIN)+"/api/radio/";
  endpoint+=job->mode==1?"link/start":job->mode==3?"link/reset":"poll";
  static bool enrolledThisBoot=false;
  if(job->mode==1 && !enrolledThisBoot && strlen(RADIO_ENROLLMENT_TOKEN)==64) {
   HTTPClient registration; registration.useHTTP10(true); registration.setConnectTimeout(4000); registration.setTimeout(4000);
   if(registration.begin(client,String(RADIO_SERVICE_ORIGIN)+"/api/radio/enroll")) {
    registration.addHeader("Content-Type","application/json");registration.addHeader("Authorization","Bearer "+job->secret);
    JsonDocument enrollment;enrollment["radio_id"]=job->id;enrollment["enrollment_token"]=RADIO_ENROLLMENT_TOKEN;
    String encoded;serializeJson(enrollment,encoded);int enrollmentStatus=registration.POST(encoded);
    enrolledThisBoot=enrollmentStatus==200;Serial.printf("Cloudflare enrollment HTTP %d\n",enrollmentStatus);registration.end();
   }
  }
  if(!http.begin(client,endpoint))break;
  http.addHeader("Content-Type","application/json");http.addHeader("Authorization","Bearer "+job->secret);
  JsonDocument payload;payload["radio_id"]=job->id;
  if(job->mode==1)payload["stable_pair_code"]=job->pin;
  if(job->mode==2) {
   payload["firmware_version"]=RADIO_FIRMWARE_VERSION;payload["remote_control_version"]=1;
   payload["volume_percent"]=job->volume;payload["muted"]=job->muted;payload["current_station_code"]=job->currentCode;
   if(job->controlAck.length()){payload["control_ack_id"]=job->controlAck;payload["control_ack_status"]=job->controlStatus;}
  }
  if(job->mode==2 && job->inventoryComplete) {
   JsonArray savedCodes=payload["saved_station_codes"].to<JsonArray>();
   for(int i=0;i<job->savedCodeCount;++i)savedCodes.add(job->savedCodes[i]);
  }
  if(job->mode==2 && job->playingCode.length()){payload["playing_station_code"]=job->playingCode;payload["playing_confirmed"]=true;}
  if(job->mode==2 && job->ack.length()){payload["ack_id"]=job->ack;payload["ack_status"]=job->status;}
  if(job->mode==2 && job->claim.length() && job->decision.length()){payload["pair_claim_id"]=job->claim;payload["pair_decision"]=job->decision;if(job->pairScope=="control")payload["pair_scope"]="control";}
  if(payload.overflowed())break;
  String body;if(serializeJson(payload,body)!=measureJson(payload))break;
  status=http.POST(body);Serial.printf("Cloudflare link mode %d HTTP %d\n",job->mode,status);
  if(status==200 && http.getSize()<=2048) {
   JsonDocument filter;filter["pair_code"]=true;filter["expires_in"]=true;filter["linked"]=true;filter["command_id"]=true;filter["station_code"]=true;
   filter["pair_claim_id"]=true;filter["pair_check"]=true;filter["claim_decision_ack"]=true;filter["claim_result"]=true;
   filter["command_expires_in"]=true;filter["persistent"]=true;filter["pair_scope"]=true;
   filter["control_command_id"]=true;filter["control_action"]=true;filter["control_value"]=true;
   filter["control_expires_in"]=true;filter["control_acknowledged_id"]=true;filter["control_valid_id"]=true;
   BoundedStationStream stream(http.getStream());
   if(deserializeJson(*result,stream,DeserializationOption::Filter(filter),DeserializationOption::NestingLimit(2)) || stream.exhausted() || result->overflowed()){result->clear();status=-1;}
  }else if(status==200)status=-1;
  http.end();
 }while(false);
 if(result){(*result)["mode"]=job->mode;(*result)["status"]=status;(*result)["sent_ack"]=job->ack;}
 delete job;
 if(xQueueSend(radioLinkResults,&result,0)!=pdTRUE)delete result;
 vTaskDelete(nullptr);
}
bool radioApprovalPopupVisible() {
 return radioOn && uiPage==0 && radioPendingClaim.length() && !radioPairDecision.length();
}
void drawRadioApprovalPopup() {
 screen.fillRoundRect(24,40,272,152,10,UI_BG);screen.drawRoundRect(24,40,272,152,10,UI_SKY);
 uiCenter(radioPendingScope=="control"?"Allow phone controls?":"Allow this phone?",51,2,UI_WHITE);
 uiCenter("Match this number on your phone",77,1,UI_MUTED);
 uiCenter(radioPendingCheck,94,3,UI_WHITE);
 uiCenter(radioPendingScope=="control"?"Station, volume and mute only":"Only allow a request you started",125,1,UI_MUTED);
 screen.fillRoundRect(38,145,113,36,6,UI_BLUE);uiText("Allow",65,155,2,UI_WHITE);
 screen.fillRoundRect(169,145,113,36,6,0xC800);uiText("Deny",201,155,2,UI_WHITE);
}
void tapRadioApprovalPopup(int x,int y) {
 if(!radioApprovalPopupVisible() || y<145 || y>=181)return;
 if(x>=38 && x<151)radioPairDecision="approve";
 else if(x>=169 && x<282)radioPairDecision="deny";
 else return;
 radioLinkRequestedMode=2;radioLinkPollAt=0;uiDirty=true;changed=true;
}
void openRadioLinkPage() {
 if(radioApprovalPopupVisible()){backToRadioHome();return;}
 wakeRadioDisplay();uiPage=0;homePopup=6;uiDirty=true;changed=true;radioLinkMessage="";
 if(WiFi.status()!=WL_CONNECTED){radioLinkMessage="Connect Wi-Fi first.";return;}
 if(!radioLinkResults || !radioLinkId.length()){radioLinkMessage="Link storage unavailable.";return;}
 if(!radioLinkPin.length() && !radioPhoneLinked){radioLinkRequestedMode=1;radioLinkMessage="Preparing link code...";}
}
bool requestRadioCodeReset() {
 if(radioCodeResetLocked() || radioPairDecision.length())return false;
 if(WiFi.status()!=WL_CONNECTED || time(nullptr)<1700000000){radioLinkMessage="Connect Wi-Fi before resetting.";return false;}
 Preferences prefs;bool stored=false;
 if(prefs.begin("cf-link",false)){radioCodeResetAfter=uint32_t(time(nullptr))+60;stored=prefs.putULong("reset_after",radioCodeResetAfter)>0 && prefs.putBool("unlink",true)>0;prefs.end();}
 if(!stored){radioCodeResetAfter=0;radioLinkMessage="Could not save reset. Please retry.";return false;}
 radioLinkResetPending=true;rememberPhoneLinked(false);radioLinkRequestedMode=3;radioLinkPollAt=0;
 radioPendingClaim="";radioPendingCheck="";radioPendingScope="";radioPairDecision="";radioControlId="";radioControlAck="";radioControlAckStatus="";radioLinkMessage="Resetting and unpairing phones...";return true;
}
bool completeRadioCodeReset() {
 if(!prepareStableRadioCode(true))return false;
 Preferences prefs;bool stored=false;
 if(prefs.begin("cf-link",false)){stored=prefs.putBool("unlink",false)>0;prefs.end();}
 if(!stored)return false;
 radioLinkResetPending=false;radioStableCodeRegistered=false;radioLinkCodeAttemptAt=0;
 rememberPhoneLinked(false);radioAckId="";radioAckStatus="";radioPendingClaim="";radioPendingCheck="";radioPendingScope="";radioPairDecision="";radioControlId="";radioControlAck="";radioControlAckStatus="";
 radioLinkMessage="Code reset. All phones unpaired.";return true;
}
void drawRadioLinkPage() {
 screen.fillRoundRect(16,44,288,146,10,UI_BG);screen.drawRoundRect(16,44,288,146,10,UI_SKY);
 uiCenter("Device Code",53,2,UI_WHITE);
 String formatted=!radioLinkResetPending&&validRadioPairCode(radioLinkPin)?formattedDeviceCode():"------";
 uiCenter(formatted,82,3,UI_WHITE);
 uiCenter(uiShort(radioLinkMessage.length()?radioLinkMessage:"Reset disconnects all phones",42),117,1,UI_MUTED);
 screen.fillRoundRect(30,140,124,40,6,radioCodeResetLocked()?UI_PANEL:UI_BLUE);uiText(radioCodeResetLocked()?"Please wait":"Reset code",54,156,1,UI_WHITE);
 screen.fillRoundRect(166,140,124,40,6,UI_PANEL);uiText("Exit",204,152,2,UI_WHITE);
}
void tapRadioLinkPage(int x,int y) {
 if(y<140 || y>=180)return;
 if(x>=166 && x<290){backToRadioHome();return;}
 if(x>=30 && x<154){requestRadioCodeReset();uiDirty=true;changed=true;}
}
void finishRadioRemoteCommand(bool success) {
 if(!radioRemoteRunning)return;
 radioAckId=radioRemoteId;radioAckStatus=success?"added":"failed";
 radioLastCommand=radioRemoteId;radioLastResult=radioAckStatus;
 Preferences prefs;if(prefs.begin("cf-link",false)){prefs.putString("last_cmd",radioLastCommand);prefs.putString("last_result",radioLastResult);prefs.end();}
 radioRemoteId="";radioRemoteCode="";radioRemoteRunning=false;radioLinkPollAt=0;
 if(!success){uiPage=5;uiDirty=true;}
}
bool radioRemoteCommandAllowed() {
 return !radioLinkResetPending && radioRemoteId.length() && int32_t(radioRemoteUntil-millis())>0;
}
// Absolute setters are idempotent. JSON/TLS work stays on its worker; all
// audio, station and Preferences operations below run on the Arduino loop.
bool radioControlValueAllowed(const String& action,bool number,bool boolean,int value) {
 return (action=="set_volume" && number && value>=0 && value<=100) ||
        (action=="select_station" && number && value>=10 && value<=999999) ||
        (action=="set_mute" && boolean);
}
void finishRadioControl(bool applied) {
 if(!radioControlId.length())return;
 radioControlAck=radioControlId;radioControlAckStatus=applied?"applied":"failed";radioControlAckAt=millis();
 radioLastControl=radioControlId;radioLastControlStatus=radioControlAckStatus;
 Preferences prefs;if(prefs.begin("cf-link",false)){prefs.putString("control_last",radioLastControl+":"+radioLastControlStatus);prefs.end();}
 radioControlId="";radioControlAction="";radioControlUntil=0;radioControlNeedsValidation=false;radioLinkPollAt=0;changed=true;
}
bool applyRadioControl(const String& action,int value,bool boolean) {
 if(action=="set_volume") {
  int previous=volumePercent;volumePercent=value;saveVolumeIfDue(true);
  if(savedVolumePercent!=volumePercent || savedRadioMuted!=radioMuted){volumePercent=previous;saveVolumeIfDue(true);applyRadioOutputVolume();return false;}
  applyRadioOutputVolume();return true;
 }
 if(action=="set_mute") {
  bool previous=radioMuted;radioMuted=boolean;saveVolumeIfDue(true);
  if(savedVolumePercent!=volumePercent || savedRadioMuted!=radioMuted){radioMuted=previous;saveVolumeIfDue(true);applyRadioOutputVolume();return false;}
  applyRadioOutputVolume();return true;
 }
 if(action!="select_station" || stationCount<1 || stationCount>MAX_STATIONS)return false;
 String code=String(value);int index=-1;
 for(int i=0;i<stationCount;++i)if(stationCodes[i]==code){index=i;break;}
 if(index<0)return false; // Never accept an arbitrary stream URL or add a station.
 int previous=selected;selected=index;savePlaybackStateIfDue(true);
 if(savedStationUrl!=streamUrls[selected]){selected=previous;savePlaybackStateIfDue(true);return false;}
 bool restart=previous!=index || uiPaused || safeRecoveryMode;
 uiPaused=false;safeRecoveryMode=false;
 if(restart){playbackRecovery.reset();stationPending=true;lastTransition=millis();}
 uiDirty=true;return true;
}
void validatePendingRadioControl(const String& valid) {
 radioControlValidId=radioLinkHex(valid,32)?valid:"";
 if(radioControlId.length() && radioControlId!=radioControlValidId) {
  radioControlId="";radioControlAction="";radioControlUntil=0;radioControlNeedsValidation=false;
 }else if(radioControlId.length())radioControlNeedsValidation=false;
}
void receiveRadioControl(JsonDocument& result) {
 // The server validates active grants even while a delivery lease is busy.
 // This cancels a deferred request after unlink, reset, restore or expiry.
 validatePendingRadioControl(result["control_valid_id"]|"");
 String acknowledged=result["control_acknowledged_id"]|"";
 if(acknowledged.length() && acknowledged==radioControlAck){radioControlAck="";radioControlAckStatus="";}
 String id=result["control_command_id"]|"",action=result["control_action"]|"";
 int expires=result["control_expires_in"]|0;
 if(radioLinkResetPending || !radioLinkHex(id,32) || id!=radioControlValidId || radioControlId.length())return;
 // A new server command supersedes an old receipt removed by phone unlink.
 if(radioControlAck.length() && radioControlAck!=id){radioControlAck="";radioControlAckStatus="";}
 if(radioControlAck.length())return;
 if(id==radioLastControl){radioControlAck=id;radioControlAckStatus=radioLastControlStatus;radioControlAckAt=millis();radioLinkPollAt=0;return;}
 JsonVariant value=result["control_value"];bool numeric=value.is<int>()&&!value.is<bool>(),boolean=value.is<bool>();
 radioControlId=id;radioControlAction=action;radioControlNeedsValidation=false;radioControlValue=numeric?value.as<int>():0;radioControlBoolean=boolean?value.as<bool>():false;
 uint32_t elapsed=millis()-radioLinkTaskAt;
 if(expires<1 || expires>60 || elapsed>=uint32_t(expires)*1000 || !radioControlValueAllowed(action,numeric,boolean,radioControlValue)){finishRadioControl(false);return;}
 radioControlUntil=millis()+uint32_t(expires)*1000-elapsed;
}
void serviceRadioControl() {
 // An unlinked phone can remove its command row before a delayed receipt. Do
 // not retain an unknown receipt forever or block commands from another phone.
 if(radioControlAck.length() && uint32_t(millis()-radioControlAckAt)>=120000){radioControlAck="";radioControlAckStatus="";}
 if(!radioControlId.length())return;
 if(radioLinkResetPending || !radioOn || int32_t(radioControlUntil-millis())<=0){finishRadioControl(false);return;}
 if(portalActive || uiPage!=0 || homePopup || radioPendingClaim.length() || radioPairDecision.length() || voiceBusy() || syncTaskHandle || stationAddRequested || radioRemoteId.length() || uiVolumeDragging){radioControlNeedsValidation=true;return;}
 // Returning from setup/another modal must not execute a stale cached request.
 // Obtain a fresh authenticated grant check before applying a deferred command.
 if(radioControlNeedsValidation){
  if(!radioLinkTask && (!radioLinkPollAt || uint32_t(millis()-radioLinkPollAt)>=10000UL))radioLinkRequestedMode=2;
  return;
 }
 finishRadioControl(applyRadioControl(radioControlAction,radioControlValue,radioControlBoolean));
}
void serviceRadioLink() {
 ensureRadioLinkIdentity();
 JsonDocument* result=nullptr;
 if(radioLinkResults && xQueueReceive(radioLinkResults,&result,0)==pdTRUE) {
  radioLinkTask=nullptr;
  if(result) {
   int status=(*result)["status"]|0,mode=(*result)["mode"]|0;
   if(status==200) {
    if(mode==1) {
     String pin=(*result)["pair_code"]|"";
     int ttl=(*result)["expires_in"]|0;
     bool persistent=(*result)["persistent"]|false;
     if(validRadioPairCode(pin) && pin==radioLinkPin && persistent){radioStableCodeRegistered=true;radioLinkMessage="Device Code ready.";radioLinkPollAt=0;}
     else radioLinkMessage="Code unavailable. Retry or update site.";
    }else if(mode==3) {
     if(!completeRadioCodeReset())radioLinkMessage="Saving reset. Retrying...";
    }else {
     bool linked=(*result)["linked"]|false;if(!radioLinkResetPending)rememberPhoneLinked(linked);
     if(!linked){radioControlId="";radioControlAck="";radioControlAckStatus="";}
     String decisionAck=(*result)["claim_decision_ack"]|"",decisionResult=(*result)["claim_result"]|"";
     if(decisionAck.length() && decisionAck==radioPendingClaim && radioPairDecision.length()) {
      bool controls=radioPendingScope=="control";
      radioPendingClaim="";radioPendingCheck="";radioPendingScope="";radioPairDecision="";
      radioLinkCodeAttemptAt=0;
      radioLinkMessage=decisionResult=="approved"?(controls?"Phone controls allowed.":"Phone approved. Ready to add stations."):decisionResult=="denied"?"Phone request declined.":"Request expired. Try your code again.";
     }
     String pending=(*result)["pair_claim_id"]|"",check=(*result)["pair_check"]|"",scope=(*result)["pair_scope"]|"";
     bool checkValid=check.length()==4;
     for(unsigned i=0;i<check.length();++i)if(check[i]<'0'||check[i]>'9')checkValid=false;
     if(radioLinkHex(pending,32)&&checkValid&&validRadioPairCode(radioLinkPin)&&(scope==""||scope=="add"||scope=="control")) {
      if(radioPendingClaim!=pending){radioPendingClaim=pending;radioPendingCheck=check;radioPendingScope=scope;radioPairDecision="";backToRadioHome();}
     }else if(!pending.length()&&!radioPairDecision.length()){
      if(radioPendingClaim.length()){radioLinkCodeAttemptAt=0;}
      radioPendingClaim="";radioPendingCheck="";radioPendingScope="";
     }
     receiveRadioControl(*result);
     String sent=(*result)["sent_ack"]|"";if(sent.length()&&sent==radioAckId){radioAckId="";radioAckStatus="";}
     String command=(*result)["command_id"]|"",code=(*result)["station_code"]|"";
     int expires=(*result)["command_expires_in"]|0;
     if(!radioLinkResetPending && radioLinkHex(command,32)&&validListenerCode(code.c_str())&&!radioRemoteId.length() && expires>0 && expires<=300) {
      if(command==radioLastCommand){radioAckId=command;radioAckStatus=radioLastResult;radioLinkPollAt=0;}
      else {radioRemoteId=command;radioRemoteCode=code;radioRemoteUntil=millis()+uint32_t(expires)*1000;}
     }
    }
   }else if(status==409 && mode==1 && !radioStableCodeRegistered){
    if(radioDeviceCodeDigits<10)++radioDeviceCodeDigits;
    if(prepareStableRadioCode(true)){radioLinkRequestedMode=1;radioLinkMessage="Preparing another Device Code...";}
   }else {radioLinkMessage=status==429?"Please wait before retrying.":"Link connection failed. Try again.";}
   delete result;uiDirty=true;
  }
 }
 serviceRadioControl();
 if(radioRemoteId.length()&&!radioRemoteRunning&&!radioRemoteCommandAllowed()) {
  radioRemoteRunning=true;finishRadioRemoteCommand(false);
 }
 if(!radioLinkResults || radioLinkTask || syncTaskHandle || artWorkerBusy || stationAddRequested || WiFi.status()!=WL_CONNECTED || time(nullptr)<1700000000 || ESP.getFreeHeap()<80000 || portalActive || !radioOn)return;
 if(radioRemoteId.length()) {
  if(homePopup==8)return;
  if(!radioRemoteRunning){radioRemoteRunning=true;stationAddCanceled=false;startStationCodeWorker(radioRemoteCode,true);if(!syncTaskHandle)finishRadioRemoteCommand(false);}
  return;
 }
 bool pairing=validRadioPairCode(radioLinkPin);
 if(!radioLinkRequestedMode && shouldRefreshHomeLinkCode())radioLinkRequestedMode=1;
 int mode=radioLinkResetPending?3:radioLinkRequestedMode;
 if(radioLinkResetPending && radioLinkPollAt && millis()-radioLinkPollAt<15000 && radioLinkRequestedMode!=3)return;
 if(!mode && (pairing||radioPhoneLinked||radioAckId.length()||radioPairDecision.length()) && (!radioLinkPollAt || millis()-radioLinkPollAt>=(pairing?10000UL:15000UL)))mode=2;
 if(!mode)return;
 if(mode==1 && !prepareStableRadioCode()){radioLinkCodeAttemptAt=millis();radioLinkMessage="Could not save radio code. Retry later.";radioLinkRequestedMode=0;return;}
 RadioLinkJob* job=new(std::nothrow) RadioLinkJob{radioLinkId,radioLinkSecret,radioAckId,radioAckStatus,radioPendingClaim,radioPairDecision,radioLinkPin,monthlyRadioUsageCode(),mode};if(!job)return;
 if(mode==2){snapshotRadioSavedStations(*job);job->controlAck=radioControlAck;job->controlStatus=radioControlAckStatus;job->pairScope=radioPendingScope;
  job->volume=volumePercent;job->muted=radioMuted;job->currentCode=stationCount>0 && selected>=0 && selected<stationCount?stationCodes[selected]:"";
 }
 radioLinkPollAt=millis();radioLinkTaskAt=millis();radioLinkRequestedMode=0;
 if(mode==1)radioLinkCodeAttemptAt=millis();
 if(xTaskCreate(radioLinkWorker,"cf-link",8192,job,1,&radioLinkTask)!=pdPASS){delete job;radioLinkTask=nullptr;radioLinkMessage="Busy. Try again.";uiDirty=true;}
}
