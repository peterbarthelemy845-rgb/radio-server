const fs=require('fs'),vm=require('vm'),assert=require('assert');
const read=n=>fs.readFileSync(__dirname+'/'+n,'utf8').replace(/\r\n/g,'\n');
const policy=read('feature_policy.h');
let js=policy.replace(/^#.*$/gm,'').replace(/\b(?:int|bool) (\w+)\(([^)]*)\)/g,(_,n,args)=>'function '+n+'('+args.replace(/\b(?:int|bool) /g,'')+')')
 .replace(/const int (\w+)\[\]=\{([^}]+)\};/g,'const $1=[$2];').replace(/for\(int /g,'for(let ');
const p={};vm.createContext(p);vm.runInContext(js,p);
assert.equal(p.batteryEstimatePercent(0),-1);assert.equal(p.batteryEstimatePercent(5000),-1);
assert.equal(p.batteryEstimatePercent(3200),0);assert.equal(p.batteryEstimatePercent(4200),100);
let last=-1;for(let mv=2800;mv<=4350;mv++){let v=p.batteryEstimatePercent(mv);assert(v>=last&&v>=0&&v<=100);last=v;}
assert.equal(p.dragVolumePercent(-10),0);assert.equal(p.dragVolumePercent(53),0);
assert.equal(p.dragVolumePercent(160),50);assert.equal(p.dragVolumePercent(267),100);assert.equal(p.dragVolumePercent(400),100);
const source=read('radio_features.h');
const body=name=>source.split(name+' {')[1].split('\n}\n')[0];
console.log('PASS: battery voltage estimate bounds/monotonicity and drag-volume endpoints.');
const display=read('Display_ST7789.cpp'),sketch=read('waveshare_radio.ino');
assert(!display.includes('LCD_WriteCommand(0x29)'),'driver must not reveal uninitialized GRAM');
assert(display.includes('Set_Backlight(0)'));
assert(sketch.indexOf('  drawStation();\n  if(screenReady) {LCD_WriteCommand(0x29);Set_Backlight(50);}')>0);
console.log('PASS: LCD remains off and backlight dark until first valid home framebuffer.');
const touch=read('touch_ui.h');
const gesture='if(uiTouchHeld && uiVolumeDragging'+touch.split('      if(uiTouchHeld && uiVolumeDragging')[1].split('    } else if(millis()-uiTouchLastSeen>100)')[0];
let taps=0,volumes=[];
const drag={homePopup:0,radioApprovalPopupVisible:()=>false,uiTouchHeld:false,uiVolumeDragging:false,uiPage:0,radioOn:true,onNoticeActive:false,
 portalActive:false,dragVolumePercent:p.dragVolumePercent,uiVolume:v=>volumes.push(v),uiTap:()=>taps++};
vm.createContext(drag);vm.runInContext('function move(tx,ty){const x=[239-ty],y=[tx];'+gesture+'}',drag);
drag.move(160,215);assert(drag.uiVolumeDragging);assert.equal(taps,1);
drag.move(53,215);drag.move(160,160);drag.move(300,215);
assert.deepEqual(volumes,[0,50,100]);assert.equal(taps,1,'drag must not repeatedly tap/pause stations');
drag.uiPage=3;drag.move(53,215);assert.equal(volumes.length,3,'settings must not respond to old slider drag');
drag.uiTouchHeld=false;drag.uiVolumeDragging=false;drag.uiPage=0;
drag.move(25,215);assert(!drag.uiVolumeDragging,'minus button must not become a drag gesture');
console.log('PASS: actual touch handler starts slider drag, tracks held movement, clamps volume, prevents repeated taps and ignores settings/buttons.');
const stored={};let appliedZone='';
const prefs={begin:()=>true,end(){},putUChar(k,v){stored[k]=v},getUChar:(k,d)=>stored[k]??d};
const zones=[...source.matchAll(/\{"([^"]+)","([^"]+)"\}/g)].map(m=>({name:m[1],rule:m[2]}));
const settings={prefs,radioZone:11,radioZones:zones,RADIO_ZONE_COUNT:zones.length,
 configTzTime:r=>appliedZone=r,analogReadResolution(){},analogSetPinAttenuation(){},ADC_11db:3};
const prefsBody=signature=>body(signature).replace('Preferences p;','const p=prefs;');
vm.createContext(settings);vm.runInContext('function save(){'+prefsBody('void saveClockSettings()')+'}\nfunction load(){'+prefsBody('void loadClockSettings()')+'}',settings);
settings.save();settings.radioZone=0;settings.load();
assert.equal(settings.radioZone,11);assert.equal(appliedZone,'JST-9');
stored.zone=255;settings.load();assert.equal(settings.radioZone,1);
console.log('PASS: actual time-zone save/load preserves selection and safely defaults invalid stored values.');
assert(!read('radio_features.h').includes('RadioAlarm'));
assert(!read('settings_ui.h').includes('Snooze'));

drag.uiTouchHeld=false;drag.uiVolumeDragging=false;drag.uiPage=0;drag.radioApprovalPopupVisible=()=>true;
const beforePopupVolume=volumes.length;drag.move(160,215);drag.move(260,215);assert(!drag.uiVolumeDragging);assert.equal(volumes.length,beforePopupVolume,'approval overlay blocks held volume gestures behind it');
console.log('PASS: modal phone approval prevents volume drag behind the popup.');

drag.uiTouchHeld=false;drag.uiVolumeDragging=false;drag.homePopup=6;drag.radioApprovalPopupVisible=()=>false;drag.move(160,215);drag.move(260,215);assert(!drag.uiVolumeDragging);assert.equal(volumes.length,beforePopupVolume,'code and delete overlays also block volume drag');
