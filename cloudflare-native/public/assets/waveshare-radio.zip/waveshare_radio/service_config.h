#pragma once
#define RADIO_SERVICE_ORIGIN "https://radiolocals.com"
#if __has_include("cloudflare_provisioning.h")
#include "cloudflare_provisioning.h"
#endif
#ifndef RADIO_ENROLLMENT_TOKEN
#define RADIO_ENROLLMENT_TOKEN ""
#endif
