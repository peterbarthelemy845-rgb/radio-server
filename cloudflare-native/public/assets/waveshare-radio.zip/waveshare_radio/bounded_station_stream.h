#pragma once
#include <esp_heap_caps.h>
#include <cstddef>

class StationJsonAllocator : public ArduinoJson::Allocator {
  struct alignas(std::max_align_t) Header { size_t size; };
  size_t used_ = 0;
public:
  void* allocate(size_t size) override {
    if (size > 65536 || used_ > 65536 - size) return nullptr;
    Header* block = static_cast<Header*>(heap_caps_malloc(size + sizeof(Header), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
    if (!block) return nullptr; // This radio requires PSRAM; don't drain audio's internal heap.
    block->size = size;
    used_ += size;
    return block + 1;
  }
  void deallocate(void* pointer) override {
    if (!pointer) return;
    Header* block = static_cast<Header*>(pointer) - 1;
    used_ -= block->size;
    heap_caps_free(block);
  }
  void* reallocate(void* pointer, size_t size) override {
    if (!pointer) return allocate(size);
    size_t oldSize = (static_cast<Header*>(pointer) - 1)->size;
    if (size > 65536 || used_ - oldSize > 65536 - size) return nullptr;
    Header* block = static_cast<Header*>(heap_caps_realloc(static_cast<Header*>(pointer) - 1,
                         size + sizeof(Header), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
    if (!block) return nullptr;
    block->size = size;
    used_ = used_ - oldSize + size;
    return block + 1;
  }
};

// Lifetime includes queued documents; only one refresh may be in flight.
StationJsonAllocator stationJsonAllocator;

class DeadlineStationClient : public WiFiClientSecure {
  unsigned long started_ = millis();
  bool expired_ = false;
  bool expired() {
    if (!expired_ && millis() - started_ >= 20000) {
      expired_ = true;
      WiFiClientSecure::stop();
    }
    return expired_;
  }
public:
  int available() override { return expired() ? 0 : WiFiClientSecure::available(); }
  uint8_t connected() override { return expired() ? 0 : WiFiClientSecure::connected(); }
  int read() override { return expired() ? -1 : WiFiClientSecure::read(); }
  int read(uint8_t* buffer, size_t size) override { return expired() ? -1 : WiFiClientSecure::read(buffer, size); }
};

// Bound a complete response, including servers that send one byte forever.
// This is read only by the station worker; no audio/encoder calls occur here.
class BoundedStationStream : public Stream {
  Stream& input_;
  size_t remaining_ = 32768;
  unsigned long started_ = millis();
public:
  explicit BoundedStationStream(Stream& input,size_t limit=32768) : input_(input) {remaining_=limit;setTimeout(250); }
  bool exhausted() const { return !remaining_ || millis() - started_ >= 10000; }
  int available() override { return exhausted() ? 0 : input_.available(); }
  int read() override {
    if (exhausted()) return -1;
    if (!input_.available()) { delay(1); return -1; }
    int value = input_.read();
    if (value >= 0) --remaining_;
    return value;
  }
  int peek() override { return exhausted() || !input_.available() ? -1 : input_.peek(); }
  void flush() override {}
  size_t write(uint8_t) override { return 0; }
};

bool validStationFields(const char* name, const char* url) {
  if (!name || !url || !*name || !*url) return false;
  if (strlen(name) > 96 || strlen(url) > 1024) return false;
  return strncmp(url, "https://", 8) == 0 || strncmp(url, "http://", 7) == 0;
}

bool validListenerCode(const char* code) {
  if(!code || (strlen(code)<2 || strlen(code)>6))return false;
  for(int i=0;i<strlen(code);++i)if(code[i]<'0' || code[i]>'9')return false;
  return true;
}
