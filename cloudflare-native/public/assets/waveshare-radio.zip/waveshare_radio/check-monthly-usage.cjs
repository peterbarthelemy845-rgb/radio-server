const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync(__dirname+'/radio_link.h','utf8');
function body(signature){let a=source.indexOf(signature);assert(a>=0);a=source.indexOf('{',a);let n=1,b=a+1;while(n){if(source[b]==='{')n++;if(source[b]==='}')n--;b++;}return source.slice(a+1,b-1);}
let now=1000,running=true,voice=false;
const state={radioOn:true,radioMuted:false,stationCount:1,audioReady:true,uiPaused:false,safeRecoveryMode:false,stationPending:false,portalActive:false,voiceBusy:()=>voice,WiFi:{status:()=>3},WL_CONNECTED:3,audio:{isRunning:()=>running},selected:0,stationCodes:['55'],radioUsageCode:'',radioUsageTracking:false,radioUsageSince:0,millis:()=>now,uint32_t:x=>x>>>0,validListenerCode:s=>/^\d{2,6}$/.test(s)};
vm.createContext(state);
vm.runInContext('function monthlyPlaybackQualified(){'+body('bool monthlyPlaybackQualified(')+'}',state);
vm.runInContext('function update(){'+body('void updateMonthlyRadioUsage(').replace('String code=','let code=').replace('bool playing=','let playing=').replace('code.c_str()','code')+'}',state);
vm.runInContext('function code(){'+body('String monthlyRadioUsageCode(')+'}',state);
state.update();now=60999;state.update();assert.equal(state.code(),'');now=61000;state.update();assert.equal(state.code(),'55');
state.uiPaused=true;state.update();assert.equal(state.code(),'');state.uiPaused=false;state.update();now+=59999;assert.equal(state.code(),'');now++;assert.equal(state.code(),'55');
state.stationCodes[0]='56';state.update();assert.equal(state.code(),'');now+=60000;state.update();assert.equal(state.code(),'56');
for(const key of ['radioOn','audioReady']){state[key]=false;state.update();assert.equal(state.code(),'');state[key]=true;state.update();}
for(const key of ['safeRecoveryMode','stationPending','portalActive','radioMuted']){state[key]=true;state.update();assert.equal(state.code(),'');state[key]=false;state.update();}
voice=true;state.update();assert.equal(state.code(),'');voice=false;running=false;state.update();assert.equal(state.code(),'');running=true;
now=0xfffffff0;state.update();now=(now+60000)>>>0;assert.equal(state.code(),'56');
assert(source.includes('payload["playing_confirmed"]=true'));assert(source.includes('monthlyRadioUsageCode(),mode'));
console.log('PASS: actual monthly usage policy waits 60 continuous seconds; pause, outage, voice, standby, station change and rollover; foreground snapshot and authenticated poll only.');
