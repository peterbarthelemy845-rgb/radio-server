const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync(__dirname+'/settings_ui.h','utf8');
function body(sig){let a=source.indexOf(sig);assert(a>=0);a=source.indexOf('{',a);let d=1,b=a+1;while(d){if(source[b]==='{')d++;if(source[b]==='}')d--;b++;}return source.slice(a+1,b-1);}
let saves=true,snapshot,stops=0;
const c={stations:['A','B','C'],streamUrls:['a','b','c'],stationLogoUrls:['x','y','z'],stationCodes:['10','11','12'],stationRevisions:['1','2','3'],stationExpectedRevisions:['1','20','30'],stationSyncRetryAt:[100,200,300],stationCount:3,selected:1,syncTaskHandle:null,radioRemoteRunning:false,stationAddRequested:false,audioReady:true,audio:{stopSong(){stops++}},playingUrl:'b',uiPaused:true,safeRecoveryMode:false,stationPending:false,changed:false,lastTransition:0,playbackRecovery:{reset(){}},min:Math.min,millis:()=>1000,cancelVoicePrompts(){},savePlaybackStateIfDue(){},saveStations(){snapshot=c.stations.slice(0,c.stationCount);return saves;}};
vm.createContext(c);vm.runInContext('function remove(index){'+body('bool deleteSavedStation(').replace('String name=','let name=').replace('int oldCount=','let oldCount=').replace('uint32_t retry=','let retry=').replace(/for\(int /g,'for(let ')+'}',c);
saves=false;assert(!c.remove(1));assert.deepEqual(c.stations,['A','B','C']);assert.equal(c.stationCount,3);assert.equal(stops,0,'failed persistence cannot interrupt playback');
saves=true;c.syncTaskHandle={};assert(!c.remove(1));c.syncTaskHandle=null;c.radioRemoteRunning=true;assert(!c.remove(1));c.radioRemoteRunning=false;
assert(c.remove(1));assert.deepEqual(snapshot,['A','C']);assert.equal(c.stationCount,2);assert.equal(c.stations[1],'C');assert.equal(c.selected,1);assert.equal(stops,1);
assert.deepEqual(c.stationRevisions,['1','3','']);assert.deepEqual(c.stationExpectedRevisions,['1','30','']);assert.deepEqual(c.stationSyncRetryAt,[100,300,0]);
assert(c.remove(1));assert(c.remove(0));assert.deepEqual(snapshot,[]);assert.equal(c.stationCount,0);assert.equal(c.streamUrls[0],'');assert(!c.stationPending);assert(!c.remove(0));
const sketch=fs.readFileSync(__dirname+'/waveshare_radio.ino','utf8');assert(sketch.includes('bool playbackAllowed = stationCount>0'));assert(!sketch.includes('if (!count) return;'));
console.log('PASS: actual station deletion rolls back failed storage, waits for in-flight updates, selects a remaining station, and saves an empty list without restarting deleted audio.');
