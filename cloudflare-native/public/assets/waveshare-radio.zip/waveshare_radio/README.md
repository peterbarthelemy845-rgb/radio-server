## Phone controls — firmware 2026.11.07.1

Upload this version before using the website's new station, volume and mute controls. Existing phone links keep their original add-stations-only permission. On the website choose Enable phone controls, compare the four-digit confirmation, and tap Allow on the physical radio's **Allow phone controls?** popup. The grant permits saved-station selection, volume and mute only. It never exposes Wi-Fi credentials or administrator settings. Reset Device Code or unlink the phone to revoke permission.

This build reports firmware version, selected directory station code, stored volume and mute state over the existing authenticated HTTPS poll. Listening reports remain separate and require genuine continuous playback; a muted radio does not qualify. Commands select only a station already saved on this radio and accept no stream URL. Setters are absolute, expire within 60 seconds, are deduplicated by command ID, and run on the Arduino loop. Setup, voice prompts and station operations defer controls; expired requests fail rather than execute later. A successful receipt means the setting was applied, not that a listener heard audio.

Mute preserves the stored volume. Unmute restores that volume; changing the physical touchscreen's volume also unmutes. Voice prompts and stream reconnects respect mute. Volume, mute and station choice are saved for restart. Phone controls cannot turn a powered-off radio on or off. Some delay is normal because the radio polls securely rather than accepting incoming router connections.

### Update with Arduino IDE

1. Extract the complete `waveshare_radio` folder and open `waveshare_radio.ino`.
2. For an already enrolled radio, a normal upload preserves its identity in ESP32 storage. Public ZIPs compile without a provisioning header. Keep an existing private `cloudflare_provisioning.h` only in your local sketch folder and never share it. Do not erase flash or recreate the identity for an ordinary update. A fresh, unenrolled board needs a new one-time enrollment permission.
3. Select **ESP32S3 Dev Module**, 16 MB flash, **OPI PSRAM**, the 3 MB app / 9 MB FAT partition for 16 MB flash, USB CDC on boot, and the connected USB serial port. Use the same installed display/audio libraries as the existing project.
4. Click Verify, then Upload. If the board cannot connect, hold BOOT while starting upload and release when it connects.
5. Keep the radio connected to Wi-Fi. Its version will appear on the website after an authenticated status report; then enable controls and approve on the radio.

The landscape display and touchscreen retain rotation 3 for the printed case. Pin assignments and radio UI are unchanged apart from the explicit controls approval and Muted status. This code is compiled and its logic is checked, but physical touch/audio/end-to-end controls still need a hardware test. No automatic over-the-air updater or charging detector is added.

New station codes now start at 10 and grow to three or more digits as needed. Existing six-digit codes remain valid. This firmware accepts 2-6 digit codes; upload it before adding newly issued short codes.

## Simple home screen (default)

- Restores the last station and saved volume on power-up.
- Larger station name, smaller artwork, plain Playing / Reconnecting / No Wi-Fi status.
- Artwork and station-name taps do not pause. There is no home Pause button.
- Battery icon only; voltage estimates are not shown as an exact percentage.
- Tap Settings (gear) for Wi-Fi and Time zone.
- Simple is the fixed home layout: larger 112-pixel artwork and a saved phone code in the top bar and a smaller Add station box beside the artwork.
- Tap Add station to go directly to station-code entry. Tap the large Device Code to manage phone pairing.
- Settings pages have Back to radio; home pop-ups have Exit.

# Waveshare touchscreen radio â€” first hardware trial

Open `waveshare_radio.ino` in Arduino IDE. Keep every file in this folder.
This is the new Waveshare build; the old OLED `radio_player` remains separate.

Board: ESP32S3 Dev Module; flash 16 MB; PSRAM OPI; USB CDC On Boot Enabled;
partition 3 MB APP / 9 MB FATFS (16 MB), matching the compiled configuration.
Select the connected USB port and upload. No SD card or filesystem upload.
Uses the already-installed Adafruit GFX, ArduinoJson, WiFiManager 2.0.17,
and ESP32-audioI2S 4.0.0 libraries with ESP32 core 3.3.12.

## Radio controls

Landscape 320 x 240 navy interface, with USB-C facing right and BAT PWR on top:
time, battery icon and Wi-Fi at the top, a larger station name and smaller logo,
with volume +/- and a sliding volume bar at the bottom.
The selected station logo is loaded from the website and cached in PSRAM.
Artwork and station-name taps do not pause playback. There is no home Pause button.
Use the physical knob or narrow screen edges to change stations.
Tap Settings at the top right for Wi-Fi and Time zone.
Tap Add station, type the station owner's 2-6 digit
listener code and tap Add. DEL removes one digit; C clears the field.
The radio looks up only that station, saves it internally, selects it and plays
its stream directly. Reusing a code updates the existing entry; it does not
duplicate it. Back cancels the lookup result. Errors preserve saved stations.
The website package must be deployed first: /api/device/stations/<2-6 digits>.
This firmware does NOT auto-download the complete website station catalog.
La Voix Divine is preloaded; older already-saved station lists are preserved.
Selected coded stations refresh their metadata every five minutes when online.
Saved entries remain available after restart and website lookup outages.
Persistence uses a bounded NVS blob and migrates the older string cache.
If storage is full, Add reports a save error and rolls the in-memory change back.
The station stream itself needs Wi-Fi/internet; a saved code is not offline audio.
A simple battery icon appears beside the clock. Its bars use a smoothed voltage
estimate, not a precision fuel gauge; invalid readings show a question mark.
Charging/USB presence and battery absence cannot be reliably inferred here.
Tap Settings, then Time zone to change the clock region.
Select a saved time zone, including Haiti, US zones, Puerto Rico, UTC, London,
Paris, India and Japan. DST rules are applied for the selected region.
Slide a finger along the bottom volume bar to change volume continuously;
the minus/plus buttons still work. Volume gestures do not pause the station.

## Startup and clock

The selected time zone is remembered. Time synchronizes over Wi-Fi after a
restart, then continues through network outages while the board stays powered.
This build does not restore time from the onboard RTC after power loss.

The LCD stays display-OFF with backlight at zero during reset/initialization.
The first complete home framebuffer is sent before display-ON and backlight
enable, to avoid showing uninitialized colored lines. Correct RGB565 order is
retained. Confirm the startup appearance on the physical radio after upload.

Optional KY-040 station knob: CLK GPIO43, DT GPIO44, SW GPIO18,
+ 3V3, GND GND. These replace the OLD board's GPIO6/7/8 connections.
Do not connect an old volume encoder or external audio amp to this board.
Turn the knob to change station; click for standby/on; hold five seconds
to clear Wi-Fi credentials and open setup. This is software standby,
not battery power cutoff. Firmware enables the board's GPIO7 battery latch
at startup. Hold the board's BAT PWR button for two seconds to save settings
and shut down battery power. USB power remains supplied while plugged in.
The initial button press used to start on battery is ignored until released.
After uploading by USB, test with a charged battery connected: unplug USB;
if needed, press BAT PWR to start. If it still dies, the battery, connection
and charge need checking; the software change does not verify those parts.

## Wi-Fi directly on the screen

Every power-up shows the home screen and starts the radio in the ON state.
The home status shows Playing, Reconnecting, or No Wi-Fi. Saved Wi-Fi is tried
first in the background. If it cannot connect, the existing Wi-Fi setup voice
instructions play once per outage. The home screen stays visible; tap Settings,
then Wi-Fi to open network selection and the password keyboard. Phone setup
can also run in the background without taking over the radio screen.
Tap a network, type its password, and tap Connect. The screen shows success
only after Wi-Fi reports connected. Bad credentials show an error and remain
editable. Working credentials are remembered for the next boot.

Use Shift for capitals; 123 for numbers/symbols; More for punctuation;
ABC to return to letters; Space/Backspace; Show/Hide to inspect a password.
Setup and keyboard use a white background, larger keys, and blue actions.
The keyboard provides all 95 printable ASCII characters. Passwords support
8â€“63 characters or 64 hex digits. Leave the password empty for an open network.
Type name lets you enter an exact network name (1â€“32 bytes) before its password.
Existing non-ASCII network names are preserved when selected from the scan,
but the small built-in display font omits unsupported characters in labels.
The local keyboard does not enter non-ASCII characters; use phone setup for
those credentials. Up to 64 network/security combinations are listed, three per page.
An active scan and a passive beacon scan are merged without filtering open
networks. OPEN identifies password-free networks; leave their password empty.
The phone portal also has its weak-signal display filter disabled.
Only 2.4 GHz Wi-Fi is supported by this ESP32-S3. For iPhone hotspots enable
Maximize Compatibility; on Android select the 2.4 GHz hotspot band. A hotspot
must be enabled and discoverable before scanning. Networks requiring a web
sign-in page do not gain internet access from entering an empty password alone.
No Wi-Fi has a red background on the home screen when not currently connecting.
Tap a network directly to enter its password. More networks advances the
list only when another page exists; Last page is disabled at the end.

Phone setup remains available: connect phone to Radio-Setup (no password),
open http://192.168.4.1, and select Wi-Fi. The portal stays open ten seconds
after successful connection so the phone can display its success message.

## First hardware checks

Compilation does not verify touchscreen targets or Wi-Fi behavior on hardware.
Check: boot/autoplay; touch station and volume; pause/resume; knob if attached;
password keyboard capitals/symbols/delete/show; incorrect password/retry;
open network; reconnect after USB removal; phone setup fallback.
The watchdog, bounded station downloads, playback retry, station cache,
voice prompts, and saved volume/state are retained from the previous firmware.
Screen buffer uses PSRAM to keep internal memory available for Wi-Fi/audio.

## Logo loader

The website currently supplies PNG logos. PNG decoding uses the bundled
MIT-licensed Pngle source by kikuchan and its miniz dependency; no library
installation is needed. Source: https://github.com/kikuchan/pngle
pngle.c is adapted to allocate decoder buffers in PSRAM. Original license
notices remain in the source files. Logo download/decode runs on one bounded
worker, separately from the screen/audio loop, with verified HTTPS to this
website's /static/ files. Download limit 2 MiB, dimensions up to 2048 each,
two million source pixels. Invalid/unavailable images show a neutral placeholder
and retry later; they do not prevent radio playback. JPEG/WebP logos are not
decoded by this build. The clock uses US Eastern time, including daylight saving,
and shows --:-- until network time is synchronized.

I2S: BCLK48 / LRCLK38 / DOUT47, supplied speaker socket. LCD/touch use the
same official Waveshare V2 drivers as the successful hardware tests.
Display RAMCTRL accepts native little-endian RGB565; do not byte swap.


## Link a phone and add a shared station

1. Upload this complete project with ESP32S3 Dev Module, 16 MB flash, OPI PSRAM and the existing 3 MB application partition.
2. Tap **Add station â†’ Link phone** on the radio to display its saved code. The saved Device Code appears beside the cover art. Wi-Fi and a synchronized clock are required.
3. Open a shared `/station/<code>` page on the phone. Enter the saved Device Code (four numbers on new or reset devices; old letter codes remain supported). It remains the same until Reset code is selected on the radio.
4. Compare the four-digit number on the phone and radio. Tap **Allow phone** on the radio within two minutes. **Deny** or **Back** never approves access.
5. After pairing, open a shared station and choose **Yes, add station**. Keep the radio on and online. The page reports success only after the radio confirms its station list was saved.

Phone permission lasts up to 30 days in that browser. To remove it, tap the large Device Code and choose **Reset code**. This changes the code and unpairs all phones. Both devices need internet; no router port forwarding or local browser scanning is used. Different in-app browsers can have separate cookies.

TLS and station requests run on a bounded worker, with station/art workers kept separate. Command retries reuse the existing station-code deduplication and save rollback. This build must still be tried on the physical radio; compiling and mocked API tests do not confirm the real touch, audio, Wi-Fi or end-to-end hardware behavior.

The saved home-screen code does not rotate or disappear after use. It is re-registered after reboot, and each new phone still requires physical Allow/Deny approval. Failed registration retries wait one minute.

The Add Station tile is now a compact button. Below it, the pairing code uses two large rows of four characters; read the top row first, then the bottom row. Tap the code panel for pairing details. The station artwork and bottom volume slider retain their existing layout.

## Saved radio code and deleting stations

The top radio code is eight characters and is separate from a station's listener
code. It survives restarts and does not rotate. Tap it and select Reset code to
replace it; the previous code stops working after the online reset completes.
New phone requests always require Allow phone on the radio and expire after
two minutes. Reset code also revokes every existing phone link.
The server update must be deployed before this firmware can register saved codes.

Delete station opens a confirmation page. Deletion affects this radio only.
After the last station is removed, No stations appears; Add station stays usable.
Empty lists are saved and remain empty after restart. Failed saves restore the list.

Phone approval appears as a small Allow / Deny overlay on the home screen.
Compare the four-digit number with your phone. Choosing either button dismisses
the overlay immediately; the decision is then sent securely in the background.
No Phone connected page appears after approval. Tap the top radio code only
when you want to reset the code or unlink phones. The website inserts the code's
dash automatically, so you only type its letters and numbers.

## Updated listening layout

- Time uses 12-hour format with AM/PM, including midnight and noon.
- Live on the Air appears only while audio is playing, with decorative wave bars.
- The volume track is twice as thick, with a larger drag handle and +/- buttons.
- Add station uses a full-width numeric keypad and a compact code field.
- Delete station and Radio code open dark overlays over the home screen.
- Delete station offers Delete and Exit; Radio code offers Reset code and Exit.
- Reset code durably requests server revocation of all phones before generating
  and registering a replacement code. Offline resets resume on reconnect/restart.
  Reset does not delete installed stations or saved Wi-Fi credentials.

The small Live on the Air badge now sits directly under the station name.
The red home delete button contains only a trash-can icon; confirmation remains.


## Device Code layout update
The home screen shows a large Device Code to the right of the artwork. The station name is below the artwork. Add station, trash (with confirmation), and Settings sit in the top menu; the time and battery are smaller. Tap the large Device Code to open Reset code / Exit.

New or reset devices use four numeric digits. If the server finds a collision, the firmware tries a longer numeric code (up to ten digits). Existing saved letter codes still work: tap Device Code and reset once to change to numbers. Reset unpairs all phones first and is locked for 60 seconds, including across a restart. The new code is displayed only after server registration succeeds. Phone linking still requires physical Allow/Deny approval, TLS verification, per-device credentials and limited attempts. Device Codes are separate from public station codes.

The home Device Code heading and value are both hidden until a usable code is ready. Reset once to change an existing six-digit code to a new four-digit code.

Add station is now in Settings (below Wi-Fi and Time zone), opening station code entry directly. The home top bar keeps only trash and Settings.


## Local sponsor pop-ups (free station-owner pilot)
Owners sign in on the website and choose Manage radio ads. They upload an image, business name, short offer, optional business phone and schedule. Screening and administrator review happen on the server. Every new ad is paused; the owner must choose Start. Owners currently pay nothing and no Stripe account is required.

This firmware requests ads only for the selected station's public station code, using the radio's separate private credential over verified HTTPS. It waits ten uninterrupted listening minutes before showing the first eligible ad and at least thirty minutes between pop-ups. Pop-ups close after eight seconds or with the X. Audio, top-menu controls and volume remain usable. Setup, phone approval, warning screens, standby and an unlit display block sponsor pop-ups. Changing station or losing playback drops the in-flight creative. Ad image transfer and acknowledgements run off the audio/UI loop with bounded time and memory. Older firmware does not request or show ads.

Display counts are authenticated, deduplicated reports from devices; they are not proof a human saw the ad. A paused/deleted ad or a suspended station cannot receive new media grants. An already delivered pop-up may finish briefly. No Google AdSense/AdMob, video, remote advertiser URLs, tracking scripts or payment processing run on the radio.

Before selling radios, disclose that local sponsor messages may appear. Test this complete firmware on the actual display and speakers before release.

## Monthly active-radio preview
This update adds the selected station code to the existing authenticated website poll after at least sixty continuous seconds of playback. Pause, station changes, loss of playback, setup and voice prompts reset the timer. No extra polling connection is created. Server counts are deduplicated once per radio/station/New York calendar month. The owner sees aggregate counts and proposed $0/10, $30/100, $50/300 monthly tiers. Older firmware is not included. No charges, subscription enforcement or playback limits are active. Device reports are not verified people or certified billing measurements.

## Automatic saved-station updates — 2026.11.08.1

Upload this sketch by USB with Erase All Flash disabled. Saved Wi-Fi, volume,
station list and the enrolled radio identity are preserved. Installing a website
update does not install new firmware on the physical radio.

When online, the radio checks revisions for its saved directory station codes
about every five minutes. It downloads new metadata only for changed saved
stations, one request at a time, with time/memory limits and verified HTTPS.
Choosing a saved coded station also schedules a fresh lookup after the existing
two-second interaction quiet period. Network work waits for setup, other network
workers and low-memory conditions to clear; it never downloads the full catalog.

Approved stream-address and logo changes are saved automatically. An updated
active stream address causes a normal reconnect. Logo/name/revision-only changes
and updates to another saved station leave current audio playing. Artwork uses
the approved content-hash URL, so replacement art is fetched without reusing the
old logo's cache entry. Errors keep the last saved data and back off for at least
a minute. Unpublished or missing directory entries do not erase the local list.
Legacy/manual stations without a directory code cannot be matched automatically.

Station revisions are saved with their names, addresses and artwork. Failed
storage rolls all those fields back together. A delayed background result cannot
reinstall a removed station, and different station codes may share one stream
address without being merged. Empty station lists stay empty.
