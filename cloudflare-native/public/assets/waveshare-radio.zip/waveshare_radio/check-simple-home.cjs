const fs=require('fs'),vm=require('vm'),assert=require('assert');
const read=file=>fs.readFileSync(__dirname+'/'+file,'utf8');const touch=read('touch_ui.h'),settingsSource=read('settings_ui.h'),features=read('radio_features.h');
function body(source,signature){let a=source.indexOf(signature);assert(a>=0,signature);a=source.indexOf('{',a);let n=1,b=a+1;while(n){if(source[b]==='{')n++;if(source[b]==='}')n--;b++;}return source.slice(a+1,b-1);}
let status=3,running=true,voices=false;const calls=[];
const c={homePopup:0,stationCount:1,radioMuted:false,simpleHomeMode:true,WiFi:{status:()=>status,scanDelete:()=>calls.push('scan-delete')},WL_CONNECTED:3,wifiAttemptActive:false,wifiStartupScanning:false,safeRecoveryMode:false,uiPaused:false,audioReady:true,stationPending:false,audio:{isRunning:()=>running},voiceBusy:()=>voices,
 uiPage:0,uiPassword:'private-password',uiPasswordVisible:true,uiLocalWifiAttempt:true,uiAwaitingConnection:true,uiScanning:true,uiScanRequested:true,uiVolumeDragging:true,uiDirty:false,changed:false,wakeRadioDisplay(){},esp_wifi_scan_stop:()=>calls.push('scan-stop'),
 openRadioSettings:()=>calls.push('settings'),openAddStationMenu:()=>calls.push('add-menu'),openStationCodePage:()=>calls.push('station-code'),openDeleteStationPage:()=>calls.push('delete'),toggleUiPlayback:()=>calls.push('play-pause'),openRadioLinkPage:()=>calls.push('link'),uiStationChange:v=>calls.push(v),uiVolume:v=>calls.push(v),volumePercent:50,dragVolumePercent:x=>Math.round((x-57)*100/206)};
vm.createContext(c);vm.runInContext('function playbackStatus(){'+body(touch,'const char* homePlaybackStatus(')+'}\nfunction goHome(){'+body(touch,'void backToRadioHome(')+'}',c);
assert.equal(c.playbackStatus(),'Playing');c.radioMuted=true;assert.equal(c.playbackStatus(),'Muted');c.radioMuted=false;running=false;assert.equal(c.playbackStatus(),'Reconnecting');running=true;c.uiPaused=true;assert.equal(c.playbackStatus(),'Paused');c.uiPaused=false;status=0;assert.equal(c.playbackStatus(),'No Wi-Fi');c.wifiAttemptActive=true;assert.equal(c.playbackStatus(),'Reconnecting');c.wifiAttemptActive=false;status=3;
const homeBody=body(touch,'void uiTap(');vm.runInContext('function tapHome(x,y){'+body(homeBody,'if(uiPage==0)')+'}',c);
c.tapHome(50,80);c.tapHome(125,80);assert.equal(calls.length,0,'artwork and station name cannot pause playback');c.tapHome(40,20);assert.equal(calls.length,0,'clock is not hidden settings');
c.tapHome(270,20);c.tapHome(145,20);c.tapHome(200,80);c.tapHome(210,20);assert.deepEqual(calls,['settings','link','delete']);calls.length=0;c.tapHome(60,185);c.tapHome(250,185);assert.equal(calls.length,0,'old action row is now status only');
c.uiPage=2;c.goHome();assert.equal(c.uiPage,0);assert.equal(c.uiPassword,'');assert(!c.uiScanning&&!c.uiScanRequested&&!c.uiVolumeDragging);assert.deepEqual(calls,['scan-stop','scan-delete']);
const stored={};let canSave=true;const prefs={begin:()=>true,end(){},putBool:(key,value)=>{if(canSave)stored[key]=value;return canSave?1:0},getBool:(key,fallback)=>stored[key]??fallback};
const p={simpleHomeMode:true,prefs};vm.createContext(p);vm.runInContext('function save(){'+body(features,'bool saveRadioUiSettings(').replace('Preferences p;','const p=prefs;').replace('bool ok=','let ok=')+'}\nfunction load(){'+body(features,'void loadRadioUiSettings(').replace('Preferences p;','const p=prefs;')+'}',p);
p.load();assert(p.simpleHomeMode,'new devices default to Simple');p.simpleHomeMode=false;assert(p.save());p.simpleHomeMode=true;p.load();assert(p.simpleHomeMode,'Simple layout always loads, including previously saved code layout');canSave=false;assert(!p.save());
const header=body(touch,'void drawHomeHeader(');assert(!header.includes('"%"'));assert(!header.includes('String("~")'));
for(const [source,signature] of [[touch,'void uiDrawWifi('],[touch,'void uiDrawKeyboard('],[settingsSource,'void drawFeaturePage('],[read('station_code_ui.h'),'void drawStationCodePage(']])assert(body(source,signature).includes('Back to radio'),signature);
assert(settingsSource.includes('"Wi-Fi"')&&settingsSource.includes('"Time zone"'));assert(touch.includes('&FreeSans12pt7b'));
assert(!header.includes('wifiLabel'));assert(!header.includes('Pause'));assert(!header.includes('compactHomeLinkLabel()'));assert(!header.includes('Pause'));assert(!header.includes('compactHomeLinkLabel()'));assert(!settingsSource.includes('Home:'));assert(touch.includes('drawHomeArt(8,42,112)'));
console.log('PASS: Compact home code and enlarged art; fixed Simple layout and saved layout choice; real home tap routing ignores art/clock, direct Add station and confirmed deletion controls, plain statuses, unified settings, clear battery icon and Back to radio on every settings screen.');

vm.runInContext('function hour12(hour){'+body(touch,'int radioHour12(')+'}',c);assert.equal(c.hour12(0),12);assert.equal(c.hour12(12),12);assert.equal(c.hour12(13),1);assert.equal(c.hour12(23),11);
assert(header.includes('"AM":"PM"')&&!header.includes('%H:%M'));
for(const [source,signature] of [[settingsSource,'void drawDeleteStationPage('],[read('radio_link.h'),'void drawRadioLinkPage(']]){const popup=body(source,signature);assert(!popup.includes('fillScreen'));assert(popup.includes('"Exit"'));}
assert(touch.includes('"Live on the Air"'));assert(touch.includes('53,208,214,14'));assert(touch.includes('215,11,UI_WHITE'));assert(touch.includes('else if(homePopup==8)drawDeleteStationPage()'));
console.log('PASS: 12-hour clock handles midnight/noon/afternoon, modal delete/code panels have Exit, and live decoration uses a thicker slider.');

const homeDrawing=body(touch,'void drawStation(');assert(homeDrawing.includes('160,132,124,24'));assert(header.includes('198,4,28,32'));assert(!homeDrawing.includes('"Delete station"'));assert(header.includes('205,15,14,15'));
calls.length=0;c.tapHome(200,135);c.tapHome(254,160);assert.equal(calls.length,0,'small status badge and button gap do not delete or open entry');
console.log('PASS: smaller status badge sits under the name, Add opens directly, and icon-only trash still opens confirmation.');

assert(!body(touch,'void drawHomeHeader(').includes('"Add station"'));
assert(settingsSource.includes('setupButton(8,127,304,42,"Add station"'));
const settings={uiPage:3,uiDirty:false,zonePage:0,openStationCodePage:()=>calls.push('station-code'),backToRadioHome(){},uiOpenWifi(){}};
vm.createContext(settings);vm.runInContext('function tap(x,y){'+body(settingsSource,'void tapFeaturePage(').replace('int index=','let index=')+'}',settings);
calls.length=0;settings.tap(150,145);assert.deepEqual(calls,['station-code'],'Settings Add station opens code entry directly');
