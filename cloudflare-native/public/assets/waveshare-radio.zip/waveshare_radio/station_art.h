#pragma once
#include "pngle.h"
struct ArtDecode {
  uint16_t* pixels; unsigned width,height,dw,dh; bool done=false;
};
void artDrawPixel(pngle_t* decoder,uint32_t x,uint32_t y,uint32_t w,uint32_t h,const uint8_t* pixel) {
  auto* d=(ArtDecode*)pngle_get_user_data(decoder);
  unsigned left=(x*d->dw+d->width-1)/d->width;
  unsigned right=((x+w)*d->dw+d->width-1)/d->width;
  unsigned top=(y*d->dh+d->height-1)/d->height;
  unsigned bottom=((y+h)*d->dh+d->height-1)/d->height;
  unsigned a=pixel[3];
  unsigned r=(pixel[0]*a+8*(255-a))/255, g=(pixel[1]*a+12*(255-a))/255;
  unsigned b=(pixel[2]*a+40*(255-a))/255;
  uint16_t color=((r>>3)<<11)|((g>>2)<<5)|(b>>3);
  for(unsigned yy=top;yy<min(bottom,d->dh);++yy)
    for(unsigned xx=left;xx<min(right,d->dw);++xx)
      d->pixels[(yy+(160-d->dh)/2)*160+xx+(160-d->dw)/2]=color;
}
void artDecodeDone(pngle_t* decoder) { ((ArtDecode*)pngle_get_user_data(decoder))->done=true; }
struct StationArt { String url; uint16_t* pixels=nullptr; };
StationArt artCache[3];
QueueHandle_t artResults=nullptr;
bool artWorkerBusy=false;
String artAttemptUrl;
uint32_t artAttemptAt=0;
int artNextSlot=0;
String stationLogoUrls[MAX_STATIONS] = {"/static/logos/radiolavoixdivine.png", ""};

String allowedArtUrl(const String& url) {
  if(url.length()>512)return "";
  if(url=="/static/logos/radiolavoixdivine.png")return String(RADIO_SERVICE_ORIGIN)+"/assets/radiolavoixdivine.png";
  String path=url;
  if(path.startsWith(RADIO_SERVICE_ORIGIN))path=path.substring(strlen(RADIO_SERVICE_ORIGIN));
  if(path=="/assets/radiolavoixdivine.png")return String(RADIO_SERVICE_ORIGIN)+path;
  if(!path.startsWith("/artwork/")||path.length()!=77||!path.endsWith(".png"))return "";
  for(unsigned i=9;i<73;i++)if(!isxdigit((unsigned char)path[i]))return "";
  return String(RADIO_SERVICE_ORIGIN)+path;
}
uint16_t* currentStationArt() {
  String url=allowedArtUrl(stationLogoUrls[selected]);
  for(auto& entry:artCache) if(entry.pixels && entry.url==url) return entry.pixels;
  return nullptr;
}
void fetchStationArt(void* argument) {
  StationArt* result=(StationArt*)argument;
  uint8_t* encoded=nullptr;
  do {
    DeadlineStationClient client;
    client.setCACert(WEBSITE_ROOT_CA); client.setHandshakeTimeout(5); client.setTimeout(1000);
    HTTPClient http; http.useHTTP10(true); http.setConnectTimeout(4000); http.setTimeout(1000);
    if(!http.begin(client,result->url)) break;
    if(http.GET()!=HTTP_CODE_OK) { http.end(); break; }
    constexpr size_t CAP=2*1024*1024;
    int expected=http.getSize();
    if(expected>int(CAP) || expected==0) { http.end(); break; }
    encoded=(uint8_t*)heap_caps_malloc(CAP,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    if(!encoded) { http.end(); break; }
    auto& stream=http.getStream(); size_t used=0; uint32_t started=millis();
    while(used<CAP && millis()-started<12000) {
      int available=stream.available();
      if(available>0) {
        size_t wanted=min(size_t(available),min(size_t(1024),CAP-used));
        int count=stream.read(encoded+used,wanted);
        if(count>0) used+=count;
      } else if(!stream.connected()) break;
      if(expected>0 && used==size_t(expected)) break;
      delay(1);
    }
    http.end();
    if(!used || used>=CAP || millis()-started>=12000 || (expected>0 && used!=size_t(expected))) break;
    const uint8_t signature[]={137,80,78,71,13,10,26,10};
    if(used<33 || memcmp(encoded,signature,8) || memcmp(encoded+12,"IHDR",4)) break;
    auto be32=[](const uint8_t* p)->uint32_t { return (uint32_t(p[0])<<24)|(uint32_t(p[1])<<16)|(uint32_t(p[2])<<8)|p[3]; };
    unsigned w=be32(encoded+16),h=be32(encoded+20);
    if(!w || !h || w>2048 || h>2048 || uint64_t(w)*h>2000000) break;
    result->pixels=(uint16_t*)heap_caps_malloc(160*160*2,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    if(!result->pixels) break;
    // Contain the whole logo without cropping; composite transparency over navy.
    unsigned dw=160,dh=160;
    if(w>h) dh=max(1u,160*h/w); else dw=max(1u,160*w/h);
    for(int i=0;i<160*160;++i) result->pixels[i]=UI_BG;
    ArtDecode context={result->pixels,w,h,dw,dh,false};
    pngle_t* decoder=pngle_new();
    if(!decoder) { heap_caps_free(result->pixels); result->pixels=nullptr; break; }
    pngle_set_user_data(decoder,&context); pngle_set_draw_callback(decoder,artDrawPixel);
    pngle_set_done_callback(decoder,artDecodeDone);
    size_t offset=0; uint32_t decodeStarted=millis();
    while(offset<used && millis()-decodeStarted<15000) {
      size_t available=min(size_t(4096),used-offset);
      int consumed=pngle_feed(decoder,encoded+offset,available);
      if(consumed<=0) break;
      offset+=consumed; delay(1);
    }
    pngle_destroy(decoder);
    if(!context.done) { heap_caps_free(result->pixels); result->pixels=nullptr; }
  } while(false);
  heap_caps_free(encoded);
  if(xQueueSend(artResults,&result,0)!=pdTRUE) { heap_caps_free(result->pixels); delete result; }
  vTaskDelete(nullptr);
}
void serviceStationArt() {
  if(!artResults) artResults=xQueueCreate(1,sizeof(StationArt*));
  if(!artResults) return;
  StationArt* result=nullptr;
  if(xQueueReceive(artResults,&result,0)==pdTRUE) {
    artWorkerBusy=false;
    if(result) {
      if(result->pixels) {
        auto& entry=artCache[artNextSlot++%3]; heap_caps_free(entry.pixels);
        entry.url=result->url; entry.pixels=result->pixels; changed=true;
      }
      delete result;
    }
  }
  if(artWorkerBusy || syncTaskHandle || portalActive || uiPage || !radioOn ||
     WiFi.status()!=WL_CONNECTED || time(nullptr)<1700000000 ||
     ESP.getFreeHeap()<70000 || currentStationArt()) return;
  String url=allowedArtUrl(stationLogoUrls[selected]);
  if(url.isEmpty() || (url==artAttemptUrl && millis()-artAttemptAt<60000)) return;
  artAttemptUrl=url; artAttemptAt=millis();
  auto* job=new(std::nothrow) StationArt;
  if(!job) return;
  job->url=url; artWorkerBusy=true;
  if(xTaskCreate(fetchStationArt,"station-logo",8192,job,1,nullptr)!=pdPASS) {
    artWorkerBusy=false; delete job;
  }
}
