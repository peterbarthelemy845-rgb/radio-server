#pragma once
#include <Fonts/FreeSans9pt7b.h>
#include <Fonts/FreeSans12pt7b.h>
#include <esp_wifi.h>
// All Wi-Fi and touch state stays on the Arduino loop task.
struct UiNetwork { String name; bool open; };
constexpr int MAX_UI_NETWORKS=64;
UiNetwork uiNetworks[MAX_UI_NETWORKS];
int uiNetworkCount=0, uiNetworkOffset=0;
bool uiScanning=false, uiScanRequested=false, uiPasswordVisible=false;
bool uiPassiveScan=false;
bool uiUpper=false, uiSymbols=false, uiEditingSsid=false;
bool uiTouchHeld=false, uiPortalWasActive=false;
bool uiAwaitingConnection=false;
bool uiVolumeDragging=false;
uint32_t uiScanStarted=0, uiPollAt=0, uiTouchLastSeen=0;
String uiSsid, uiPassword, uiError, uiMessageTitle, uiMessageDetail;
const char *uiRowsLower[] = {"qwertyuiop", "asdfghjkl", "zxcvbnm"};
const char *uiRowsUpper[] = {"QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM"};
const char *uiRowsSymbols[] = {"1234567890", "!@#$%^&*()", "-_=+[]{}\\|"};
const char *uiRowsMore[] = {"`~;:'\",.<>", "/?", ""};
int uiSymbolPage=0;

void uiText(const String& text,int x,int y,int size=1,uint16_t color=UI_WHITE) {
  screen.setTextColor(color); screen.setTextSize(size); screen.setCursor(x,y); screen.print(text);
}
void uiCenter(const String& text,int y,int size=1,uint16_t color=UI_WHITE) {
  uiText(text,max(2,(320-int(text.length())*6*size)/2),y,size,color);
}
String uiShort(String text,int limit) {
  // Built-in GFX font is ASCII. Do not show broken UTF-8 sequences.
  String clean;
  for (unsigned i=0;i<text.length();++i) if (uint8_t(text[i])>=32 && uint8_t(text[i])<127) clean+=text[i];
  if (clean.length()>unsigned(limit)) clean=clean.substring(0,limit-1)+"~";
  return clean;
}
void uiButton(int x,int y,int w,int h,const String& label,uint16_t color=UI_PANEL) {
  screen.fillRoundRect(x,y,w,h,7,color);
  uiText(label,x+max(2,(w-int(label.length())*6)/2),y+(h-8)/2);
}
void wifiMessage(const char* title,const char* detail) {
  uiMessageTitle=title; uiMessageDetail=detail; uiDirty=true;
  // Network progress belongs in the home header, never a full-screen takeover.
  changed=true;
}
void uiStationChange(int direction) {
  if (stationCount<1) return;
  selected=(selected+direction+stationCount)%stationCount;
  safeRecoveryMode=false; uiPaused=false; playbackRecovery.reset(); stationPending=true;
  lastTransition=millis(); changed=true;
}
void uiVolume(int value) {
  volumePercent=constrain(value,0,100);
  radioMuted=false; applyRadioOutputVolume();
  changed=true;
}
void uiPrettyCenter(String text,int baseline,const GFXfont* font,uint16_t color=UI_WHITE) {
  screen.setFont(font); screen.setTextSize(1); screen.setTextColor(color);
  int16_t x,y; uint16_t w,h;
  screen.getTextBounds(text,0,0,&x,&y,&w,&h);
  while(w>300 && text.length()>3) {
    text.remove(text.length()-1); screen.getTextBounds(text+"~",0,0,&x,&y,&w,&h);
  }
  screen.setCursor((320-w)/2-x,baseline); screen.print(text);
  screen.setFont(nullptr);
}

void backToRadioHome() {
 uiPage=0;homePopup=0;uiPassword="";uiPasswordVisible=false;uiLocalWifiAttempt=false;uiAwaitingConnection=false;
 if(uiScanning){esp_wifi_scan_stop();WiFi.scanDelete();uiScanning=false;}
 uiScanRequested=false;uiVolumeDragging=false;uiDirty=true;changed=true;wakeRadioDisplay();
}
void openAddStationMenu() {wakeRadioDisplay();uiPage=7;uiDirty=true;}
void toggleUiPlayback() {
 if(uiPaused || safeRecoveryMode){uiPaused=false;safeRecoveryMode=false;playbackRecovery.reset();stationPending=true;}
 else{uiPaused=true;cancelVoicePrompts();if(audioReady)audio.stopSong();}
 changed=true;
}
const char* homePlaybackStatus() {
 if(stationCount==0)return "Add a station";
 if(WiFi.status()!=WL_CONNECTED)return (wifiAttemptActive||wifiStartupScanning)?"Reconnecting":"No Wi-Fi";
 if(safeRecoveryMode)return "Press Play";
 if(uiPaused)return "Paused";
 if(radioMuted)return "Muted";
 if(!audioReady || stationPending || !audio.isRunning() || voiceBusy())return "Reconnecting";
 return "Playing";
}
bool radioApprovalPopupVisible();
void drawRadioApprovalPopup();
void tapRadioApprovalPopup(int x,int y);
String compactHomeLinkLabel();
int radioHour12(int hour) {return hour%12?hour%12:12;}
void drawHomeHeader() {
 time_t now=time(nullptr);struct tm clock;char label[8]="--:--";char meridiem[3]="";
 if(now>1700000000 && localtime_r(&now,&clock)){snprintf(label,sizeof(label),"%d:%02d",radioHour12(clock.tm_hour),clock.tm_min);snprintf(meridiem,sizeof(meridiem),"%s",clock.tm_hour<12?"AM":"PM");}
 uiText(String(label),6,12,1,UI_WHITE);uiText(meridiem,38,12,1,UI_WHITE);
 uint16_t batteryColor=batteryPercent>=0&&batteryPercent<=15?0xF800:UI_WHITE;
 screen.drawRoundRect(54,10,18,10,2,batteryColor);screen.fillRect(72,13,2,4,batteryColor);
 if(batteryPercent<0)uiText("?",60,11,1,batteryColor);
 else{int bars=constrain((batteryPercent+24)/25,0,4);for(int i=0;i<bars;++i)screen.fillRect(56+i*4,12,2,6,batteryColor);}
 screen.fillRoundRect(198,4,28,32,6,0xC800);
 screen.drawRoundRect(205,15,14,15,2,UI_WHITE);screen.fillRect(203,12,18,2,UI_WHITE);screen.drawRoundRect(209,8,6,4,1,UI_WHITE);
 for(int x=209;x<=215;x+=3)screen.drawLine(x,18,x,26,UI_WHITE);
 screen.fillRoundRect(230,4,82,32,6,UI_PANEL);uiText("Settings",236,15,1,UI_WHITE);
 for(int i=0;i<8;++i){float angle=i*0.785398f;int dx=int(cosf(angle)*9),dy=int(sinf(angle)*9);screen.drawLine(298+dx,18+dy,298+dx*12/9,18+dy*12/9,UI_WHITE);}
 screen.drawCircle(298,18,7,UI_WHITE);screen.drawCircle(298,18,3,UI_WHITE);
}
void drawHomeArt(int x,int y,int size) {
 uint16_t* art=currentStationArt();
 if(!art){screen.fillRoundRect(x,y,size,size,8,UI_PANEL);return;}
 for(int row=0;row<size;++row){int edge=row<5?5-row:row>size-6?row-(size-6):0;
  for(int col=edge;col<size-edge;++col)screen.drawPixel(x+col,y+row,art[(row*160/size)*160+col*160/size]);}
}
void drawLargeStationName(int x,int top,int width) {
 String rest=stationCount?uiShort(stations[selected],64):"No stations";rest.trim();
 screen.setFont(&FreeSans12pt7b);screen.setTextSize(1);screen.setTextColor(UI_WHITE);
 for(int line=0;line<2 && rest.length();++line){
  int fit=0,space=-1;int16_t bx,by;uint16_t w,h;
  for(unsigned i=1;i<=rest.length();++i){screen.getTextBounds(rest.substring(0,i),0,0,&bx,&by,&w,&h);if(w>width)break;fit=i;if(rest[i-1]==' ')space=i-1;}
  if(!fit)break;
  bool more=fit<int(rest.length());
  if(line==0 && more && space>0)fit=space;
  String text=rest.substring(0,fit);text.trim();
  if(line==1 && more){while(text.length()>1){screen.getTextBounds(text+"...",0,0,&bx,&by,&w,&h);if(w<=width)break;text.remove(text.length()-1);}text+="...";}
  screen.getTextBounds(text,0,0,&bx,&by,&w,&h);screen.setCursor(x-bx,top+22+line*28);screen.print(text);
  rest=rest.substring(fit);rest.trim();
 }
 screen.setFont(nullptr);
}

void openDeleteStationPage();
void drawDeleteStationPage();
void tapDeleteStationPage(int x,int y);
String compactHomeLinkLabel();
void drawStation() {
 if(!screenReady || uiPage!=0 || !radioOn || onNoticeActive)return;
 screen.clearDisplay();drawHomeHeader();
 const char* status=homePlaybackStatus();bool offline=WiFi.status()!=WL_CONNECTED;
 drawHomeArt(8,42,112);
 String stationName=stationCount?uiShort(stations[selected],18):"No stations";
 uiText(stationName,8+max(0,(112-int(stationName.length())*6)/2),162,1,UI_WHITE);
 String deviceCode=compactHomeLinkLabel();
 if(deviceCode.length()){
  uiText("Device Code",142,52,2,UI_SKY);int codeSize=deviceCode.length()>6?2:4;
  uiText(deviceCode,132+max(0,(180-int(deviceCode.length())*6*codeSize)/2),80,codeSize,UI_WHITE);
 }
 bool live=strcmp(status,"Playing")==0;
 const char* caption=live?"Live on the Air":status;
 screen.fillRoundRect(160,132,124,24,7,offline?0xC800:UI_PANEL);screen.drawRoundRect(160,132,124,24,7,offline?0xF800:UI_SKY);
 uiText(caption,160+max(2,(124-int(strlen(caption))*6)/2),140,1,UI_WHITE);
 if(live){const int heights[5]={4,8,16,8,4};for(int i=0;i<5;++i){screen.fillRoundRect(135+i*4,144-heights[i]/2,2,heights[i],1,UI_SKY);screen.fillRoundRect(290+i*4,144-heights[i]/2,2,heights[i],1,UI_SKY);}}
 screen.fillCircle(25,215,19,UI_BLUE);screen.fillCircle(295,215,19,UI_BLUE);
 screen.fillRect(17,214,16,3,UI_WHITE);screen.fillRect(287,214,16,3,UI_WHITE);screen.fillRect(294,207,3,17,UI_WHITE);
 screen.fillRoundRect(53,208,214,14,7,UI_MUTED);int thumb=53+214*volumePercent/100;
 if(volumePercent)screen.fillRoundRect(53,208,thumb-53,14,7,UI_SKY);
 screen.fillCircle(thumb,215,11,UI_WHITE);screen.fillCircle(thumb,215,9,UI_SKY);
 if(radioApprovalPopupVisible())drawRadioApprovalPopup();
 else if(homePopup==8)drawDeleteStationPage();
 else if(homePopup==6)drawRadioLinkPage();
 else if(sponsorPopupVisible())drawSponsorPopup();
 screen.display();
}
constexpr uint16_t SETUP_BG=0xFFFF, SETUP_INK=0x1084, SETUP_KEY=0xE71C,
  SETUP_MUTED=0x6B4D, SETUP_DISABLED=0xD69A;
constexpr int NETWORK_ROWS=3;
void setupButton(int x,int y,int w,int h,const String& text,bool primary=false,bool enabled=true,int size=1) {
  screen.fillRoundRect(x,y,w,h,6,!enabled?SETUP_DISABLED:primary?UI_BLUE:SETUP_KEY);
  uiText(text,x+max(1,(w-int(text.length())*6*size)/2),y+(h-8*size)/2,size,
    !enabled?SETUP_MUTED:primary?UI_WHITE:SETUP_INK);
}
bool uiHasNextNetworks() { return uiNetworkOffset+NETWORK_ROWS<uiNetworkCount; }
void uiChangeNetworkPage(int direction) {
  if(direction<0) uiNetworkOffset=max(0,uiNetworkOffset-NETWORK_ROWS);
  else if(uiHasNextNetworks()) uiNetworkOffset+=NETWORK_ROWS;
  uiDirty=true;
}
void uiStartScan() {
  if (wifiAttemptActive || wifiStartupScanning || uiScanning) return;
  WiFi.scanDelete();
  uiPassiveScan=false; uiNetworkCount=0; uiNetworkOffset=0;
  // All permitted 2.4 GHz channels, hidden SSIDs included, no auth filter.
  int result=WiFi.scanNetworks(true,true,false,400,0);
  uiScanning=result==WIFI_SCAN_RUNNING;
  uiScanStarted=millis(); uiScanRequested=false;
  if (!uiScanning) uiError="Scan unavailable. Try again.";
  uiDirty=true;
}
void uiRememberNetwork(const String& name,bool open) {
  if(name.isEmpty() || name=="Radio-Setup") return;
  for(int j=0;j<uiNetworkCount;++j)
    if(uiNetworks[j].name==name && uiNetworks[j].open==open) return;
  if(uiNetworkCount<MAX_UI_NETWORKS) uiNetworks[uiNetworkCount++]={name,open};
}
void uiOpenWifi(bool userInitiated=true) {
  wakeRadioDisplay(); uiPage=1; uiDirty=true; uiError="";
  uiAwaitingConnection=false;
  if(!wifiAttemptActive) portalState="ready";
  uiNetworkOffset=0; uiScanRequested=true;
  // Keep automatic retries from interrupting an active setup form.
  if(userInitiated) {
    portalShouldRetrySaved=false;
    if(!uiLocalWifiAttempt && (wifiAttemptActive || wifiStartupScanning)) {
      wifiAttemptActive=false; wifiStartupScanning=false;
      WiFi.scanDelete(); WiFi.disconnect(false,false); portalState="ready";
    }
  }
}
void uiDrawWifi() {
  screen.fillScreen(SETUP_BG); uiCenter("Wi-Fi setup",7,2,SETUP_INK);
  setupButton(8,32,145,30,"Scan");setupButton(163,32,149,30,"Type name");
  uiCenter(uiError.length()?uiShort(uiError,49):uiScanning?"Scanning...":wifiAttemptActive?"Connecting...":"Tap your Wi-Fi network below",67,1,uiError.length()?0xB800:SETUP_MUTED);
  for(int row=0;row<NETWORK_ROWS;++row) {
    int index=uiNetworkOffset+row; if(index>=uiNetworkCount) break;
    setupButton(8,83+row*26,304,24,"");
    uiText(uiShort(uiNetworks[index].name,uiNetworks[index].open?41:48),16,91+row*26,1,SETUP_INK);
    if(uiNetworks[index].open) uiText("OPEN",280,91+row*26,1,SETUP_MUTED);
  }
  setupButton(8,164,80,26,"Previous",false,uiNetworkOffset>0);
  uiText(String(uiNetworkCount?uiNetworkOffset/NETWORK_ROWS+1:0)+" / "+String((uiNetworkCount+NETWORK_ROWS-1)/NETWORK_ROWS),120,174,1,SETUP_MUTED);
  setupButton(204,164,108,26,uiHasNextNetworks()?"More networks":"Last page",false,uiHasNextNetworks());
  if(!uiNetworkCount && !uiScanning) uiCenter("No networks. Tap Scan or Type name.",121,1,SETUP_INK);
  setupButton(8,194,304,40,"Back to radio",false,true,2);
  screen.display();
}
const char* uiKeyboardRow(int row) {
  if(uiSymbols) return uiSymbolPage?uiRowsMore[row]:uiRowsSymbols[row];
  return uiUpper?uiRowsUpper[row]:uiRowsLower[row];
}
void uiDrawKeyboard() {
  screen.fillScreen(SETUP_BG);
  uiText(uiEditingSsid?"Wi-Fi name":"Password",8,12,2,SETUP_INK);
  setupButton(150,0,162,40,"Back to radio",false,true,2);
  screen.drawRoundRect(5,43,310,26,5,SETUP_MUTED);
  String value=uiEditingSsid?uiSsid:uiPassword;
  if(!uiEditingSsid && !uiPasswordVisible) { value=""; for(unsigned i=0;i<uiPassword.length();++i) value+='*'; }
  if(value.length()>24) value=value.substring(value.length()-24);
  uiText(value,11,49,2,SETUP_INK);
  setupButton(5,70,65,27,"Networks");
  setupButton(75,70,75,27,uiEditingSsid?"Name":uiPasswordVisible?"Hide":"Show");
  setupButton(155,70,160,27,uiEditingSsid?"Next: password":"Connect",true,!wifiAttemptActive);
  uiText(uiShort(wifiAttemptActive?"Connecting...":uiError.length()?uiError:uiSsid,50),5,101,1,0xB800);
  for(int row=0;row<3;++row) {
    const char* keys=uiKeyboardRow(row); int count=strlen(keys),left=(320-count*32)/2;
    for(int col=0;col<count;++col) setupButton(left+col*32,114+row*27,31,25,String(keys[col]),false,true,2);
  }
  setupButton(0,199,54,33,uiSymbols?"ABC":uiUpper?"CAPS":"Shift");
  setupButton(57,199,50,33,uiSymbols?(uiSymbolPage?"123":"More"):"123");
  setupButton(110,199,104,33,"Space");
  setupButton(217,199,103,33,"Backspace",true);
  screen.display();
}
bool uiValidPassword(const String& password) {
  if(password.isEmpty()) return true;
  if(password.length()>=8 && password.length()<=63) return true;
  if(password.length()!=64) return false;
  for(unsigned i=0;i<64;++i) if(!isxdigit((unsigned char)password[i])) return false;
  return true;
}
void uiSubmitWifi() {
  if(wifiAttemptActive) return;
  if(uiSsid.isEmpty() || uiSsid.length()>32) { uiError="Name must be 1-32 bytes"; return; }
  if(!uiValidPassword(uiPassword)) { uiError="Use 8-63 chars, or empty for open"; return; }
  // Stop scanning before attempting a connection; never log the password.
  if(uiScanning) esp_wifi_scan_stop();
  WiFi.scanDelete(); uiScanning=false; uiScanRequested=false;
  portalShouldRetrySaved=false; wifiStartupScanning=false;
  wifiCredentialsSubmitted=false;
  if(audioReady) audio.stopSong();
  cancelVoicePrompts(); queueVoicePrompt("/connecting.mp3");
  wifiAttemptSsid=uiSsid; wifiAttemptPassword=uiPassword;
  wifiAttemptActive=true; wifiAttemptFromPortal=true; wifiAttemptStarted=millis();
  uiLocalWifiAttempt=true;
  uiAwaitingConnection=true;
  portalState="connecting"; portalConnectedAt=0;
  WiFi.disconnect(false,false);
  // Only rememberWorkingWifi() persists credentials after WL_CONNECTED.
  WiFi.persistent(false);
  WiFi.begin(wifiAttemptSsid.c_str(),wifiAttemptPassword.isEmpty()?nullptr:wifiAttemptPassword.c_str());
  uiError="Connecting..."; uiDirty=true;
}
void uiKeyboardControl(int key) {
  String& value=uiEditingSsid?uiSsid:uiPassword;
  if(key==0) { if(uiSymbols) uiSymbols=false; else uiUpper=!uiUpper; }
  else if(key==1) { if(uiSymbols) uiSymbolPage=!uiSymbolPage; else { uiSymbols=true; uiSymbolPage=0; } }
  else if(key==2) { if(value.length()<unsigned(uiEditingSsid?32:64)) value+=' '; }
  else if(value.length()) value.remove(value.length()-1);
  uiError=""; if(portalState=="failed") portalState="ready"; uiDirty=true;
}
void uiTap(int x,int y) {
  if(sponsorPopupVisible() && y>=37 && y<193){tapSponsorPopup(x,y);return;}
  if(radioApprovalPopupVisible()){tapRadioApprovalPopup(x,y);return;}
  if(homePopup==8){tapDeleteStationPage(x,y);return;}
  if(homePopup==6){tapRadioLinkPage(x,y);return;}
  if(uiPage==8){tapDeleteStationPage(x,y);return;}
  if(uiPage==6) {tapRadioLinkPage(x,y);return;}
  if(uiPage==5) {tapStationCodePage(x,y);return;}
  if(uiPage>=3) {tapFeaturePage(x,y);return;}
  if(uiPage==0) {
    if(y<39 && x>=230){openRadioSettings();return;}
    if(y>=44 && y<124 && x>=132 && x<312){openRadioLinkPage();return;}
    if(y>=4 && y<36 && x>=198 && x<226){openDeleteStationPage();return;}
    if(y>=43 && y<=189){if(x<9)uiStationChange(-1);else if(x>310)uiStationChange(1);return;}
    if(y>=197 && y<240) {
      if(x<47) uiVolume(volumePercent-5);
      else if(x>=273) uiVolume(volumePercent+5);
      else if(x>=47 && x<273) uiVolume(dragVolumePercent(x));
    }
  } else if(uiPage==1) {
    if(y>=194){backToRadioHome();return;}
    if(wifiAttemptActive) return;
    if(y>=32 && y<61) {
      if(x<158) uiScanRequested=true;
      else { portalShouldRetrySaved=false; uiSsid=""; uiPassword=""; uiEditingSsid=true; uiPage=2; uiError=""; }
    } else if(y>=83 && y<161) {
      int index=uiNetworkOffset+(y-83)/26;
      if(index<uiNetworkCount) {
        portalShouldRetrySaved=false; uiSsid=uiNetworks[index].name; uiPassword="";
        uiEditingSsid=false; uiPasswordVisible=false; uiPage=2; uiError="";
        portalState="ready";
      }
    } else if(y>=164 && y<190) {
      if(x<90) uiChangeNetworkPage(-1);
      if(x>=204) uiChangeNetworkPage(1);
    }
    uiDirty=true;
  } else {
    if(y<40 && x>=150){backToRadioHome();return;}
    if(wifiAttemptActive) return;
    if(y>=70 && y<98) {
      if(x<70) { uiPage=1; uiPassword=""; uiError=""; }
      else if(x<152) { if(!uiEditingSsid) uiPasswordVisible=!uiPasswordVisible; }
      else if(uiEditingSsid) {
        if(uiSsid.isEmpty()) uiError="Enter your network name first";
        else { uiEditingSsid=false; uiError=""; }
      } else uiSubmitWifi();
    } else if(y>=114 && y<195) {
      int row=(y-114)/27; const char* keys=uiKeyboardRow(row);
      int count=strlen(keys),left=(320-count*32)/2,col=(x-left)/32;
      if(x>=left && col>=0 && col<count) {
        String& value=uiEditingSsid?uiSsid:uiPassword;
        if(value.length()<unsigned(uiEditingSsid?32:64)) value+=keys[col];
        uiError=""; if(portalState=="failed") portalState="ready";
      }
    } else if(y>=199 && y<233) {
      uiKeyboardControl(x<55?0:x<108?1:x<215?2:3);
    }
    uiDirty=true;
  }
}
void serviceTouchUi() {
  static uint32_t offlineSince=0;
  if(WiFi.status()==WL_CONNECTED) { offlineSince=0; wifiNoticeSpoken=false; }
  else if(radioOn && !wifiAttemptActive && !wifiStartupScanning) {
    if(!offlineSince) offlineSince=millis();
    if(millis()-offlineSince>=5000 && !wifiNoticeSpoken) {
      queueVoicePrompt("/setup.mp3"); wifiNoticeSpoken=true;
    }
  } else offlineSince=0;
  if(!screenReady) return;
  // The setup AP may run in the background; only a user tap opens local setup.
  uiPortalWasActive=portalActive;
  if((uiPage==1 || uiPage==2) && wifiAttemptActive) uiAwaitingConnection=true;
  if((uiPage==1 || uiPage==2) && uiAwaitingConnection && !wifiAttemptActive && WiFi.status()==WL_CONNECTED && portalState=="connected") {
    uiAwaitingConnection=false;
    uiPassword=""; uiPage=0; uiScanning=false; WiFi.scanDelete();
    // Keep the phone portal alive for its normal ten-second success notice.
    wakeRadioDisplay(); screen.fillScreen(SETUP_BG); uiCenter("Wi-Fi connected!",95,2,SETUP_INK);
    uiCenter("Your radio is ready",130,1,SETUP_INK); screen.display();
    onNoticeActive=true; onNoticeStarted=millis(); changed=true;
  }
  if((uiPage==1 || uiPage==2) && portalState=="failed" && !wifiAttemptActive) {
    if(uiError!="Connection failed. Check password.") { uiError="Connection failed. Check password."; uiDirty=true; }
  }
  if(uiScanRequested && !wifiAttemptActive && !wifiStartupScanning) uiStartScan();
  if(uiScanning) {
    int count=WiFi.scanComplete();
    if(count>=0) {
      for(int i=0;i<count && i<256;++i)
        uiRememberNetwork(WiFi.SSID(i),WiFi.encryptionType(i)==WIFI_AUTH_OPEN);
      WiFi.scanDelete(); uiError="";
      // Listen for beacons as a second pass; merge, rather than discard,
      // open networks and hotspots found by either scan.
      if(!uiPassiveScan) {
        uiPassiveScan=true;
        uiScanning=WiFi.scanNetworks(true,true,true,350,0)==WIFI_SCAN_RUNNING;
        uiScanStarted=millis();
      } else uiScanning=false;
      uiDirty=true;
    } else if(count==WIFI_SCAN_FAILED || millis()-uiScanStarted>12000) {
      esp_wifi_scan_stop(); WiFi.scanDelete(); uiScanning=false;
      uiError=uiNetworkCount?"Scan incomplete. Tap Scan to retry.":"Scan failed. Try Scan again."; uiDirty=true;
    }
  }
  if(millis()-uiPollAt>=20) {
    uiPollAt=millis();
    uint16_t x[5]={},y[5]={},strength[5]={}; uint8_t count=0;
    bool received=Touch_Read_Data();
    bool down=received && Touch_Get_XY(x,y,strength,&count,5) && count && x[0]<240 && y[0]<320;
    if(down) {
      int tx=319-y[0],ty=x[0]; // Match the 180-degree display flip.
      uiTouchLastSeen=millis();
      if(uiTouchHeld && uiVolumeDragging && !homePopup && !radioApprovalPopupVisible() && uiPage==0 && radioOn && !onNoticeActive) {
        uiVolume(dragVolumePercent(tx));
      }
      if(!uiTouchHeld) {
        uiTouchHeld=true;
        uiVolumeDragging=radioOn && !homePopup && !radioApprovalPopupVisible() && uiPage==0 && !onNoticeActive && ty>=197 && ty<240 && tx>=47 && tx<273;
        if(!radioOn && !portalActive) {
          radioOn=true; safeRecoveryMode=false; uiPaused=false; playbackRecovery.reset();
          showRadioOn(); stationPending=true; changed=true;
        } else if(!onNoticeActive) uiTap(tx,ty);
      }
    } else if(millis()-uiTouchLastSeen>100) {uiTouchHeld=false;uiVolumeDragging=false;}
  }
  if(uiDirty && !onNoticeActive && (radioOn || portalActive)) {
    uiDirty=false;
    if(uiPage==1) uiDrawWifi(); else if(uiPage==2) uiDrawKeyboard(); else if(uiPage==5)drawStationCodePage(); else if(uiPage==6)drawRadioLinkPage(); else if(uiPage==8)drawDeleteStationPage(); else if(uiPage>=3)drawFeaturePage(); else changed=true;
  }
}
