#pragma once
// Image-only, station-scoped sponsors. Never execute advertiser URLs or HTML.
constexpr size_t SPONSOR_PIXELS=256*76, SPONSOR_BYTES=SPONSOR_PIXELS*2;
constexpr uint32_t SPONSOR_FIRST_MS=600000, SPONSOR_GAP_MS=1800000, SPONSOR_SHOW_MS=8000;
struct SponsorResult {
 String code,brand,message,phone,receipt;uint16_t* pixels=nullptr;
 bool ack=false,ok=false;uint32_t received=0;
};
struct SponsorJob {String id,secret,code,receipt;bool ack;};
QueueHandle_t sponsorResults=nullptr;
SponsorResult* sponsorCurrent=nullptr;
String sponsorListeningCode,sponsorAckReceipt;
bool sponsorTracking=false;
uint32_t sponsorListeningSince=0,sponsorNextAt=0,sponsorAttemptAt=0,sponsorVisibleAt=0,sponsorAckAt=0;
int sponsorAckTries=0;

bool sponsorDelayElapsed(uint32_t now) {
 return sponsorTracking && uint32_t(now-sponsorListeningSince)>=SPONSOR_FIRST_MS &&
        (!sponsorNextAt||int32_t(now-sponsorNextAt)>=0);
}
bool sponsorPlaybackQualified() {
 return radioOn && !radioMuted && stationCount>0 && audioReady && !uiPaused && !safeRecoveryMode &&
        !stationPending && !portalActive && !voiceBusy() && WiFi.status()==WL_CONNECTED && audio.isRunning();
}
bool sponsorScreenAvailable() {
 return screenReady && !displaySleeping && !offNoticeActive && uiPage==0 && !homePopup && !onNoticeActive && !radioApprovalPopupVisible();
}
bool sponsorPopupVisible() {return sponsorCurrent && sponsorCurrent->pixels && sponsorScreenAvailable() && sponsorPlaybackQualified();}
void freeSponsor(SponsorResult* item) {if(item){heap_caps_free(item->pixels);delete item;}}
void closeSponsorPopup() {freeSponsor(sponsorCurrent);sponsorCurrent=nullptr;sponsorVisibleAt=0;changed=true;}
bool safeSponsorPath(const String& path) {
 const String prefix="/api/radio/ad/pixels?token=";
 if(!path.startsWith(prefix)||path.length()>600||path.length()<=prefix.length())return false;
 for(unsigned i=prefix.length();i<path.length();++i){char c=path[i];if(!isalnum((unsigned char)c)&&c!='_'&&c!='-'&&c!='.')return false;}
 return true;
}
void sponsorWorker(void* parameter) {
 auto* job=static_cast<SponsorJob*>(parameter);
 auto* result=new(std::nothrow) SponsorResult;
 if(result)do {
  result->ack=job->ack;result->code=job->code;result->receipt=job->receipt;
  if(WiFi.status()!=WL_CONNECTED||time(nullptr)<1700000000)break;
  String path;
  {
   DeadlineStationClient client;client.setCACert(WEBSITE_ROOT_CA);client.setHandshakeTimeout(5);client.setTimeout(1000);
   HTTPClient http;http.useHTTP10(true);http.setConnectTimeout(4000);http.setTimeout(4000);
   if(!http.begin(client,(String(RADIO_SERVICE_ORIGIN)+"/api/radio/ad")+(job->ack?"/displayed":"")))break;
   http.addHeader("Authorization","Bearer "+job->secret);http.addHeader("Content-Type","application/json");
   JsonDocument payload;payload["radio_id"]=job->id;
   if(job->ack)payload["receipt"]=job->receipt;else payload["station_code"]=job->code;
   String body;serializeJson(payload,body);int status=http.POST(body);
   if(status!=200){http.end();break;}
   if(job->ack){result->ok=true;http.end();break;}
   int length=http.getSize();if(length<=0||length>2048){http.end();break;}
   JsonDocument document;BoundedStationStream stream(http.getStream());
   auto error=deserializeJson(document,stream,DeserializationOption::NestingLimit(3));http.end();
   if(error||stream.exhausted()||document["ad"].isNull())break;
   JsonObject ad=document["ad"].as<JsonObject>();
   path=ad["pixels_path"]|"";result->receipt=ad["receipt"]|"";
   result->brand=ad["brand"]|"";result->message=ad["message"]|"";result->phone=ad["phone"]|"";
   int width=ad["width"]|0,height=ad["height"]|0,expires=ad["expires_in"]|0;
   if(width!=256||height!=76||expires<=0||expires>60||!safeSponsorPath(path)||
      !radioLinkHex(result->receipt,32)||result->brand.length()>128||result->message.length()>320||result->phone.length()>128)break;
  }
  if(path.isEmpty())break;
  DeadlineStationClient client;client.setCACert(WEBSITE_ROOT_CA);client.setHandshakeTimeout(5);client.setTimeout(1000);
  HTTPClient http;http.useHTTP10(true);http.setConnectTimeout(4000);http.setTimeout(1000);
  if(!http.begin(client,String(RADIO_SERVICE_ORIGIN)+path))break;
  http.addHeader("Authorization","Bearer "+job->secret);
  if(http.GET()!=200||http.getSize()!=int(SPONSOR_BYTES)){http.end();break;}
  result->pixels=(uint16_t*)heap_caps_malloc(SPONSOR_BYTES,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
  if(!result->pixels){http.end();break;}
  auto& stream=http.getStream();size_t used=0;uint32_t started=millis();
  while(used<SPONSOR_BYTES && millis()-started<12000){
   int available=stream.available();
   if(available>0){int count=stream.read(((uint8_t*)result->pixels)+used,min(size_t(1024),min(size_t(available),SPONSOR_BYTES-used)));if(count>0)used+=count;}
   else if(!stream.connected())break;
   delay(1);
  }
  http.end();
  if(used!=SPONSOR_BYTES||millis()-started>=12000)break;
  result->ok=true;result->received=millis();
 }while(false);
 delete job;
 if(xQueueSend(sponsorResults,&result,0)!=pdTRUE)freeSponsor(result);
 vTaskDelete(nullptr);
}
void drawSponsorPopup() {
 if(!sponsorPopupVisible())return;
 screen.fillRoundRect(16,37,288,156,9,UI_BG);screen.drawRoundRect(16,37,288,156,9,UI_SKY);
 uiText("Sponsored",27,47,1,UI_SKY);
 screen.fillRoundRect(266,40,32,28,5,UI_PANEL);
 screen.drawLine(276,48,288,60,UI_WHITE);screen.drawLine(288,48,276,60,UI_WHITE);
 uiText(uiShort(sponsorCurrent->brand,36),28,71,1,UI_WHITE);
 for(int y=0;y<76;++y)for(int x=0;x<256;++x)screen.drawPixel(32+x,84+y,sponsorCurrent->pixels[y*256+x]);
 uiText(uiShort(sponsorCurrent->message,42),28,167,1,UI_WHITE);
 uiText(uiShort(sponsorCurrent->phone,42),28,180,1,UI_MUTED);
 if(!sponsorVisibleAt){
  sponsorVisibleAt=millis();sponsorNextAt=millis()+SPONSOR_GAP_MS;
  sponsorAckReceipt=sponsorCurrent->receipt;sponsorAckTries=0;sponsorAckAt=0;
 }
}
void tapSponsorPopup(int x,int y) {
 if(x>=260&&x<304&&y>=37&&y<81)closeSponsorPopup();
}
void serviceSponsors() {
 if(!sponsorResults)sponsorResults=xQueueCreate(1,sizeof(SponsorResult*));
 if(!sponsorResults)return;
 bool listening=sponsorPlaybackQualified();String code=stationCount?stationCodes[selected]:"";
 if(!listening||!validListenerCode(code.c_str())||code!=sponsorListeningCode){
  sponsorListeningCode=code;sponsorListeningSince=millis();sponsorTracking=listening&&validListenerCode(code.c_str());
  if(sponsorCurrent)closeSponsorPopup();
 }
 if(listening&&!sponsorTracking){sponsorTracking=true;sponsorListeningSince=millis();}
 SponsorResult* result=nullptr;
 if(xQueueReceive(sponsorResults,&result,0)==pdTRUE){
  sponsorWorkerBusy=false;
  if(result&&result->ack){
   if(result->ok||++sponsorAckTries>=3)sponsorAckReceipt="";
  }else if(result&&result->ok&&sponsorTracking&&listening&&result->code==code&&sponsorScreenAvailable()&&!uiTouchHeld&&
           sponsorDelayElapsed(millis())&&millis()-result->received<60000){
   freeSponsor(sponsorCurrent);sponsorCurrent=result;result=nullptr;sponsorVisibleAt=0;changed=true;
  }
  freeSponsor(result);
 }
 if(sponsorCurrent&&(!listening||!sponsorScreenAvailable()||
    (sponsorVisibleAt&&millis()-sponsorVisibleAt>=SPONSOR_SHOW_MS)))closeSponsorPopup();
 if(sponsorWorkerBusy||radioLinkTask||syncTaskHandle||artWorkerBusy||stationAddRequested||portalActive||
    WiFi.status()!=WL_CONNECTED||time(nullptr)<1700000000||ESP.getFreeHeap()<90000||radioLinkId.isEmpty()||radioLinkSecret.isEmpty())return;
 bool ack=sponsorAckReceipt.length()>0;
 if(ack){if(sponsorAckAt&&millis()-sponsorAckAt<15000)return;}
 else if(!sponsorTracking||!listening||!sponsorScreenAvailable()||uiTouchHeld||sponsorCurrent||
         !sponsorDelayElapsed(millis())||
         (sponsorAttemptAt&&millis()-sponsorAttemptAt<60000))return;
 auto* job=new(std::nothrow) SponsorJob{radioLinkId,radioLinkSecret,code,sponsorAckReceipt,ack};if(!job)return;
 if(ack)sponsorAckAt=millis();else sponsorAttemptAt=millis();
 sponsorWorkerBusy=true;
 if(xTaskCreate(sponsorWorker,"radio-sponsor",8192,job,1,nullptr)!=pdPASS){sponsorWorkerBusy=false;delete job;}
}
