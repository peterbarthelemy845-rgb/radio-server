#pragma once

// Saved directory identities and revisions stay separate from the current
// playback selection. Never replace this with a full-catalog download.
String stationRevisions[MAX_STATIONS],stationExpectedRevisions[MAX_STATIONS];
uint32_t stationSyncRetryAt[MAX_STATIONS]={};
bool stationManifestJob=false,stationManifestAttempted=false;
String stationManifestCodes,stationSyncSelectedCode;
bool stationSelectedRefreshPending=true;
uint32_t stationManifestAt=0,stationManifestRetryAt=0,stationSyncAttemptAt=0;
int stationSyncCursor=0;

bool validStationRevision(const char* revision) {
  if(!revision || !*revision || strlen(revision)>20)return false;
  for(unsigned i=0;revision[i];++i)if(revision[i]<'0'||revision[i]>'9')return false;
  return true;
}
bool stationSyncRetryReady(int index,uint32_t now) {
  return !stationSyncRetryAt[index] || int32_t(now-stationSyncRetryAt[index])>=0;
}
String savedStationManifestCodes() {
  String codes;
  for(int i=0;i<stationCount;++i)if(validListenerCode(stationCodes[i].c_str())) {
    if(codes.length())codes+=',';
    codes+=stationCodes[i];
  }
  return codes;
}
bool applyStationManifest(JsonDocument& document) {
  if((document["http_status"]|0)!=HTTP_CODE_OK || !document["stations"].is<JsonArray>())return false;
  JsonArray entries=document["stations"].as<JsonArray>();
  if(entries.size()>MAX_STATIONS)return false;
  // Validate the entire bounded response before changing pending revisions.
  int count=0;
  String seen[MAX_STATIONS];
  for(JsonObject entry:entries) {
    const char* code=entry["listener_code"]|"";
    const char* revision=entry["revision"]|"";
    if(!validListenerCode(code)||!validStationRevision(revision))return false;
    for(int i=0;i<count;++i)if(seen[i]==code)return false;
    seen[count++]=code;
  }
  for(JsonObject entry:entries) {
    const char* code=entry["listener_code"]|"";
    for(int i=0;i<stationCount;++i)if(stationCodes[i]==code) {
      stationExpectedRevisions[i]=entry["revision"].as<String>();break;
    }
  }
  // Missing/unpublished entries never erase the listener's local list.
  return true;
}
void stationManifestFinished(bool okay) {
  if(okay){stationManifestAttempted=true;stationManifestRetryAt=0;}
  else{stationManifestAttempted=false;stationManifestRetryAt=millis()+60000UL;}
}
void stationMetadataFinished(const String& code,bool okay) {
  for(int i=0;i<stationCount;++i)if(stationCodes[i]==code) {
    stationSyncRetryAt[i]=okay?0:millis()+60000UL;
    if(okay)stationExpectedRevisions[i]=stationRevisions[i];
    else if(i==selected)stationSelectedRefreshPending=true;
    break;
  }
}

void startStationCodeWorker(const String& code,bool adding);
void startStationManifestWorker(const String& codes);
void serviceSavedStationSync() {
  if(stationCount<=0 || stationCount>MAX_STATIONS || selected<0 || selected>=stationCount)return;
  uint32_t now=millis();
  String selectedCode=stationCodes[selected];
  if(selectedCode!=stationSyncSelectedCode) {
    stationSyncSelectedCode=selectedCode;stationSelectedRefreshPending=true;
  }
  // An actively chosen station gets priority. Failures retain its cache, then
  // retry after a minute instead of repeatedly opening TLS connections.
  if(validListenerCode(selectedCode.c_str()) && stationSyncRetryReady(selected,now) &&
     (stationSelectedRefreshPending || !syncAttempted || uint32_t(now-lastStationSync)>=300000UL)) {
    stationSelectedRefreshPending=false;syncAttempted=true;lastStationSync=now;stationSyncAttemptAt=now;
    startStationCodeWorker(selectedCode,false);return;
  }
  // Give the UI/audio network work breathing room between background jobs.
  if(stationSyncAttemptAt && uint32_t(now-stationSyncAttemptAt)<10000UL)return;
  if((!stationManifestAttempted || uint32_t(now-stationManifestAt)>=300000UL) &&
     (!stationManifestRetryAt || int32_t(now-stationManifestRetryAt)>=0)) {
    String codes=savedStationManifestCodes();
    if(codes.length()) {
      stationManifestAt=now;stationManifestAttempted=true;stationSyncAttemptAt=now;
      startStationManifestWorker(codes);return;
    }
  }
  // The manifest names only saved codes. Fetch changed metadata one station at
  // a time; changing another saved station must not select or start it.
  for(int offset=0;offset<stationCount;++offset) {
    int index=(stationSyncCursor+offset)%stationCount;
    if(validListenerCode(stationCodes[index].c_str()) && stationExpectedRevisions[index].length() &&
       stationExpectedRevisions[index]!=stationRevisions[index] && stationSyncRetryReady(index,now)) {
      stationSyncCursor=(index+1)%stationCount;stationSyncAttemptAt=now;
      startStationCodeWorker(stationCodes[index],false);return;
    }
  }
}
