#pragma once

int savedVolumePercent = 25;
int observedVolumePercent = 25;
bool savedRadioMuted=false,observedRadioMuted=false;
unsigned long volumeChangedAt = 0;

void loadVolumeSettings() {
  Preferences settings;
  if (settings.begin("radio-volume", true)) {
    int packed=settings.getInt("state_v2",-1);
    if(packed>=0 && packed<=228 && (packed&127)<=100) {
      volumePercent=packed&127;radioMuted=(packed&128)!=0;
    }else {
      int value=settings.getInt("percent",25);
      volumePercent=value>=0 && value<=100?value:25;
      radioMuted=settings.getBool("muted",false);
    }
    settings.end();
  }
  savedVolumePercent=observedVolumePercent=volumePercent;
  savedRadioMuted=observedRadioMuted=radioMuted;
}

void saveVolumeIfDue(bool force = false) {
  if(volumePercent!=observedVolumePercent || radioMuted!=observedRadioMuted) {
    observedVolumePercent=volumePercent;observedRadioMuted=radioMuted;volumeChangedAt=millis();
  }
  if(volumePercent==savedVolumePercent && radioMuted==savedRadioMuted)return;
  if(!force && millis()-volumeChangedAt<1000)return;
  Preferences settings;
  if(!settings.begin("radio-volume",false)){volumeChangedAt=millis();return;}
  // One NVS value commits level and mute atomically. A failed write cannot
  // leave half of a setting changed after reboot. Older percent keys still load.
  int packed=volumePercent+(radioMuted?128:0);
  bool saved=settings.putInt("state_v2",packed)==sizeof(int32_t) && settings.getInt("state_v2",-1)==packed;
  settings.end();
  if(saved){savedVolumePercent=volumePercent;savedRadioMuted=radioMuted;}
  else volumeChangedAt=millis();
}
