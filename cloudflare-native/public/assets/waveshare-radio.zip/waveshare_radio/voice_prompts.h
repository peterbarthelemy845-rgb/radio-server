#pragma once
#include <FS.h>
#include <FSImpl.h>
#include "voice_assets.h"

// Read-only files backed by firmware flash; no filesystem upload or formatting.
class VoiceFile : public fs::FileImpl {
  const uint8_t* data_;
  size_t size_, position_ = 0;
  const char* path_;
  bool open_ = true;
public:
  VoiceFile(const uint8_t* data, size_t size, const char* path) : data_(data), size_(size), path_(path) {}
  size_t write(const uint8_t*, size_t) override { return 0; }
  size_t read(uint8_t* buffer, size_t count) override {
    if (!open_) return 0;
    size_t remaining = size_ - position_;
    if (count > remaining) count = remaining;
    memcpy(buffer, data_ + position_, count);
    position_ += count;
    return count;
  }
  void flush() override {}
  bool seek(uint32_t offset, fs::SeekMode mode) override {
    uint64_t target = offset;
    if (mode == fs::SeekCur) target += position_;
    else if (mode == fs::SeekEnd) target += size_;
    else if (mode != fs::SeekSet) return false;
    if (!open_ || target > size_) return false;
    position_ = target;
    return true;
  }
  size_t position() const override { return position_; }
  size_t size() const override { return size_; }
  bool setBufferSize(size_t) override { return true; }
  void close() override { open_ = false; }
  time_t getLastWrite() override { return 0; }
  const char* path() const override { return path_; }
  const char* name() const override { return path_ + 1; }
  boolean isDirectory() override { return false; }
  fs::FileImplPtr openNextFile(const char*) override { return {}; }
  boolean seekDir(long) override { return false; }
  String getNextFileName() override { return ""; }
  String getNextFileName(bool* isDir) override { if (isDir) *isDir = false; return ""; }
  void rewindDirectory() override {}
  operator bool() override { return open_; }
};

class VoiceFilesystem : public fs::FSImpl {
public:
  fs::FileImplPtr open(const char* path, const char* mode, bool create) override {
    if (!path || !mode || strcmp(mode, "r") || create) return {};
    if (!strcmp(path, "/welcome.mp3")) return std::make_shared<VoiceFile>(voice_welcome, sizeof(voice_welcome), "/welcome.mp3");
    if (!strcmp(path, "/setup.mp3")) return std::make_shared<VoiceFile>(voice_setup, sizeof(voice_setup), "/setup.mp3");
    if (!strcmp(path, "/connecting.mp3")) return std::make_shared<VoiceFile>(voice_connecting, sizeof(voice_connecting), "/connecting.mp3");
    if (!strcmp(path, "/volume.mp3")) return std::make_shared<VoiceFile>(voice_volume, sizeof(voice_volume), "/volume.mp3");
    return {};
  }
  bool exists(const char* path) override { return bool(open(path, "r", false)); }
  bool rename(const char*, const char*) override { return false; }
  bool remove(const char*) override { return false; }
  bool mkdir(const char*) override { return false; }
  bool rmdir(const char*) override { return false; }
};

fs::FS voiceFiles(std::make_shared<VoiceFilesystem>());
const char* voiceQueue[4];
uint8_t voiceCount = 0;
bool voiceActive = false;
unsigned long voiceStarted = 0;
unsigned long voiceProgressAt = 0;
uint32_t voicePosition = 0;

void cancelVoicePrompts() {
  voiceCount = 0;
  if (voiceActive && audioReady) audio.stopSong();
  voiceActive = false;
}

void queueVoicePrompt(const char* path) {
  if (audioReady && voiceCount < 4) voiceQueue[voiceCount++] = path;
}

bool voiceBusy() { return voiceActive || voiceCount > 0; }

void serviceVoicePrompts() {
  if (!audioReady) { voiceCount = 0; voiceActive = false; return; }
  if (voiceActive) {
    audio.loop();
    uint32_t position = audio.getAudioCurrentTime();
    if (position != voicePosition) { voicePosition = position; voiceProgressAt = millis(); }
    if (audio.isRunning() && millis() - voiceStarted < 60000 && millis() - voiceProgressAt < 10000) return;
    audio.stopSong();
    voiceActive = false;
    stationPending = true;
    changed = true;
  }
  if (!voiceCount) return;
  const char* path = voiceQueue[0];
  for (uint8_t i = 1; i < voiceCount; ++i) voiceQueue[i - 1] = voiceQueue[i];
  --voiceCount;
  audio.stopSong();
  voiceActive = audio.connecttoFS(voiceFiles, path);
  if (voiceActive) {
    audio.setMute(false);
    applyRadioOutputVolume();
  }
  voiceStarted = millis();
  voiceProgressAt = voiceStarted;
  voicePosition = 0;
  stationPending = true;
  Serial.print(voiceActive ? "Voice prompt: " : "Voice prompt failed: ");
  Serial.println(path);
}
