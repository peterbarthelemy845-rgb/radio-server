#pragma once
String enteredStationCode;
void openStationCodePage() {
 wakeRadioDisplay();uiPage=5;uiDirty=true;
 if(!stationAddRequested && !syncTaskHandle)codeLookupMessage="";
}
bool codeLookupBusy() {return stationAddRequested || (syncTaskHandle && stationCodeAddingJob);}
void drawStationCodePage() {
 screen.fillScreen(UI_BG);
 uiText("Add station",8,12,1,UI_WHITE);
 screen.drawRoundRect(114,2,198,29,6,UI_SKY);uiText(enteredStationCode.length()?enteredStationCode:"__",132,8,2);
 uiText(uiShort(codeLookupBusy()?"Loading station...":codeLookupMessage,50),8,191,1,UI_SKY);
 for(int row=0;row<4;++row)for(int col=0;col<3;++col) {
  int key=row*3+col;String label=key<9?String(key+1):key==9?"DEL":key==10?"0":"C";
  int x=8+col*103,y=38+row*38,size=key==9?1:3;
  screen.fillRoundRect(x,y,98,36,6,UI_PANEL);
  uiText(label,x+(98-int(label.length())*6*size)/2,y+(36-8*size)/2,size);
 }
 setupButton(8,202,168,36,"Back to radio",false,true,1);
 setupButton(184,202,128,36,codeLookupBusy()?"Wait":"Add",true,true,2);
 screen.display();
}
void tapStationCodePage(int x,int y) {
 if(y>=202 && x<176) {
  stationAddRequested=false;stationAddCanceled=true;codeLookupMessage="";backToRadioHome();return;
 }
 if(codeLookupBusy())return;
 if(x>=8 && x<312 && y>=38 && y<188) {
  int col=(x-8)/103,row=(y-38)/38,key=row*3+col;
  if(col<3 && row<4 && (x-8)%103<98 && (y-38)%38<36) {
   if(key<9 && enteredStationCode.length()<6)enteredStationCode+=char('1'+key);
   else if(key==9 && enteredStationCode.length())enteredStationCode.remove(enteredStationCode.length()-1);
   else if(key==10 && enteredStationCode.length()<6)enteredStationCode+='0';
   else if(key==11)enteredStationCode="";
   codeLookupMessage="";
  }
 } else if(y>=202 && x>=184) {
  if(!validListenerCode(enteredStationCode.c_str()))codeLookupMessage="Enter 2-6 digits.";
  else if(WiFi.status()!=WL_CONNECTED)codeLookupMessage="Connect Wi-Fi first.";
  else if(time(nullptr)<1700000000)codeLookupMessage="Clock syncing. Retry.";
  else {
   stationCodeRequest=enteredStationCode;stationAddRequested=true;stationAddCanceled=false;
   stationAddRequestedAt=millis();codeLookupMessage="Loading station...";
  }
 }
 uiDirty=true;
}
