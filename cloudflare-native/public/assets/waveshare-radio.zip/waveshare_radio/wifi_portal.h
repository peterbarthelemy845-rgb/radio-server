#pragma once

#include <WiFiManager.h>

// Pinned WiFiManager 2.0.17: portal, scans and credential persistence.

WiFiManager wifiManager;

bool portalActive = false;

bool wifiAttemptActive = false;
bool wifiStartupScanning = false;
bool wifiAttemptFromPortal = false;
bool portalShouldRetrySaved = false;
unsigned long portalRetryAt = 0;
unsigned long wifiStartupScanStarted = 0;
String wifiAttemptSsid = "";
String wifiAttemptPassword = "";

bool wifiManagerConfigured = false;

bool wifiCredentialsSubmitted = false;

unsigned long wifiAttemptStarted = 0;

unsigned long portalConnectedAt = 0;

unsigned long wifiDisconnectedAt = 0;

String portalState = "ready";

void wifiMessage(const char* title, const char* detail);

void showPortalInstructions() {

  wifiMessage("Phone Wi-Fi setup", "Radio-Setup\nNo password\n192.168.4.1");

}

const char radioPortalHead[] PROGMEM = R"HTML(

<meta charset="utf-8"><style>

:root{--radio-blue:#2563eb;--radio-sky:#38bdf8;--radio-ink:#0f172a}

*{box-sizing:border-box}html{min-height:100%;background:#071642}body{min-height:100vh;margin:0;padding:16px;font:17px system-ui;background:radial-gradient(circle at top,#1d4ed8 0,#0b1f5b 38%,#071642 100%);color:var(--radio-ink)}

body .wrap{display:block;width:100%;max-width:460px;min-width:0;margin:16px auto;padding:22px;background:rgba(255,255,255,.96);border-radius:24px;text-align:left;box-shadow:0 24px 70px rgba(0,0,0,.35)}

h1{font-size:28px;line-height:1.15;color:var(--radio-ink)}label{display:inline-block;margin:10px 0 6px;color:#1e293b}input:not([type=checkbox]),select{width:100%;min-height:50px;padding:12px;border:2px solid #dbe4f0;border-radius:12px;background:#fff;color:var(--radio-ink);font:inherit}input:focus,select:focus{outline:2px solid var(--radio-sky)}

button{width:100%;padding:14px;border:0;border-radius:14px;background:linear-gradient(135deg,#38bdf8,#2563eb);color:white;font:inherit;font-weight:700;cursor:pointer}a{color:#1d4ed8}body .msg{background:#eff6ff;color:#1e293b;border-color:#dbeafe}

#radio-status{max-width:460px;margin:0 auto;padding:16px;border-radius:18px;background:rgba(255,255,255,.96);color:#1e293b;font-size:18px;box-shadow:0 12px 30px rgba(0,0,0,.2)}#radio-status.connected{background:#dcfce7;color:#166534;font-size:25px}#radio-status .creole{font-size:19px;line-height:1.45;border-top:1px solid #86c99c;padding-top:16px}#radio-networks{margin:8px 0 16px}#radio-network-label{display:block;text-align:left}[hidden]{display:none!important}

</style>

<script>window.addEventListener('DOMContentLoaded',()=>{

const panel=document.createElement('div');panel.id='radio-status';panel.setAttribute('role','status');panel.setAttribute('aria-live','polite');panel.tabIndex=-1;

document.body.prepend(panel);panel.textContent='Radio La Voix Divine - Wi-Fi setup';let finished=false;

const ssid=document.getElementById('s'),password=document.getElementById('p');

const networks=Array.from(document.querySelectorAll('a[data-ssid]'));

if(ssid){

  ssid.required=true;

  const label=document.createElement('label');label.id='radio-network-label';label.htmlFor='radio-networks';label.textContent='Choose your Wi-Fi network';

  const select=document.createElement('select');select.id='radio-networks';

  select.add(new Option(networks.length?'Select a network':'No networks found - type the name below',''));

  for(const network of networks){select.add(new Option(network.textContent,network.dataset.ssid));network.parentElement.hidden=true;}

  select.onchange=()=>{if(select.value){ssid.value=select.value;if(password){password.value='';password.focus();}}};

  const form=ssid.closest('form');form.parentNode.insertBefore(label,form);form.parentNode.insertBefore(select,form);

}

setInterval(async()=>{if(finished)return;try{const r=await fetch('/radio-status',{cache:'no-store'});if(!r.ok)return;const s=await r.json();

if(s.state==='connecting')panel.textContent='Connecting your radio... Please wait.';

if(s.state==='failed')panel.textContent='Could not connect. Check the network and password, then try again. Open networks use an empty password.';

if(s.state==='connected'){finished=true;panel.className='connected';panel.textContent='Wi-Fi connected! Your radio is ready.';

const help=document.createElement('p');help.textContent='This window will try to close. If it stays open, tap X or Done and return your phone to normal Wi-Fi.';panel.append(help);

const creole=document.createElement('p');creole.className='creole';creole.lang='ht';creole.textContent='Wi-Fi konekte! Radyo ou pare. Fenèt sa a ap eseye fèmen poukont li. Si li rete ouvè, peze X oswa Done anlè a, epi rekonekte telefòn ou ak Wi-Fi ou konn itilize a.';panel.append(creole);

Array.from(document.body.children).forEach(child=>{if(child!==panel)child.hidden=true;});window.scrollTo(0,0);panel.focus();setTimeout(()=>window.close(),4000);}

}catch(e){}},1000);});</script>)HTML";

void configureWifiManager() {

  if (wifiManagerConfigured) return;

  wifiManagerConfigured = true;

  wifiManager.setDebugOutput(false);

  wifiManager.setTitle("Radio La Voix Divine");

  wifiManager.setDarkMode(false);
  // Do not hide weak networks in the phone's setup list.
  wifiManager.setMinimumSignalQuality(-1);

  wifiManager.setConfigPortalBlocking(false);

  wifiManager.setConfigPortalTimeout(0);

  // Upstream saves credentials; the loop then starts a nonblocking attempt.

  wifiManager.setSaveConnect(false);

  wifiManager.setConnectRetries(1);

  wifiManager.setConnectTimeout(1);

  wifiManager.setSaveConnectTimeout(1);

  wifiManager.setDisableConfigPortal(false);

  wifiManager.setCustomHeadElement(radioPortalHead);

  const char* menu[] = {"wifi"};

  wifiManager.setMenu(menu, 1);

  wifiManager.setWebServerCallback([]() {

    // Register first, before WiFiManager's default landing-page handler.

    wifiManager.server->on("/", HTTP_GET, []() {

      wifiManager.server->sendHeader("Location", "/wifi", true);

      wifiManager.server->send(302, "text/plain", "Opening Wi-Fi setup");

    });

    wifiManager.server->on("/radio-status", HTTP_GET, []() {

      wifiManager.server->sendHeader("Cache-Control", "no-store");

      wifiManager.server->send(200, "application/json", "{\"state\":\"" + portalState + "\"}");

    });

  });

  wifiManager.setPreSaveConfigCallback([]() {
    // Once the user submits a network, do not compete with their choice.
    portalShouldRetrySaved = false;

    portalState = "connecting";

    portalConnectedAt = 0;

    cancelVoicePrompts();

    queueVoicePrompt("/connecting.mp3");

    wifiMessage("Connecting Wi-Fi", "Keep phone on\nRadio-Setup");

  });

  wifiManager.setSaveConfigCallback([]() { wifiCredentialsSubmitted = true; });

}

void beginWifiPortal(bool forgetSaved) {

  configureWifiManager();

  if (portalActive) wifiManager.stopConfigPortal();

  if (forgetSaved) {

    cancelVoicePrompts();

    wifiManager.resetSettings();

    Preferences oldSettings;

    if (oldSettings.begin("radio-wifi", false)) { oldSettings.clear(); oldSettings.end(); }

  }

  if (audioReady) audio.stopSong();

  stationPending = true;

  wifiAttemptActive = false;
  wifiStartupScanning = false;
  uiLocalWifiAttempt = false;
  WiFi.scanDelete();
  wifiAttemptSsid = "";
  wifiAttemptPassword = "";

  wifiCredentialsSubmitted = false;

  portalConnectedAt = 0;

  wifiDisconnectedAt = 0;

  portalState = "ready";

  WiFi.setAutoReconnect(false);

  WiFi.disconnect(false, false);

  WiFi.mode(WIFI_AP_STA);

  wifiManager.startConfigPortal("Radio-Setup");

  portalActive = wifiManager.getConfigPortalActive();
  portalRetryAt = millis();
  portalShouldRetrySaved = !forgetSaved;

  if (!portalActive) { wifiMessage("Setup Wi-Fi failed", "Press RESET to retry"); return; }

  showPortalInstructions();

  if (radioOn && !wifiNoticeSpoken) {
    queueVoicePrompt("/setup.mp3");
    wifiNoticeSpoken = true;
  }

}

// Preserve the last WORKING credentials independently of driver persistence.
// Write only on successful connection and only when the values have changed.
void rememberWorkingWifi() {
  if (wifiAttemptSsid.isEmpty()) return;
  Preferences saved;
  if (!saved.begin("radio-wifi", false)) {
    Serial.println("Could not open saved Wi-Fi settings.");
    return;
  }
  if (saved.getString("ssid", "") != wifiAttemptSsid ||
      saved.getString("password", "") != wifiAttemptPassword) {
    saved.putString("ssid", wifiAttemptSsid);
    saved.putString("password", wifiAttemptPassword);
  }
  saved.end();
}

void connectSavedWifiAfterScan() {
  wifiStartupScanning = false;
  WiFi.scanDelete();
  WiFi.setAutoReconnect(true);
  WiFi.persistent(true);
  WiFi.begin(wifiAttemptSsid.c_str(), wifiAttemptPassword.isEmpty() ? nullptr : wifiAttemptPassword.c_str());
  WiFi.persistent(false);
  wifiAttemptActive = true;
  wifiAttemptFromPortal = false;
  wifiAttemptStarted = millis();
  wifiMessage("Connecting Wi-Fi", "Saved network\nPlease wait...");
  Serial.println("Trying saved Wi-Fi before setup (up to 60 seconds).");
}

void startSavedWifi() {
  configureWifiManager();
  WiFi.mode(WIFI_STA);
  wifiAttemptSsid = "";
  wifiAttemptPassword = "";
  Preferences saved;
  if (saved.begin("radio-wifi", true)) {
    wifiAttemptSsid = saved.getString("ssid", "");
    wifiAttemptPassword = saved.getString("password", "");
    saved.end();
  }
  if (wifiAttemptSsid.isEmpty()) {
    wifiAttemptSsid = wifiManager.getWiFiSSID(true);
    wifiAttemptPassword = wifiManager.getWiFiPass(true);
  }
  if (wifiAttemptSsid.isEmpty()) {
    if (radioOn) beginWifiPortal(false);
    return;
  }
  wifiAttemptActive = false;
  wifiAttemptFromPortal = false;
  wifiDisconnectedAt = 0;
  wifiStartupScanning = true;
  wifiStartupScanStarted = millis();
  wifiMessage("Checking home Wi-Fi", "Scanning saved\nnetwork first...");
  Serial.println("Scanning for saved Wi-Fi; setup stays closed.");
  WiFi.scanDelete();
  // Asynchronous scan: controls, voice and display keep being serviced.
  WiFi.scanNetworks(true, true);
}

void serviceWifiPortal() {
  if (portalActive) wifiManager.process();

  // An automatically opened portal must not strand the radio after a router
  // outage. Keep the page available while retrying the last working network.
  if (portalActive && portalShouldRetrySaved && !wifiAttemptActive &&
      portalState != "connected" && millis() - portalRetryAt >= 30000) {
    portalRetryAt = millis();
    Preferences saved;
    if (saved.begin("radio-wifi", true)) {
      wifiAttemptSsid = saved.getString("ssid", "");
      wifiAttemptPassword = saved.getString("password", "");
      saved.end();
    }
    if (wifiAttemptSsid.isEmpty()) {
      wifiAttemptSsid = wifiManager.getWiFiSSID(true);
      wifiAttemptPassword = wifiManager.getWiFiPass(true);
    }
    if (wifiAttemptSsid.isEmpty()) portalShouldRetrySaved = false;
    else {
      WiFi.begin(wifiAttemptSsid.c_str(), wifiAttemptPassword.isEmpty() ? nullptr : wifiAttemptPassword.c_str());
      wifiAttemptActive = true;
      wifiAttemptFromPortal = false;
      wifiAttemptStarted = millis();
      Serial.println("Setup remains available; retrying saved home Wi-Fi.");
    }
  }

  if (wifiStartupScanning) {
    int scanResult = WiFi.scanComplete();
    if (scanResult != WIFI_SCAN_RUNNING || millis() - wifiStartupScanStarted >= 12000) {
      // Try the stored SSID even if absent from this scan: hidden networks and
      // routers still starting can become available during the connection wait.
      connectSavedWifiAfterScan();
    }
  }

  if (wifiCredentialsSubmitted) {
    WiFi.scanDelete();
    wifiCredentialsSubmitted = false;
    wifiAttemptSsid = wifiManager.getWiFiSSID(true);
    wifiAttemptPassword = wifiManager.getWiFiPass(true);
    if (!wifiAttemptSsid.isEmpty()) {
      WiFi.begin(wifiAttemptSsid.c_str(), wifiAttemptPassword.isEmpty() ? nullptr : wifiAttemptPassword.c_str());
      wifiAttemptActive = true;
      wifiAttemptFromPortal = true;
      wifiAttemptStarted = millis();
    } else { portalState = "failed"; showPortalInstructions(); }
  }

  if (wifiAttemptActive && WiFi.status() == WL_CONNECTED) {
    rememberWorkingWifi();
    uiLocalWifiAttempt = false;
    wifiAttemptActive = false;
    wifiDisconnectedAt = 0;
    WiFi.setAutoReconnect(true);
    portalState = "connected";
    if (portalActive) {
      portalState = "connected";
      portalConnectedAt = millis();
      wifiMessage("Wi-Fi connected!", "Return phone to\nyour normal Wi-Fi");
    }
    syncAttempted = false;
    stationPending = true;
    changed = true;
    Serial.println("Wi-Fi connected; saved for next power-on.");
  } else if (wifiAttemptActive && millis() - wifiAttemptStarted >= (wifiAttemptFromPortal ? 25000 : 60000)) {
    wifiAttemptActive = false;
    if (portalActive || uiLocalWifiAttempt) {
      WiFi.disconnect(false, false);
      portalState = "failed";
      showPortalInstructions();
    } else if (radioOn) beginWifiPortal(false);
    else startSavedWifi(); // Standby retries quietly; only an explicit reset opens setup.
  }

  if (portalActive && portalConnectedAt && millis() - portalConnectedAt >= 10000) {
    wifiManager.stopConfigPortal();
    WiFi.mode(WIFI_STA);
    portalActive = false;
    changed = true;
  }

  if (!portalActive && !wifiAttemptActive && !wifiStartupScanning && uiPage == 0) {
    if (WiFi.status() == WL_CONNECTED) wifiDisconnectedAt = 0;
    else if (!wifiDisconnectedAt) wifiDisconnectedAt = millis();
    // Give auto-reconnect a chance, then scan/retry saved Wi-Fi before setup.
    else if (millis() - wifiDisconnectedAt >= 45000) startSavedWifi();
  }
}
