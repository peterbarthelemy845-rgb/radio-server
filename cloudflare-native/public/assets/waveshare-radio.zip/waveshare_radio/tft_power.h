#pragma once
bool displaySleeping=false, offNoticeActive=false, onNoticeActive=false;
unsigned long onNoticeStarted=0, offNoticeStarted=0;
void wakeRadioDisplay() {
  offNoticeActive=onNoticeActive=false;
  if (displaySleeping) Set_Backlight(50);
  displaySleeping=false;
}
void powerNotice(const char* label) {
  if (!screenReady) return;
  wakeRadioDisplay(); screen.clearDisplay(); screen.setTextColor(UI_WHITE);
  screen.setTextSize(2); screen.setCursor((320-strlen(label)*12)/2,115);
  screen.print(label); screen.display();
}
void showRadioOff() { powerNotice("Radio OFF"); offNoticeStarted=millis(); offNoticeActive=true; }
void showRadioOn() { powerNotice("Radio ON"); onNoticeStarted=millis(); onNoticeActive=true; }
void serviceDisplaySleep() {
  if (onNoticeActive && millis()-onNoticeStarted>=1000) { onNoticeActive=false; changed=true; }
  if (!screenReady || radioOn || portalActive || !offNoticeActive) return;
  if (millis()-offNoticeStarted<1500) return;
  Set_Backlight(0); displaySleeping=true; offNoticeActive=false;
}
