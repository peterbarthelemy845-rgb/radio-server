#pragma once
#include "feature_policy.h"
struct RadioZone {const char* name;const char* rule;};
const RadioZone radioZones[]={
 {"Haiti / Port-au-Prince","EST5EDT,M3.2.0,M11.1.0"},
 {"US Eastern / New York","EST5EDT,M3.2.0,M11.1.0"},
 {"US Central / Chicago","CST6CDT,M3.2.0,M11.1.0"},
 {"US Mountain / Denver","MST7MDT,M3.2.0,M11.1.0"},
 {"US Pacific / Los Angeles","PST8PDT,M3.2.0,M11.1.0"},
 {"Arizona / Phoenix","MST7"},{"Puerto Rico","AST4"},
 {"UTC / GMT","UTC0"},{"UK / London","GMT0BST,M3.5.0/1,M10.5.0/2"},
 {"France / Paris","CET-1CEST,M3.5.0/2,M10.5.0/3"},
 {"India","IST-5:30"},{"Japan","JST-9"}
};
constexpr int RADIO_ZONE_COUNT=sizeof(radioZones)/sizeof(radioZones[0]);
int radioZone=1,zonePage=0;
int homePopup=0;
bool simpleHomeMode=true;
void loadRadioUiSettings() {
 Preferences p;if(p.begin("radio-ui",true)){simpleHomeMode=true;p.end();}
}
bool saveRadioUiSettings() {
 Preferences p;if(!p.begin("radio-ui",false))return false;
 bool ok=p.putBool("simple",simpleHomeMode)==1;p.end();return ok;
}
float batteryVolts=0;
int batteryPercent=-1;
void drawFeaturePage();
void tapFeaturePage(int x,int y);
void openRadioSettings();
void saveClockSettings() {
 Preferences p;if(!p.begin("radio-clock",false)) return;
 p.putUChar("zone",radioZone);p.end();
}
void loadClockSettings() {
 Preferences p;if(p.begin("radio-clock",true)) {
  radioZone=p.getUChar("zone",1);p.end();
 }
 if(radioZone>=RADIO_ZONE_COUNT)radioZone=1;
 configTzTime(radioZones[radioZone].rule,"pool.ntp.org","time.google.com");
 analogReadResolution(12);analogSetPinAttenuation(8,ADC_11db);
}
void serviceBatteryLevel() {
 static uint32_t sampledAt=0;
 if(sampledAt && millis()-sampledAt<2000)return;
 sampledAt=millis();uint32_t sum=0;
 for(int i=0;i<8;++i)sum+=analogReadMilliVolts(8);
 float value=(sum/8.0f)*3.0f/1000.0f/0.990476f;
 int estimate=batteryEstimatePercent(int(value*1000));
 if(estimate<0) {batteryVolts=value;batteryPercent=-1;}
 else {
  batteryVolts=batteryPercent<0?value:batteryVolts*.8f+value*.2f;
  batteryPercent=batteryEstimatePercent(int(batteryVolts*1000));
 }
 changed=true;
}
