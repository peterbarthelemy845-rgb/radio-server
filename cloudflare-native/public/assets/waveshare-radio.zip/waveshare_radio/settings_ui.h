#pragma once
extern bool radioRemoteRunning;
String radioSettingsMessage;
void openRadioSettings() {wakeRadioDisplay();uiPage=3;uiDirty=true;radioSettingsMessage="";}
void drawFeaturePage() {
 screen.fillScreen(SETUP_BG);
 if(uiPage==3) {
  uiCenter("Settings",7,2,SETUP_INK);
  setupButton(8,35,304,42,"Wi-Fi",true,true,2);
  setupButton(8,81,304,42,"Time zone",false,true,2);
  setupButton(8,127,304,42,"Add station",false,true,2);
  uiCenter(String("Software ")+RADIO_FIRMWARE_VERSION,177,1,SETUP_MUTED);
 }else if(uiPage==4) {
  uiCenter("Time zone",7,2,SETUP_INK);
  for(int row=0;row<3;++row){int index=zonePage*3+row;if(index>=RADIO_ZONE_COUNT)break;
   setupButton(8,35+row*36,304,32,String(index==radioZone?"* ":"")+radioZones[index].name,index==radioZone);}
  setupButton(8,149,145,37,"Previous",false,zonePage>0);
  setupButton(163,149,149,37,"Next",false,(zonePage+1)*3<RADIO_ZONE_COUNT);
 }else if(uiPage==7) {
  uiCenter("Add station",7,2,SETUP_INK);
  setupButton(8,43,304,58,"Enter station code",true,true,2);
  setupButton(8,111,304,58,"Link phone",false,true,2);
 }
 setupButton(8,194,304,40,"Back to radio",false,true,2);screen.display();
}
void tapFeaturePage(int x,int y) {
 if(y>=194){backToRadioHome();return;}
 if(uiPage==3) {
  if(y>=35&&y<77){uiOpenWifi();return;}
  if(y>=81&&y<123){zonePage=radioZone/3;uiPage=4;}
  if(y>=127&&y<169){openStationCodePage();return;}
 }else if(uiPage==4) {
  if(y>=35&&y<143){int index=zonePage*3+(y-35)/36;
   if(index<RADIO_ZONE_COUNT){radioZone=index;configTzTime(radioZones[index].rule,"pool.ntp.org","time.google.com");saveClockSettings();uiPage=3;}}
  else if(y>=149&&y<186){if(x<158&&zonePage>0)--zonePage;else if(x>=163&&(zonePage+1)*3<RADIO_ZONE_COUNT)++zonePage;}
 }else if(uiPage==7) {
  if(y>=43&&y<101){openStationCodePage();return;}
  if(y>=111&&y<169){openRadioLinkPage();return;}
 }
 uiDirty=true;
}

int deleteStationIndex=-1;
String deleteStationMessage;
void openDeleteStationPage() {
 if(stationCount<1)return;
 deleteStationIndex=selected;deleteStationMessage="";
 stationAddRequested=false;stationAddCanceled=true;
 wakeRadioDisplay();uiPage=0;homePopup=8;uiDirty=true;changed=true;
}
bool deleteSavedStation(int index) {
 if(index<0 || index>=stationCount || syncTaskHandle || radioRemoteRunning || stationAddRequested)return false;
 String name=stations[index],url=streamUrls[index],logo=stationLogoUrls[index],code=stationCodes[index],revision=stationRevisions[index],expected=stationExpectedRevisions[index];
 uint32_t retry=stationSyncRetryAt[index];
 int oldCount=stationCount;
 for(int i=index;i<stationCount-1;++i){stations[i]=stations[i+1];streamUrls[i]=streamUrls[i+1];stationLogoUrls[i]=stationLogoUrls[i+1];stationCodes[i]=stationCodes[i+1];stationRevisions[i]=stationRevisions[i+1];stationExpectedRevisions[i]=stationExpectedRevisions[i+1];stationSyncRetryAt[i]=stationSyncRetryAt[i+1];}
 --stationCount;
 if(!saveStations()) {
  for(int i=oldCount-1;i>index;--i){stations[i]=stations[i-1];streamUrls[i]=streamUrls[i-1];stationLogoUrls[i]=stationLogoUrls[i-1];stationCodes[i]=stationCodes[i-1];stationRevisions[i]=stationRevisions[i-1];stationExpectedRevisions[i]=stationExpectedRevisions[i-1];stationSyncRetryAt[i]=stationSyncRetryAt[i-1];}
  stations[index]=name;streamUrls[index]=url;stationLogoUrls[index]=logo;stationCodes[index]=code;stationRevisions[index]=revision;stationExpectedRevisions[index]=expected;stationSyncRetryAt[index]=retry;stationCount=oldCount;return false;
 }
 stations[stationCount]="";streamUrls[stationCount]="";stationLogoUrls[stationCount]="";stationCodes[stationCount]="";stationRevisions[stationCount]="";stationExpectedRevisions[stationCount]="";stationSyncRetryAt[stationCount]=0;
 selected=stationCount?min(index,stationCount-1):0;
 cancelVoicePrompts();if(audioReady)audio.stopSong();playingUrl="";
 stationPending=stationCount>0;uiPaused=false;safeRecoveryMode=false;playbackRecovery.reset();
 lastTransition=millis();savePlaybackStateIfDue(true);changed=true;return true;
}
void drawDeleteStationPage() {
 screen.fillRoundRect(16,44,288,146,10,UI_BG);screen.drawRoundRect(16,44,288,146,10,UI_SKY);
 uiCenter("Delete station?",54,2,UI_WHITE);
 uiCenter(uiShort(deleteStationIndex>=0?stations[deleteStationIndex]:"",36),84,1,UI_WHITE);
 uiCenter("Remove from this radio only",106,1,UI_MUTED);
 uiCenter(uiShort(deleteStationMessage,40),121,1,UI_SKY);
 screen.fillRoundRect(30,140,124,40,6,0xC800);uiText("Delete",56,152,2,UI_WHITE);
 screen.fillRoundRect(166,140,124,40,6,UI_PANEL);uiText("Exit",204,152,2,UI_WHITE);
}
void tapDeleteStationPage(int x,int y) {
 if(y<140 || y>=180)return;
 if(x>=166 && x<290){backToRadioHome();return;}
 if(x>=30 && x<154) {
  if(syncTaskHandle || radioRemoteRunning){deleteStationMessage="Please wait for the station update.";uiDirty=true;return;}
  if(deleteSavedStation(deleteStationIndex)){backToRadioHome();}
  else{deleteStationMessage="Could not save. Please try again.";uiDirty=true;}
 }
}
