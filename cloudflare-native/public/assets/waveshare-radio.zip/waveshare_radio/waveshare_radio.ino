// SPDX-License-Identifier: GPL-3.0-only
// Radio integration prototype prepared 2026-10-11.
#include <Wire.h>
#include <Adafruit_GFX.h>
#include "display_adapter.h"
#include <WiFi.h>
#include <Preferences.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <ArduinoJson.h>
#include <time.h>
#include "website_ca.h"
#include "service_config.h"
#include <Audio.h>
#include <new>
#include "bounded_station_stream.h"

Audio audio;
bool audioReady = false;
String playingUrl;
unsigned long lastPlaybackAttempt = 0;
bool stationPending = true;
QueueHandle_t stationUpdates;
TaskHandle_t syncTaskHandle = nullptr;
unsigned long syncTaskStartedAt = 0;
bool syncWorkerWarned = false;

void audioLog(Audio::msg_t message) {
  static unsigned long lastLogAt = 0;
  if (!message.msg || millis() - lastLogAt < 500 || Serial.availableForWrite() < 96) return;
  lastLogAt = millis();
  Serial.printf("Audio: %.80s\n", message.msg);
}

// Waveshare onboard display/audio. Optional station knob CLK43 / DT44 / SW18.
RadioCanvas *radioScreen=nullptr;
#define screen (*radioScreen)
constexpr int MAX_STATIONS = 100;
String stations[MAX_STATIONS] = {"La Voix Divine"};
String stationCodes[MAX_STATIONS];
String stationCodeJob,stationCodeRequest,codeLookupMessage;
bool stationCodeAddingJob=false,stationAddRequested=false,stationAddCanceled=false;
uint32_t stationAddRequestedAt=0;
String streamUrls[MAX_STATIONS] = {
  "https://icecast3.getstreamhosting.com/proxy/radiodivinessl/live",
  "https://cast5.asurahosting.com/stream/jodel/stream.pls"
};
int stationCount = 1;
unsigned long lastStationSync = 0;
bool syncAttempted = false;
int selected = 0;
int volumePreviousState = 0;
int volumeMovement = 0;
bool screenReady = false;
bool changed = true;
unsigned long lastTransition = 0;
unsigned long lastStatusRefresh = 0;
int volumePercent = 25;  // Default only; restore the saved volume at startup.
bool radioOn = true;
bool radioMuted = false;
constexpr const char* RADIO_FIRMWARE_VERSION = "2026.11.08.1";
void applyRadioOutputVolume() { if (audioReady) audio.setVolume(radioMuted ? 0 : volumePercent); }
int stationPreviousState = 0;
int stationMovement = 0;
bool buttonRaw = false;
bool buttonStable = false;
bool longPressHandled = false;
unsigned long buttonChangedAt = 0;
unsigned long buttonPressedAt = 0;
#include "volume_settings.h"
#include "voice_prompts.h"
#include "wifi_portal.h"
#include "tft_power.h"
#include "reliability.h"
#include "station_art.h"
#include "battery_power.h"
#include "radio_features.h"
#include "station_sync.h"

void servicePowerButton() {
  unsigned long now = millis();
  bool pressed = digitalRead(18) == LOW;
  if (pressed != buttonRaw) {
    buttonRaw = pressed;
    buttonChangedAt = now;
  }
  if (now - buttonChangedAt >= 35 && buttonStable != buttonRaw) {
    buttonStable = buttonRaw;
    if (buttonStable) {
      buttonPressedAt = now;
      longPressHandled = false;
    } else if (!longPressHandled) {
      if (uiPage == 0) {
        radioOn = !radioOn;
        saveVolumeIfDue(true);
        savePlaybackStateIfDue(true);
        if (!radioOn) {
          if (portalActive) {
            wifiManager.stopConfigPortal();
            WiFi.mode(WIFI_STA);
            portalActive=false;
          }
          cancelVoicePrompts();
          if (audioReady) audio.stopSong();
          showRadioOff();
        } else {
          safeRecoveryMode = false;
          uiPaused=false;
          playbackRecovery.reset();
          showRadioOn();
          stationPending = true;
          lastPlaybackAttempt = millis() - 1000;
        }
        changed = true;
        Serial.println(radioOn ? "Radio ON" : "Radio OFF (standby)");
      }
    }
  }
  if (buttonStable && !longPressHandled && now - buttonPressedAt >= 5000) {
    longPressHandled = true;
    beginWifiPortal(true);
    changed = true;
  }
}

void loadSavedStations() {
  Preferences cache;
  if (!cache.begin("cf-stations", true)) return;
  String saved;
  size_t length=cache.getBytesLength("list-v2");
  if(length && length<=32768) {
    char* bytes=(char*)heap_caps_malloc(length+1,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    if(bytes) {
      if(cache.getBytes("list-v2",bytes,length)==length) {bytes[length]=0;saved=bytes;}
      heap_caps_free(bytes);
    }
  } else saved=cache.getString("list", ""); // Migrate the previous string cache.

  cache.end();
  if (saved.isEmpty() || saved.length() > 32768) return;
  JsonDocument document;
  if (deserializeJson(document, saved, DeserializationOption::NestingLimit(4)) || !document.is<JsonArray>()) return;
  // Validate the complete cached list before replacing the built-in fallback.
  int count = 0;
  for (JsonObject station : document.as<JsonArray>()) {
    const char* name = station["name"] | "";
    const char* url = station["url"] | "";
    if (!validStationFields(name, url)) return;
    if (++count > MAX_STATIONS) return;
  }
  count = 0;
  for (JsonObject station : document.as<JsonArray>()) {
    stations[count] = station["name"].as<String>();
    streamUrls[count] = station["url"].as<String>();
    stationLogoUrls[count] = station["logo_url"] | "";
    stationCodes[count] = station["listener_code"] | "";
    const char* revision=station["revision"] | "";
    stationRevisions[count]=validStationRevision(revision)?revision:"";
    ++count;
  }
  stationCount = count;
  if(!count){stations[0]="";streamUrls[0]="";stationLogoUrls[0]="";stationCodes[0]="";stationRevisions[0]="";}
  Serial.print("Restored saved stations: ");
  Serial.println(stationCount);
}

bool saveStations() {
  JsonDocument document;
  JsonArray list = document.to<JsonArray>();
  for (int i = 0; i < stationCount; ++i) {
    JsonObject station = list.add<JsonObject>();
    station["name"] = stations[i];
    station["url"] = streamUrls[i];
    station["logo_url"] = stationLogoUrls[i];
    station["listener_code"] = stationCodes[i];
    station["revision"] = stationRevisions[i];
  }
  String saved;
  if (document.overflowed() || measureJson(document) > 32768) return false;
  serializeJson(document, saved);
  if(saved.length()!=measureJson(document))return false;
  Preferences cache;
  if (!cache.begin("cf-stations", false)) return false;
  uint32_t hash=2166136261u;
  for(unsigned i=0;i<saved.length();++i)hash=(hash^uint8_t(saved[i]))*16777619u;
  if(cache.getBytesLength("list-v2")!=saved.length() || cache.getUInt("hash-v2",0)!=hash) {
    if(cache.putBytes("list-v2",saved.c_str(),saved.length())!=saved.length()) {cache.end();return false;}
    cache.putUInt("hash-v2",hash);
  }
  cache.end();return true;
}

// Runs on a worker so HTTPS station refresh does not block audio.loop().
void fetchStations(void*) {
  String code=stationCodeJob;bool adding=stationCodeAddingJob,manifest=stationManifestJob;
  String manifestCodes=stationManifestCodes;
  JsonDocument* result=new (std::nothrow) JsonDocument(&stationJsonAllocator);
  int status=0;
  if(result) do {
    if(WiFi.status()!=WL_CONNECTED || time(nullptr)<1700000000)break;
    DeadlineStationClient client;client.setCACert(WEBSITE_ROOT_CA);
    client.setHandshakeTimeout(5);client.setTimeout(1000);
    HTTPClient http;http.useHTTP10(true);http.setConnectTimeout(4000);http.setTimeout(4000);
    String endpoint=String(RADIO_SERVICE_ORIGIN)+"/api/device/";
    endpoint+=manifest?String("station-revisions?codes=")+manifestCodes:code.length()?String("stations/")+code:"default-station";
    if(!http.begin(client,endpoint))break;
    status=http.GET();
    if(status==HTTP_CODE_OK && http.getSize()<=(manifest?8192:4096)) {
      JsonDocument filter;
      if(manifest){filter["stations"][0]["listener_code"]=true;filter["stations"][0]["revision"]=true;}
      else{filter["name"]=true;filter["url"]=true;filter["logo_url"]=true;filter["listener_code"]=true;filter["revision"]=true;}
      BoundedStationStream body(http.getStream(),manifest?8192:4096);
      DeserializationError error=deserializeJson(*result,body,DeserializationOption::Filter(filter),DeserializationOption::NestingLimit(4));
      if(error || body.exhausted() || result->overflowed()) {result->clear();status=-1;}
    } else if(status==HTTP_CODE_OK)status=-1;
    http.end();
  } while(false);
  if(result) {(*result)["job_add"]=adding;(*result)["job_manifest"]=manifest;(*result)["requested_code"]=code;(*result)["http_status"]=status;}
  if(xQueueSend(stationUpdates,&result,0)!=pdTRUE)delete result;
  vTaskDelete(nullptr);
}

bool applyStationUpdate(JsonDocument& document) {
  bool adding=document["job_add"] | false;
  if(adding && stationAddCanceled)return false;
  int status=document["http_status"] | 0;
  if(status!=HTTP_CODE_OK) {
    if(adding) {
      codeLookupMessage=status==404?"Code not available.":status==429?"Wait, then try again.":"Connection failed. Retry.";
      uiDirty=true;
    }return false;
  }
  const char* name=document["name"] | "";
  const char* url=document["url"] | "";
  const char* code=document["listener_code"] | "";
  const char* requested=document["requested_code"] | "";
  const char* revision=document["revision"] | "";
  if(!validStationFields(name,url) || (*requested && (!validListenerCode(code) || strcmp(code,requested)))) {
    if(adding) {codeLookupMessage="Invalid station details.";uiDirty=true;}return false;
  }
  int oldCount=stationCount;
  int index=-1;
  for(int i=0;i<stationCount;++i)if((*code && stationCodes[i]==code) || (!*code && !stationCodes[i].length() && streamUrls[i]==url)){index=i;break;}
  if(index<0) {
    if(!adding)return false; // A late refresh cannot resurrect a removed station.
    if(stationCount>=MAX_STATIONS){codeLookupMessage="Station list is full.";uiDirty=true;return false;}
    index=stationCount++;
  }
  String oldName=stations[index],oldUrl=streamUrls[index],oldLogo=stationLogoUrls[index],oldCode=stationCodes[index],oldRevision=stationRevisions[index];
  bool streamChanged=streamUrls[index]!=url;
  stations[index]=name;streamUrls[index]=url;stationLogoUrls[index]=document["logo_url"] | "";
  stationCodes[index]=code;
  if(*revision && !validStationRevision(revision)) {
    stations[index]=oldName;streamUrls[index]=oldUrl;stationLogoUrls[index]=oldLogo;stationCodes[index]=oldCode;stationCount=oldCount;return false;
  }
  stationRevisions[index]=*revision?revision:oldRevision;
  if(!saveStations()) {
    stations[index]=oldName;streamUrls[index]=oldUrl;stationLogoUrls[index]=oldLogo;stationCodes[index]=oldCode;stationRevisions[index]=oldRevision;stationCount=oldCount;
    if(adding){codeLookupMessage="Could not save station.";uiDirty=true;}return false;
  }
  if(adding) {
    selected=index;uiPaused=false;safeRecoveryMode=false;uiPage=0;
    codeLookupMessage="Station added.";uiDirty=true;
  }
  if(adding || (index==selected && streamChanged)) {stationPending=true;playbackRecovery.reset();}
  changed=true;return true;
}

void startStationCodeWorker(const String& code,bool adding) {
  stationManifestJob=false;
  stationCodeJob=code;stationCodeAddingJob=adding;
  syncTaskStartedAt=millis();syncWorkerWarned=false;
  if(xTaskCreate(fetchStations,"station-code",8192,nullptr,1,&syncTaskHandle)!=pdPASS) {
    syncTaskHandle=nullptr;if(adding){codeLookupMessage="Please try again.";uiDirty=true;}else stationMetadataFinished(code,false);
  }
}
void startStationManifestWorker(const String& codes) {
  stationManifestJob=true;stationManifestCodes=codes;stationCodeJob="";stationCodeAddingJob=false;
  syncTaskStartedAt=millis();syncWorkerWarned=false;
  if(xTaskCreate(fetchStations,"station-manifest",8192,nullptr,1,&syncTaskHandle)!=pdPASS) {
    syncTaskHandle=nullptr;stationManifestFinished(false);
  }
}

bool sponsorWorkerBusy=false;
bool sponsorPopupVisible();
void drawSponsorPopup();
void tapSponsorPopup(int x,int y);
void openRadioLinkPage();
void drawHomeRadioLinkCode();
void drawRadioLinkPage();
void tapRadioLinkPage(int x,int y);
void openStationCodePage();
void drawStationCodePage();
void tapStationCodePage(int x,int y);
#include "touch_ui.h"
#include "settings_ui.h"
#include "station_code_ui.h"
#include "radio_link.h"
#include "radio_sponsors.h"

void setup() {
  initBatteryPower(); // Latch battery power before display/touch initialization.
  pinMode(LCD_Backlight_PIN,OUTPUT);digitalWrite(LCD_Backlight_PIN,LOW);
  Serial.begin(115200);
  startReliability();
  Audio::audio_info_callback = audioLog;
  loadVolumeSettings();
  loadSavedStations();
  loadPlaybackState();
  // Every power-up starts at home, even if the last session ended in standby.
  radioOn = true;
  uiPaused = false;
  stationPending = true;
  uiPage = 0;
  pinMode(43, INPUT_PULLUP);
  pinMode(44, INPUT_PULLUP);
  pinMode(18, INPUT_PULLUP);
  stationPreviousState = (digitalRead(43) << 1) | digitalRead(44);
  Backlight_Init();
  LCD_Init();
  Wire1.setTimeOut(50);
  radioScreen = new (std::nothrow) RadioCanvas();
  screenReady = radioScreen && screen.getBuffer() != nullptr;
  if (screenReady) screen.setTextWrap(false);
  if (!screenReady) Serial.println("Display allocation failed.");
  Serial.println("Internet radio starting.");
  loadClockSettings();
  loadRadioUiSettings();
  serviceBatteryLevel();
  stationUpdates = xQueueCreate(1, sizeof(JsonDocument*));
  initRadioLink();
  if (psramFound()) {
    audioReady = audio.setPinout(48, 38, 47);
    audio.setVolumeSteps(100);
    applyRadioOutputVolume();
    audio.forceMono(false);
    audio.setConnectionTimeout(3000, 5000);
  } else {
    Serial.println("Audio disabled: select Tools > PSRAM > OPI PSRAM, then upload again.");
  }
  if (radioOn && !safeRecoveryMode) queueVoicePrompt("/welcome.mp3");
  drawStation();
  if(screenReady) {LCD_WriteCommand(0x29);Set_Backlight(50);}
  startSavedWifi();
  if (!radioOn) showRadioOff();
}

void serviceStationKnob() {
  static const int8_t stationSteps[16] = {
    0, -1, 1, 0, 1, 0, 0, -1,
    -1, 0, 0, 1, 0, 1, -1, 0
  };
  int state = (digitalRead(43) << 1) | digitalRead(44);
  if (state == stationPreviousState) return;
  lastTransition = millis();
  if (uiPage != 0 || !radioOn || buttonRaw || buttonStable || (state ^ stationPreviousState) == 3) {
    stationMovement = 0;
  } else {
    stationMovement += stationSteps[(stationPreviousState << 2) | state];
  }
  stationPreviousState = state;
  if (stationMovement >= 4 || stationMovement <= -4) {
    int direction = stationMovement > 0 ? 1 : -1;
    stationMovement = 0;
    if (stationCount <= 0) return;
    selected = (selected + direction + stationCount) % stationCount;
    uiPaused=false;
    safeRecoveryMode = false;
    playbackRecovery.reset();
    stationPending = true;
    Serial.print("Selected: ");
    Serial.println(stations[selected]);
    changed = true;
  }
}

void loop() {
  serviceReliability();
  servicePowerButton();
  serviceBatteryPower();
  serviceWifiPortal();
  static bool wifiWasConnected = false;
  bool wifiNowConnected = WiFi.status() == WL_CONNECTED;
  if (wifiNowConnected != wifiWasConnected) {
    wifiWasConnected = wifiNowConnected;
    playbackRecovery.reset();
    stationPending = true;
    if (!wifiNowConnected && audioReady && !voiceBusy()) audio.stopSong();
  }
  serviceDisplaySleep();
  serviceStationKnob();
  serviceBatteryLevel();
  serviceTouchUi();
  if(!radioLinkTask&&!sponsorWorkerBusy)serviceStationArt();
  saveVolumeIfDue();
  savePlaybackStateIfDue();
  serviceVoicePrompts();
  if (audioReady && radioOn && !uiPaused && !portalActive && !voiceBusy()) audio.loop();
  JsonDocument* update = nullptr;
  if (stationUpdates && xQueueReceive(stationUpdates, &update, 0) == pdTRUE) {
    syncTaskHandle = nullptr;
    syncWorkerWarned = false;uiDirty=true;
    if (update) {
      if(homePopup==8){delete update;update=nullptr;codeLookupMessage="Station update cancelled.";}
    }
    if (update) {
      bool manifest=(*update)["job_manifest"]|false;
      if(manifest)stationManifestFinished(applyStationManifest(*update));
      else {
        String requested=(*update)["requested_code"]|"";
        bool adding=(*update)["job_add"]|false;
        bool saved=(!radioRemoteRunning || radioRemoteCommandAllowed()) && applyStationUpdate(*update);
        if(!adding)stationMetadataFinished(requested,saved);
        if(radioRemoteRunning)finishRadioRemoteCommand(saved);
      }
      delete update;
    } else {
      if(stationManifestJob)stationManifestFinished(false);
      else if(!stationCodeAddingJob)stationMetadataFinished(stationCodeJob,false);
      else{codeLookupMessage="Please try again.";uiDirty=true;}
      if(radioRemoteRunning)finishRadioRemoteCommand(false);
    }
  }
  updateMonthlyRadioUsage();
  if(!sponsorWorkerBusy)serviceRadioLink();
  serviceSponsors();
  if(stationAddRequested && millis()-stationAddRequestedAt>30000) {
    stationAddRequested=false;codeLookupMessage="Busy. Please retry.";uiDirty=true;
  }
  if(stationUpdates && !syncTaskHandle && !radioLinkTask && !sponsorWorkerBusy && !artWorkerBusy && WiFi.status()==WL_CONNECTED && ESP.getFreeHeap()>=60000) {
    if(stationAddRequested) {
      stationAddRequested=false;startStationCodeWorker(stationCodeRequest,true);
    } else if(stationCount>0 && !homePopup && !portalActive && uiPage==0 && !buttonStable && millis()-lastTransition>=2000)serviceSavedStationSync();
  }
  if (syncTaskHandle && !syncWorkerWarned && millis() - syncTaskStartedAt >= 30000) {
    // Do not force-delete a TLS worker holding library locks. Keep audio/UI alive.
    syncWorkerWarned = true;
    Serial.println("Station refresh delayed; keeping cached stations and avoiding duplicate workers.");
  }
  static String command;
  static bool commandOverflow = false;
  int serialBudget = 32;
  while (serialBudget-- > 0 && Serial.available()) {
    char c = Serial.read();
    if (c == '\r') continue;
    if (c == '\n') {
      if (commandOverflow) { command = ""; commandOverflow = false; continue; }
      if (command == "WIFI") {
        beginWifiPortal(true);
      }
      if (command == "STATUS") {
        Serial.printf("Uptime %lu s; heap %u; largest internal block %u; Wi-Fi %d; audio %s; recovery hold %s\n",
                      millis() / 1000, ESP.getFreeHeap(),
                      unsigned(heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT)),
                      int(WiFi.status()), audio.isRunning() ? "running" : "stopped",
                      safeRecoveryMode ? "yes" : "no");
      }
      if (command.startsWith("VOL ")) {
        String number = command.substring(4);
        bool valid = !number.isEmpty();
        for (unsigned int i = 0; i < number.length(); ++i) {
          if (number[i] < '0' || number[i] > '9') valid = false;
        }
        if (valid) {
          volumePercent = constrain(number.toInt(), 0, 100);
          if (audioReady) applyRadioOutputVolume();
          changed = true;
        }
      }
      command = "";
    } else if (command.length() < 16) command += c;
    else commandOverflow = true;
  }
  bool playbackAllowed = stationCount>0 && audioReady && radioOn && !safeRecoveryMode && !uiPaused && !portalActive && !voiceBusy() &&
                         !buttonStable && WiFi.status() == WL_CONNECTED;
  if (playbackAllowed && !stationPending && audio.isRunning()) {
    playbackRecovery.observe(millis(), audio.getAudioCurrentTime());
    if (playbackRecovery.stalled(millis())) {
      Serial.println("No decoded playback progress for 30 seconds; reconnecting station.");
      audio.stopSong();
      stationPending = true;
    }
  }
  if (playbackAllowed && millis() - lastTransition >= 500 &&
      ((stationPending && playbackRecovery.retryDue(millis())) ||
       (!audio.isRunning() && playbackRecovery.retryDue(millis())))) {
    lastPlaybackAttempt = millis();
    audio.stopSong();
    playingUrl = streamUrls[selected];
    bool accepted = audio.connecttohost(playingUrl.c_str());
    playbackRecovery.started(millis(), accepted);
    if (accepted) {
      // stopSong() mutes the output; restore it after the new source is opened.
      audio.setMute(false);
      applyRadioOutputVolume();
    }
    stationPending = false;
    Serial.println(accepted ? "Station connection started." : "Station connection failed; will retry.");
    stationPreviousState = (digitalRead(43) << 1) | digitalRead(44);
    stationMovement = 0;

    changed = true;
  }
  if (screenReady && changed && millis() - lastTransition >= 50) {
    drawStation();
    changed = false;
    lastStatusRefresh = millis();
  } else if (screenReady && millis() - lastStatusRefresh >= 1000 &&
             millis() - lastTransition >= 50) {
    drawStation();
    lastStatusRefresh = millis();
  }
  if (watchdogEnabled) esp_task_wdt_reset();
  delay(1);
}
