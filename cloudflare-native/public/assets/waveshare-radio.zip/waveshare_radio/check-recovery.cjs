const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync(__dirname+'/recovery_policy.h','utf8');
let code=source.split('struct PlaybackRecovery {')[1].split('\n};')[0]
 .replace(/uint32_t\(([^)]*)\)/g,'u32($1)')
 .replace(/\b(?:uint32_t|bool) (\w+) =/g,'var $1 =')
 .replace(/\b(?:void|bool) (\w+)\(/g,'function $1(')
 .replace(/\b(?:uint32_t|bool) (?=\w+[,\)])/g,'')
 .replace(/\) const \{/g,') {');
const ctx={u32:x=>x>>>0};vm.createContext(ctx);vm.runInContext(code,ctx);
assert(ctx.retryDue(0));ctx.started(100,false);assert(!ctx.retryDue(2099));assert(ctx.retryDue(2100));
let now=2100;
for(let i=0;i<12;i++){ctx.started(now,false);assert(ctx.retryDelay<=60000);now+=ctx.retryDelay;}
assert.equal(ctx.retryDelay,60000);
ctx.reset();ctx.started(100,true);assert(!ctx.stalled(30099));assert(ctx.stalled(30100));
ctx.observe(20000,1);assert(!ctx.stalled(40000));ctx.observe(40000,2);assert(!ctx.stalled(65000));
ctx.observe(65000,2);assert(ctx.stalled(70000),'running flag without decoded progress is a stall');
ctx.reset();ctx.started(0xfffffff0,true);assert(!ctx.retryDue(0x10));assert(ctx.retryDue(6000));assert(ctx.stalled(40000));
ctx.reset();assert(ctx.retryDue(1),'manual station selection must bypass old station backoff');

let reliability=fs.readFileSync(__dirname+'/reliability.h','utf8')
 .replace(/^#.*$/gm,'').replace('PlaybackRecovery playbackRecovery;','')
 .replace(/RTC_DATA_ATTR /g,'')
 .replace(/\b(?:bool|uint32_t|unsigned long|String|esp_reset_reason_t|esp_err_t) (\w+) =/g,'var $1 =')
 .replace(/String (\w+);/g,'var $1 = "";')
 .replace(/esp_task_wdt_config_t config = \{\};/g,'var config = {};')
 .replace(/Preferences (\w+);/g,'var $1 = new Preferences();')
 .replace(/void (\w+)\(/g,'function $1(').replace(/bool force = false/g,'force = false')
 .replace(/for \(int i =/g,'for (let i =').replace(/\bint\(reason\)/g,'Number(reason)')
 .replace(/\bnullptr\b/g,'null').replace(/&config/g,'config').replace(/\(var force = false\)/g,'(force = false)');
let heap=100000,largest=50000,restarts=0,reason=0,clock=100,config,flash={};
const env={radioOn:true,streamUrls:['a','b'],stationCount:2,selected:0,
 Preferences:function(){this.begin=()=>true;this.end=()=>{};this.getBool=(k,d)=>flash[k]??d;this.getString=(k,d)=>flash[k]??d;this.putBool=(k,v)=>{flash[k]=v;return 1};this.putString=(k,v)=>{flash[k]=v;return v.length+1}},
 millis:()=>clock,esp_reset_reason:()=>reason,esp_task_wdt_init:c=>{config=c;return 0},esp_task_wdt_reconfigure:()=>0,esp_task_wdt_status:()=>0,esp_task_wdt_add:()=>0,
 ESP:{getFreeHeap:()=>heap,restart:()=>restarts++},heap_caps_get_largest_free_block:()=>largest,
 MALLOC_CAP_INTERNAL:1,MALLOC_CAP_8BIT:2,ESP_OK:0,ESP_ERR_INVALID_STATE:1,
 ESP_RST_TASK_WDT:4,ESP_RST_INT_WDT:5,ESP_RST_WDT:6,ESP_RST_PANIC:7,Serial:{printf(){},println(){}}};
vm.createContext(env);vm.runInContext(reliability,env);
env.startReliability();assert(env.watchdogEnabled);assert.equal(config.timeout_ms,45000);assert(config.trigger_panic);
reason=4;env.startReliability();env.startReliability();assert(!env.safeRecoveryMode);env.startReliability();assert(env.safeRecoveryMode,'repeated crashing must stop automatic playback');
env.loadPlaybackState();env.radioOn=false;env.selected=1;env.savePlaybackStateIfDue();assert.deepEqual(flash,{});clock+=2001;env.savePlaybackStateIfDue();assert.deepEqual(flash,{on:false,station:'b'});
env.radioOn=true;env.selected=0;env.loadPlaybackState();assert(!env.radioOn&&env.selected===1,'restore standby and selected station');
heap=10000;clock=10000;env.serviceReliability();clock=35000;env.serviceReliability();assert.equal(restarts,0);heap=100000;clock=40000;env.serviceReliability();assert(!env.lowMemoryActive);
heap=10000;clock=45000;env.serviceReliability();clock=75001;env.serviceReliability();assert.equal(restarts,1);assert(env.recoveryRestartRequested);
console.log('PASS: retry backoff/cap, live-stream stalls, progressing silence, millis rollover, manual station override, watchdog configuration, repeated-crash hold, standby/station persistence and sustained/transient low-memory recovery.');
