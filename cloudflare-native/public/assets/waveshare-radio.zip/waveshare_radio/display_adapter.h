#pragma once
#include "Display_ST7789.h"
#include <esp_heap_caps.h>
class RadioCanvas : public GFXcanvas16 {
public:
  RadioCanvas() : GFXcanvas16(240, 320, false) {
    buffer = (uint16_t*)heap_caps_calloc(240*320, sizeof(uint16_t), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    buffer_owned = true;
    setRotation(3); // Landscape flipped 180 degrees for the printed enclosure.
  }
  void clearDisplay() { fillScreen(0x0865); }
  void display() { if (getBuffer()) LCD_addWindow(0, 0, 239, 319, getBuffer()); }
};
constexpr uint16_t UI_BG=0x0865, UI_WHITE=0xffff, UI_BLUE=0x247f,
                   UI_SKY=0x35ff, UI_PANEL=0x192b, UI_MUTED=0x9d39;
int uiPage = 0; // 0 radio, 1 networks, 2 keyboard
bool uiDirty = true;
bool uiPaused=false;
bool uiLocalWifiAttempt=false;
bool wifiNoticeSpoken=false;
