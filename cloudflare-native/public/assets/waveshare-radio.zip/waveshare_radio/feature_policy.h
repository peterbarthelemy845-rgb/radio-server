#pragma once
#include <stdint.h>
// Voltage is an estimate for a single 4.2 V Li-ion cell, not a fuel gauge.
int batteryEstimatePercent(int millivolts) {
  if(millivolts<2800 || millivolts>4350) return -1;
  const int volts[]={3200,3500,3650,3750,3850,4000,4200};
  const int levels[]={0,10,25,45,65,85,100};
  if(millivolts<=volts[0]) return 0;
  for(int i=1;i<7;++i) if(millivolts<=volts[i])
    return levels[i-1]+(millivolts-volts[i-1])*(levels[i]-levels[i-1])/(volts[i]-volts[i-1]);
  return 100;
}
int dragVolumePercent(int x) { return x<=53?0:x>=267?100:(x-53)*100/214; }
