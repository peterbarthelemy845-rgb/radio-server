const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync(__dirname+'/radio_sponsors.h','utf8');
function body(signature){let a=source.indexOf(signature);assert(a>=0);a=source.indexOf('{',a);let n=1,b=a+1;while(n){if(source[b]==='{')n++;if(source[b]==='}')n--;b++;}return source.slice(a+1,b-1);}
let audioRunning=true,voice=false,wifi=3,approval=false,closed=0;
const c={screenReady:true,displaySleeping:false,offNoticeActive:false,radioOn:true,radioMuted:false,stationCount:1,audioReady:true,uiPaused:false,safeRecoveryMode:false,stationPending:false,portalActive:false,
 voiceBusy:()=>voice,WiFi:{status:()=>wifi},WL_CONNECTED:3,audio:{isRunning:()=>audioRunning},uiPage:0,homePopup:0,onNoticeActive:false,radioApprovalPopupVisible:()=>approval,
 sponsorTracking:true,sponsorListeningSince:1000,sponsorNextAt:0,SPONSOR_FIRST_MS:600000,uint32_t:v=>v>>>0,int32_t:v=>v|0,closeSponsorPopup:()=>closed++,isalnum:v=>/^[a-z0-9]$/i.test(v)};
vm.createContext(c);
for(const [name,signature,args] of [['listening','bool sponsorPlaybackQualified(',''],['screen','bool sponsorScreenAvailable(',''],['elapsed','bool sponsorDelayElapsed(','now'],['tap','void tapSponsorPopup(','x,y']])vm.runInContext('function '+name+'('+args+'){'+body(signature)+'}',c);
assert(c.listening());for(const key of ['uiPaused','safeRecoveryMode','stationPending','portalActive','radioMuted']){c[key]=true;assert(!c.listening(),key);c[key]=false;}
c.radioOn=false;assert(!c.listening());c.radioOn=true;audioRunning=false;assert(!c.listening());audioRunning=true;voice=true;assert(!c.listening());voice=false;wifi=0;assert(!c.listening());wifi=3;
assert(c.screen());for(const key of ['displaySleeping','offNoticeActive','onNoticeActive']){c[key]=true;assert(!c.screen(),key);c[key]=false;}
c.uiPage=1;assert(!c.screen());c.uiPage=0;c.homePopup=6;assert(!c.screen());c.homePopup=0;approval=true;assert(!c.screen());approval=false;
assert(!c.elapsed(600999));assert(c.elapsed(601000));c.sponsorNextAt=2401000;assert(!c.elapsed(2400999));assert(c.elapsed(2401000));
c.sponsorListeningSince=0xfffffff0;c.sponsorNextAt=0;assert(c.elapsed((0xfffffff0+600000)>>>0),'listening timer survives millis rollover');
c.sponsorNextAt=1000;assert(!c.elapsed(0xfffffff0),'future cooldown survives rollover');
c.tap(100,100);assert.equal(closed,0);c.tap(280,55);assert.equal(closed,1);c.tap(280,215);assert.equal(closed,1,'volume touch is not close');
let path=body('bool safeSponsorPath(').replace('const String prefix=','const prefix=').replace(/\.length\(\)/g,'.length').replace('for(unsigned i=','for(let i=').replace('char c=','const c=').replace('(unsigned char)c','c');
vm.runInContext('function pathAllowed(path){'+path+'}',c);
assert(c.pathAllowed('/api/radio/ad/pixels?token=abc_DEF-123.abc'));for(const p of ['https://evil.example/a','/api/radio/ad/pixels?token=abc\r\nX:yes','/static/a.png','/api/radio/ad/pixels?token='])assert(!c.pathAllowed(p));
assert(source.includes('http.getSize()!=int(SPONSOR_BYTES)'));assert(source.includes('millis()-started<12000'));assert(source.includes('setCACert(WEBSITE_ROOT_CA)'));assert(!source.includes('setInsecure('));assert(source.includes('SPONSOR_SHOW_MS=8000'));assert(source.includes('SPONSOR_GAP_MS=1800000'));
const sketch=fs.readFileSync(__dirname+'/waveshare_radio.ino','utf8'),touch=fs.readFileSync(__dirname+'/touch_ui.h','utf8');
assert(sketch.includes('!sponsorWorkerBusy)serviceRadioLink()'));assert(sketch.includes('serviceSponsors();'));assert(touch.includes('y>=37 && y<193'));
console.log('PASS: sponsor listening/screen guards, 10-minute start, 30-minute cooldown and rollover, close target, untouched volume area, allowlisted media paths, bounded image/deadline, verified TLS and worker isolation.');
