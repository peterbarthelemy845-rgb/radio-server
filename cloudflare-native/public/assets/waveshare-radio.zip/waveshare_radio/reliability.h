#pragma once
#include <esp_task_wdt.h>
#include <esp_system.h>
#include <esp_heap_caps.h>
#include "recovery_policy.h"

PlaybackRecovery playbackRecovery;
bool watchdogEnabled = false;
bool safeRecoveryMode = false;
RTC_DATA_ATTR uint32_t consecutiveCrashBoots = 0;
RTC_DATA_ATTR bool recoveryRestartRequested = false;
unsigned long healthCheckedAt = 0;
unsigned long lowMemoryStartedAt = 0;
bool lowMemoryActive = false;
bool savedRadioOn = true;
String savedStationUrl;
bool observedRadioOn = true;
String observedStationUrl;
unsigned long playbackStateChangedAt = 0;

void startReliability() {
  esp_reset_reason_t reason = esp_reset_reason();
  if (recoveryRestartRequested || reason == ESP_RST_TASK_WDT ||
      reason == ESP_RST_INT_WDT || reason == ESP_RST_WDT || reason == ESP_RST_PANIC) {
    if (consecutiveCrashBoots < 10) ++consecutiveCrashBoots;
  } else consecutiveCrashBoots = 0;
  recoveryRestartRequested = false;
  safeRecoveryMode = consecutiveCrashBoots >= 3;
  esp_task_wdt_config_t config = {};
  config.timeout_ms = 45000;
  config.idle_core_mask = 0;
  config.trigger_panic = true;
  esp_err_t result = esp_task_wdt_init(&config);
  if (result == ESP_ERR_INVALID_STATE) result = esp_task_wdt_reconfigure(&config);
  if (result == ESP_OK) {
    result = esp_task_wdt_status(nullptr);
    if (result != ESP_OK) result = esp_task_wdt_add(nullptr);
    watchdogEnabled = result == ESP_OK;
  }
  Serial.printf("Boot reset reason: %d; watchdog: %s; recovery hold: %s\n",
                int(reason), watchdogEnabled ? "enabled" : "unavailable",
                safeRecoveryMode ? "yes" : "no");
}

void loadPlaybackState() {
  Preferences state;
  if (state.begin("radio-state", true)) {
    radioOn = state.getBool("on", true);
    String url = state.getString("station", "");
    state.end();
    for (int i = 0; i < stationCount; ++i) if (streamUrls[i] == url) { selected = i; break; }
  }
  savedRadioOn = observedRadioOn = radioOn;
  savedStationUrl = observedStationUrl = streamUrls[selected];
}

void savePlaybackStateIfDue(bool force = false) {
  if (observedRadioOn != radioOn || observedStationUrl != streamUrls[selected]) {
    observedRadioOn = radioOn;
    observedStationUrl = streamUrls[selected];
    playbackStateChangedAt = millis();
  }
  if (savedRadioOn == radioOn && savedStationUrl == streamUrls[selected]) return;
  if (!force && millis() - playbackStateChangedAt < 2000) return;
  Preferences state;
  if (!state.begin("radio-state", false)) { playbackStateChangedAt = millis(); return; }
  bool stored = state.putBool("on", radioOn) == 1;
  state.putString("station", streamUrls[selected]);
  stored = state.getString("station", "!missing!") == streamUrls[selected] && stored;
  state.end();
  if (stored) { savedRadioOn = radioOn; savedStationUrl = streamUrls[selected]; }
  else playbackStateChangedAt = millis();
}

void serviceReliability() {
  if (millis() - healthCheckedAt < 5000) return;
  healthCheckedAt = millis();
  if (millis() >= 300000) consecutiveCrashBoots = 0;
  bool low = ESP.getFreeHeap() < 16000 || heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT) < 4096;
  if (!low) { lowMemoryActive = false; return; }
  if (!lowMemoryActive) {
    lowMemoryActive = true;
    lowMemoryStartedAt = millis();
    Serial.println("Low memory; watching for recovery.");
  } else if (millis() - lowMemoryStartedAt >= 30000) {
    Serial.println("Memory has not recovered; restarting without erasing settings.");
    recoveryRestartRequested = true;
    ESP.restart();
  }
}
