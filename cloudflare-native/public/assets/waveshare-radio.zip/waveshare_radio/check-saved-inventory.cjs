const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync(__dirname+'/radio_link.h','utf8');
const signature='void snapshotRadioSavedStations(';let a=source.indexOf(signature);assert(a>=0);a=source.indexOf('{',a);let depth=1,b=a+1;
while(depth&&b<source.length){if(source[b]==='{')depth++;if(source[b]==='}')depth--;b++;}
const body=source.slice(a+1,b-1).replace('for(int i=','for(let i=').replace(/\.c_str\(\)/g,'');
const state={MAX_STATIONS:100,stationCount:0,stationCodes:[],validListenerCode:code=>/^\d{2,6}$/.test(code)};
vm.createContext(state);vm.runInContext('function snapshot(job){'+body+'}',state);
function capture(){const job={savedCodes:[],savedCodeCount:0,inventoryComplete:false};state.snapshot(job);return job;}
let job=capture();assert(job.inventoryComplete);assert.equal(job.savedCodeCount,0,'an empty list is a complete report');
state.stationCodes=['10','','123456','invalid'];state.stationCount=4;job=capture();assert(job.inventoryComplete);assert.deepEqual(job.savedCodes,['10','123456']);
state.stationCodes[0]='20';assert.equal(job.savedCodes[0],'10','worker snapshot is independent of subsequent UI changes');
state.stationCodes=Array.from({length:100},(_,i)=>String(10+i));state.stationCount=100;job=capture();assert(job.inventoryComplete);assert.equal(job.savedCodeCount,100);
for(const count of [-1,101]){state.stationCount=count;assert(!capture().inventoryComplete,'invalid bounds cannot become an empty authoritative report');}
assert(source.includes('if(job->mode==2 && job->inventoryComplete)'));
assert(source.includes('payload["saved_station_codes"].to<JsonArray>()'));
assert(source.includes('if(mode==2){snapshotRadioSavedStations(*job);'));
assert(source.indexOf('snapshotRadioSavedStations(*job)')<source.indexOf('xTaskCreate(radioLinkWorker'));
assert(source.includes('if(payload.overflowed())break;'),'allocation failure cannot submit a partial report');
assert(source.includes('serializeJson(payload,body)!=measureJson(payload)'));
console.log('PASS: complete saved station snapshots include empty/deleted lists, respect all 100 slots, capture before the network task, and guard partial payloads.');
