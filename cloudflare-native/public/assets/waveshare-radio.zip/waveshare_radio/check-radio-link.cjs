const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync(__dirname+'/radio_link.h','utf8');
function body(signature){let a=source.indexOf(signature);assert(a>=0);a=source.indexOf('{',a);let depth=1,b=a+1;while(depth&&b<source.length){if(source[b]==='{')depth++;if(source[b]==='}')depth--;b++;}return source.slice(a+1,b-1);}
const stored={};let now=1000;let canSaveReset=true;
const state={homePopup:6,radioAckId:"old-ack",radioAckStatus:"added",radioPendingCheck:"1234",radioStableCodeRegistered:true,radioOn:true,changed:false,radioPendingClaim:'pending-claim',radioPairDecision:'',radioLinkRequestedMode:0,radioLinkPollAt:100,radioLinkResetConfirm:false,radioLinkMessage:'',radioCodeResetAfter:0,radioLinkResetPending:false,radioRemoteId:'command',radioRemoteUntil:2000,millis:()=>now,int32_t:v=>v|0,uiPage:6,uiDirty:false,
 backToRadioHome:()=>{state.uiPage=0;state.homePopup=0;state.uiDirty=true},Preferences:class{begin(){return true}putULong(key,value){if(canSaveReset)stored[key]=value;return canSaveReset?4:0}putBool(key,value){if(canSaveReset)stored[key]=value;return canSaveReset?1:0}end(){}},rememberPhoneLinked(){}};
state.time=()=>1800000000;state.nullptr=null;state.uint32_t=v=>v;state.WL_CONNECTED=3;state.WiFi={status:()=>3};
vm.createContext(state);vm.runInContext("function radioCodeResetLocked(){"+body("bool radioCodeResetLocked(")+"}",state);
const translate=code=>code.replace(/\.length\(\)/g,'.length').replace('Preferences prefs;','const prefs=new Preferences();').replace('bool stored=false;','let stored=false;');
vm.runInContext('function requestRadioCodeReset(){'+translate(body('bool requestRadioCodeReset('))+'} function tap(x,y){'+body('void tapRadioLinkPage(')+'}',state);
state.tap(220,160);assert.equal(state.homePopup,0);assert.equal(state.radioPairDecision,'','Exit cannot approve a phone');
vm.runInContext('function radioApprovalPopupVisible(){'+body('bool radioApprovalPopupVisible(').replace(/\.length\(\)/g,'.length')+'} function popupTap(x,y){'+body('void tapRadioApprovalPopup(')+'}',state);
assert(state.radioApprovalPopupVisible());state.popupTap(5,20);state.popupTap(160,160);assert.equal(state.radioPairDecision,'','outside taps and the gap cannot approve');
state.popupTap(50,160);assert.equal(state.radioPairDecision,'approve');assert.equal(state.radioLinkRequestedMode,2);assert.equal(state.uiPage,0);assert(!state.radioApprovalPopupVisible());
state.popupTap(220,160);assert.equal(state.radioPairDecision,'approve','second taps cannot change an in-flight decision');state.radioPairDecision='';state.popupTap(220,160);assert.equal(state.radioPairDecision,'deny');
state.radioPendingClaim='';state.radioPairDecision='';state.radioLinkRequestedMode=0;state.homePopup=6;canSaveReset=false;state.tap(50,160);assert(!state.radioLinkResetPending,'failed intent storage cannot start a reset');
canSaveReset=true;state.tap(50,160);assert(state.radioLinkResetPending&&stored.unlink);assert.equal(state.radioLinkRequestedMode,3,'one Reset code action first revokes every phone');state.tap(220,160);assert.equal(state.homePopup,0);assert(state.radioLinkResetPending,'Exit cannot cancel a stored revocation');
assert(!source.includes('uiCenter("Phone connected"'));assert(source.includes('radioPairDecision="";backToRadioHome();'));
vm.runInContext('function allowed(){'+body('bool radioRemoteCommandAllowed(').replace(/\.length\(\)/g,'.length')+'}',state);
assert(!state.allowed(),'unlink blocks an already received command');state.radioLinkResetPending=false;assert(state.allowed());
now=2001;assert(!state.allowed(),'expired command cannot run after standby');
now=0xfffffff0;state.radioRemoteUntil=(now+1000)>>>0;assert(state.allowed());now=1100;assert(!state.allowed(),'expiry works across millis rollover');
let newCodeReady=false;state.prepareStableRadioCode=reset=>{assert(reset);return newCodeReady;};
vm.runInContext('function complete(){'+translate(body('bool completeRadioCodeReset('))+'}',state);state.radioLinkResetPending=true;
assert(!state.complete());assert(state.radioLinkResetPending&&stored.unlink,'generation failure preserves the durable revocation');newCodeReady=true;canSaveReset=false;assert(!state.complete());assert(state.radioLinkResetPending);canSaveReset=true;assert(state.complete());assert(!state.radioLinkResetPending&&!stored.unlink&&!state.radioStableCodeRegistered);assert.equal(state.radioAckId,'');
assert(source.includes('client.setCACert(WEBSITE_ROOT_CA)'));assert(!source.includes('setInsecure('));
assert(source.includes('WiFi.status()!=WL_CONNECTED'));
assert(source.includes('if(command==radioLastCommand)'),'redelivered requests must not duplicate saved stations');
const sketch=fs.readFileSync(__dirname+'/waveshare_radio.ino','utf8');
assert(sketch.includes('radioRemoteCommandAllowed()) && applyStationUpdate(*update)'));assert(sketch.includes('finishRadioRemoteCommand(saved)'));
assert(!fs.readFileSync(__dirname+'/station_code_ui.h','utf8').includes('registrationQR'));
const home={radioStableCodeRegistered:true,simpleHomeMode:false,radioOn:true,portalActive:false,uiPage:0,radioLinkResetPending:false,radioPendingClaim:'',radioPairDecision:'',radioRemoteId:'',radioLinkCodeAttemptAt:0,
 WL_CONNECTED:3,WiFi:{status:()=>3},time:()=>1800000000,nullptr:null,millis:()=>now,homeRadioLinkCodeLive:()=>false};
vm.createContext(home);vm.runInContext('function refresh(){'+body('bool shouldRefreshHomeLinkCode(').replace(/\.length\(\)/g,'.length')+'}',home);
assert(home.refresh(),'online home obtains a code without opening Link phone');home.homeRadioLinkCodeLive=()=>true;assert(!home.refresh(),'live code stays stable');home.homeRadioLinkCodeLive=()=>false;
home.simpleHomeMode=true;assert(home.refresh(),'Simple home refreshes its compact temporary code');home.uiPage=6;assert(home.refresh(),'Link phone still obtains a code');home.uiPage=0;home.simpleHomeMode=false;
home.radioPendingClaim='pending';assert(!home.refresh(),'rotation never cancels a known pending approval');home.radioPendingClaim='';
home.radioLinkResetPending=true;assert(!home.refresh());home.radioLinkResetPending=false;
home.radioOn=false;assert(!home.refresh());home.radioOn=true;home.WiFi.status=()=>0;assert(!home.refresh());home.WiFi.status=()=>3;
now=100000;home.radioLinkCodeAttemptAt=90000;assert(!home.refresh(),'failed requests back off');now=151000;assert(home.refresh());
home.radioLinkCodeAttemptAt=0;home.uiPage=2;assert(!home.refresh(),'Wi-Fi entry is not interrupted');
const drawing=body('void drawHomeRadioLinkCode(');assert(!drawing.includes('radioLinkSecret'));assert(drawing.includes('radioLinkPin.substring(0,4)'));
assert(fs.readFileSync(__dirname+'/touch_ui.h','utf8').includes('compactHomeLinkLabel();'));
assert(source.includes('payload["stable_pair_code"]=job->pin'));assert(source.includes('prefs.putString("pair_code",pin)'));assert(source.includes('pin==radioLinkPin && persistent'));
console.log('PASS: actual Allow/Deny, durable reset with automatic phone revocation, Back cannot approve, pending-add revocation, expiry/rollover, TLS verification, deduplication and acknowledgement after persistent save.');
console.log('PASS: saved home-code registration and stable code, approval/offline/standby guards, retry backoff, and home shows only the temporary code.');

let canSaveCode=true,randomByte=0,codeWrites=0;
const codeStore={};
const stable={radioLinkPin:'ZZZZZZZZ',radioStableCodeRegistered:true,radioLinkCodeAttemptAt:123,radioDeviceCodeDigits:4,char:v=>String.fromCharCode(v),WL_CONNECTED:3,WiFi:{status:()=>3},esp_random:()=>randomByte++,validRadioPairCode:v=>/^(?:[0-9]{4,10}|[A-HJ-NP-Z2-9]{8})$/.test(v),Preferences:class{begin(){return true}putString(k,v){codeWrites++;if(canSaveCode)codeStore[k]=v;return canSaveCode?v.length:0}end(){}}};
vm.createContext(stable);vm.runInContext('function prepare(reset=false){'+body('bool prepareStableRadioCode(').replace('String pin;','let pin="";').replace('for(int i=','for(let i=').replace(/'0'\+/g,'48+').replace('Preferences prefs;','const prefs=new Preferences();').replace('bool saved=','let saved=').replace(/\.length\(\)/g,'.length')+'}',stable);
assert(stable.prepare());assert.equal(codeWrites,0,'a saved code is reused, not rotated');
stable.WiFi.status=()=>0;assert(!stable.prepare(true));assert.equal(stable.radioLinkPin,'ZZZZZZZZ');stable.WiFi.status=()=>3;
assert(stable.prepare(true));assert(/^[0-9]{4}$/.test(stable.radioLinkPin));assert.equal(stable.radioLinkPin,codeStore.pair_code);assert(!stable.radioStableCodeRegistered,'a reset code must register online before replacing the server mapping');
assert(state.radioCodeResetLocked(),'completed reset remains locked during cooldown');state.radioCodeResetAfter=1800000001;assert(state.radioCodeResetLocked());state.time=()=>1800000061;assert(!state.radioCodeResetLocked());
const beforeFailure=stable.radioLinkPin;canSaveCode=false;assert(!stable.prepare(true));assert.equal(stable.radioLinkPin,beforeFailure,'failed storage keeps the old saved code');
console.log('PASS: saved radio codes do not rotate; explicit reset persists a replacement and failed/offline resets keep the original code.');

assert(body("String compactHomeLinkLabel(").includes('return "";'),"no unavailable-code placeholder");
