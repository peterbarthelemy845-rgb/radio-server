const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync(__dirname+'/touch_ui.h','utf8').replace(/\r\n/g,'\n');
const keyboard=source.match(/const char \*uiRows\w+\[\] = \{[^\n]+\};/g);
assert.equal(keyboard.length,4);
let chars=' ';
for(const declaration of keyboard) {
  for(const token of declaration.slice(declaration.indexOf('{')).match(/"(?:\\.|[^"\\])*"/g)) chars+=JSON.parse(token);
}
for(let i=32;i<127;++i) assert(chars.includes(String.fromCharCode(i)),'Missing keyboard character '+i);
let body=source.split('bool uiValidPassword(const String& password) {')[1].split('\n}\n')[0];
body=body.replace(/password\.isEmpty\(\)/g,'!password.length')
 .replace(/password\.length\(\)/g,'password.length')
 .replace('for(unsigned i=0;i<64;++i)','for(let i=0;i<64;++i)')
 .replace('isxdigit((unsigned char)password[i])','/^[0-9a-f]$/i.test(password[i])');
const ctx={};vm.createContext(ctx);vm.runInContext('function valid(password){'+body+'}',ctx);
assert(ctx.valid('')); assert(!ctx.valid('1234567')); assert(ctx.valid('12345678'));
assert(ctx.valid('A'.repeat(63))); assert(ctx.valid('abcdef0123456789'.repeat(4)));
assert(!ctx.valid('g'.repeat(64))); assert(!ctx.valid('a'.repeat(65)));
assert(ctx.valid('a B!@#$%'));
const state={wakeRadioDisplay(){},uiPage:0,uiDirty:false,uiError:'old',
 uiAwaitingConnection:true,wifiAttemptActive:false,portalState:'connected',
 uiNetworkOffset:4,uiScanRequested:false,portalShouldRetrySaved:true,
 uiLocalWifiAttempt:false,wifiStartupScanning:false,WiFi:{scanDelete(){},disconnect(){}}};
vm.createContext(state);
const openBody=source.split('void uiOpenWifi(bool userInitiated=true) {')[1].split('\n}\n')[0];
vm.runInContext('function open(userInitiated=true){'+openBody+'}',state);
state.open(false);assert.equal(state.uiPage,1);assert(state.uiScanRequested);
assert(!state.uiAwaitingConnection);assert.equal(state.portalState,'ready');
assert(state.portalShouldRetrySaved,'automatic outage setup must keep retrying saved Wi-Fi');
state.open(true);assert(!state.portalShouldRetrySaved,'explicit setup must not compete with user choice');
state.wifiAttemptActive=true;state.portalState='connecting';state.open(false);
assert.equal(state.portalState,'connecting');
console.log('PASS: all 95 printable keyboard characters; open/short/normal/symbol/63-character/64-hex passwords; automatic saved-Wi-Fi recovery versus explicit setup; reopening settings clears stale success.');
const wifiBody=source.split('void serviceTouchUi() {')[1].split('  if((uiPage==1 || uiPage==2) && wifiAttemptActive)')[0]
 .replace('  static uint32_t offlineSince=0;','');
let clock=100,status=0,prompts=0;
const home={offlineSince:0,WiFi:{status:()=>status},WL_CONNECTED:3,
 radioOn:true,wifiAttemptActive:true,wifiStartupScanning:false,wifiNoticeSpoken:false,
 millis:()=>clock,queueVoicePrompt:()=>prompts++,screenReady:true,
 portalActive:true,uiPortalWasActive:false,uiPage:0};
vm.createContext(home);vm.runInContext('function tick(){'+wifiBody+'}',home);
home.tick();clock=70000;home.tick();assert.equal(prompts,0,'do not interrupt saved-Wi-Fi attempts');
home.wifiAttemptActive=false;home.tick();clock=74999;home.tick();assert.equal(prompts,0);
clock=75000;home.tick();assert.equal(prompts,1);clock=95000;home.tick();assert.equal(prompts,1);
assert.equal(home.uiPage,0,'background portal must not navigate away from home');
status=3;home.tick();assert(!home.wifiNoticeSpoken);
status=0;clock=100000;home.tick();clock=105000;home.tick();assert.equal(prompts,2,'one reminder for a new outage');
home.radioOn=false;home.wifiNoticeSpoken=false;clock=200000;home.tick();assert.equal(prompts,2,'standby is quiet');
const sketch=fs.readFileSync(__dirname+'/waveshare_radio.ino','utf8').replace(/\r\n/g,'\n');
const boot=sketch.split('  loadPlaybackState();')[1].split('  pinMode(43,')[0];
home.radioOn=false;home.uiPage=2;vm.runInContext(boot,home);assert(home.radioOn);assert.equal(home.uiPage,0);
console.log('PASS: every boot opens home; saved connection attempts remain quiet; one spoken reminder per outage; background portal never opens setup automatically; standby remains quiet.');
const pages={uiNetworkOffset:0,uiNetworkCount:3,NETWORK_ROWS:3,uiDirty:false,max:Math.max};
vm.createContext(pages);
vm.runInContext(source.slice(source.indexOf('bool uiHasNextNetworks()'),source.indexOf('void uiStartScan()'))
 .replace('bool uiHasNextNetworks()','function uiHasNextNetworks()')
 .replace('void uiChangeNetworkPage(int direction)','function uiChangeNetworkPage(direction)'),pages);
assert(!pages.uiHasNextNetworks());pages.uiChangeNetworkPage(1);assert.equal(pages.uiNetworkOffset,0);
pages.uiNetworkCount=7;pages.uiChangeNetworkPage(1);assert.equal(pages.uiNetworkOffset,3);
pages.uiChangeNetworkPage(1);assert.equal(pages.uiNetworkOffset,6);assert(!pages.uiHasNextNetworks());
pages.uiChangeNetworkPage(1);assert.equal(pages.uiNetworkOffset,6);
for(let i=0;i<4;i++)pages.uiChangeNetworkPage(-1);assert.equal(pages.uiNetworkOffset,0);
const power=fs.readFileSync(__dirname+'/battery_power.h','utf8').replace(/\r\n/g,'\n');
const keys={uiEditingSsid:false,uiSsid:'Home',uiPassword:'abc',uiSymbols:false,uiUpper:false,uiSymbolPage:0,uiError:'old',portalState:'failed',uiDirty:false};
vm.createContext(keys);
const control=source.split('void uiKeyboardControl(int key) {')[1].split('\n}\n')[0]
 .replace('String& value=','let value=').replace(/value.length\(\)/g,'value.length')
 .replace('unsigned(uiEditingSsid?32:64)','(uiEditingSsid?32:64)')
 .replace('value.remove(value.length-1)','value=value.slice(0,-1)');
vm.runInContext('function key(key){'+control+';if(uiEditingSsid)uiSsid=value;else uiPassword=value;}',keys);
keys.key(3);assert.equal(keys.uiPassword,'ab');assert.equal(keys.portalState,'ready');
keys.uiEditingSsid=true;keys.key(3);assert.equal(keys.uiSsid,'Hom');
keys.uiSsid='';keys.key(3);assert.equal(keys.uiSsid,'');keys.key(2);assert.equal(keys.uiSsid,' ');
keys.uiSsid='a'.repeat(32);keys.key(2);assert.equal(keys.uiSsid.length,32);
keys.uiEditingSsid=false;keys.uiPassword='a'.repeat(64);keys.key(2);assert.equal(keys.uiPassword.length,64);
keys.key(0);assert(keys.uiUpper);keys.key(1);assert(keys.uiSymbols);keys.key(1);assert.equal(keys.uiSymbolPage,true);
keys.key(0);assert(!keys.uiSymbols);
console.log('PASS: actual keyboard Backspace edits name/password, handles empty fields, limits spaces, switches capitals/symbols and clears failure status.');
let pressed=true,powerClock=0,cuts=0;
const battery={batteryKeyArmed:false,batteryKeyHeld:false,batteryShutdownHandled:false,batteryKeyStarted:0,
 digitalRead:()=>pressed?0:1,LOW:0,HIGH:1,OUTPUT:1,INPUT:0,pinMode(){},digitalWrite:(pin,value)=>{if(pin===7&&value===0)cuts++;},
 millis:()=>powerClock,radioOn:true,saveVolumeIfDue(){},savePlaybackStateIfDue(){},cancelVoicePrompts(){},audioReady:false,
 portalActive:false,uiPage:0,showRadioOff(){},Set_Backlight(){},displaySleeping:false,offNoticeActive:false};
vm.createContext(battery);
let tick=power.split('void serviceBatteryPower() {')[1].split('\n}\n')[0].replace('bool pressed=','let pressed=');
vm.runInContext('function tick(){'+tick+'}',battery);
battery.tick();powerClock=5000;battery.tick();assert.equal(cuts,0,'boot-held key must not shut down');
pressed=false;battery.tick();pressed=true;battery.tick();powerClock=6999;battery.tick();assert.equal(cuts,0);
powerClock=7000;battery.tick();assert.equal(cuts,1);battery.tick();assert.equal(cuts,1);
assert(!battery.radioOn);assert(battery.displaySleeping);
console.log('PASS: network pagination stops at both ends; battery boot press is ignored until release; two-second hold cuts power once and sleeps display.');
const networks={uiNetworks:[],uiNetworkCount:0,MAX_UI_NETWORKS:64};
vm.createContext(networks);
const remember=source.split('void uiRememberNetwork(const String& name,bool open) {')[1].split('\n}\n')[0]
 .replace('name.isEmpty()','!name.length').replace('for(int j=','for(let j=')
 .replace('={name,open}','={name,open}');
vm.runInContext('function remember(name,open){'+remember+'}',networks);
networks.remember('Cafe free',true);networks.remember('Phone hotspot',false);
networks.remember('Cafe free',true);assert.equal(networks.uiNetworkCount,2);
networks.remember('Cafe free',false);assert.equal(networks.uiNetworkCount,3,'keep different security modes for same SSID');
networks.remember('',true);networks.remember('Radio-Setup',true);assert.equal(networks.uiNetworkCount,3);
for(let i=0;i<100;i++)networks.remember('network '+i,i%2===0);
assert.equal(networks.uiNetworkCount,64);assert(networks.uiNetworks[0].open);
console.log('PASS: scan merge retains open networks and hotspots, deduplicates across passes, preserves security variants and bounds results at 64.');
