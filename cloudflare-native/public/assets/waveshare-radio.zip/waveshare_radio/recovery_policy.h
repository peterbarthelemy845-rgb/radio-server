#pragma once
#include <stdint.h>

// Pure scheduling policy: unsigned elapsed times also work across millis rollover.
struct PlaybackRecovery {
  uint32_t attemptedAt = 0;
  uint32_t progressedAt = 0;
  uint32_t position = 0;
  uint32_t retryDelay = 1000;
  bool attempted = false;
  bool makingProgress = false;

  void reset() {
    attempted = false;
    makingProgress = false;
    retryDelay = 1000;
  }
  void started(uint32_t now, bool accepted) {
    attempted = true;
    attemptedAt = now;
    progressedAt = now;
    position = 0;
    makingProgress = false;
    if (accepted) retryDelay = 5000;
    else retryDelay = retryDelay < 30000 ? retryDelay * 2 : 60000;
  }
  void observe(uint32_t now, uint32_t currentPosition) {
    if (currentPosition != position) {
      position = currentPosition;
      progressedAt = now;
      makingProgress = true;
      retryDelay = 5000;
    }
  }
  bool stalled(uint32_t now) const {
    return attempted && uint32_t(now - progressedAt) >= 30000;
  }
  bool retryDue(uint32_t now) const {
    return !attempted || uint32_t(now - attemptedAt) >= retryDelay;
  }
};
