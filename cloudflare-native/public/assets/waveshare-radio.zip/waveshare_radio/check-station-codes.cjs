const fs=require('fs'),vm=require('vm'),assert=require('assert');
const read=n=>fs.readFileSync(__dirname+'/'+n,'utf8').replace(/\r\n/g,'\n');
function body(src,sig){let a=src.indexOf(sig);assert(a>=0,sig);a=src.indexOf('{',a);let n=1,b=a+1;for(;n;b++){if(src[b]==='{')n++;if(src[b]==='}')n--;}return src.slice(a+1,b-1);}
const bound=read('bounded_station_stream.h'),sketch=read('waveshare_radio.ino');
const ctx={strlen:s=>s.length};vm.createContext(ctx);
vm.runInContext('function validListenerCode(code){'+body(bound,'bool validListenerCode(').replace('for(int i=','for(let i=')+'}',ctx);
assert(ctx.validListenerCode('123456'));assert(ctx.validListenerCode('000001'));for(const code of ['10','99','100','12345'])assert(ctx.validListenerCode(code));
for(const bad of ['',null,'1','1234567','12345a','１２３４５６','12 456'])assert(!ctx.validListenerCode(bad));
const state={stationCount:1,MAX_STATIONS:3,stations:['Default','',''],streamUrls:['https://default.test/live','',''],
 stationLogoUrls:['','',''],stationCodes:['','',''],stationRevisions:['','',''],validStationRevision:revision=>/^[0-9]{1,20}$/.test(revision),stationAddCanceled:false,uiDirty:false,selected:0,
 uiPaused:true,safeRecoveryMode:false,uiPage:5,stationPending:false,codeLookupMessage:'',changed:false,
 HTTP_CODE_OK:200,validListenerCode:ctx.validListenerCode,validStationFields:(n,u)=>n.length>0&&n.length<=96&&/^https?:\/\//.test(u),
 strcmp:(a,b)=>a===b?0:1,playbackRecovery:{reset(){}},saveStations:()=>true};
vm.createContext(state);
let apply=body(sketch,'bool applyStationUpdate(')
 .replace(/document\["(\w+)"\] \| (false|0|"")/g,'(document["$1"] ?? $2)')
 .replace(/\b(?:bool|int|String) (\w+)=/g,'let $1=')
 .replace(/const char\* (\w+)=/g,'const $1=').replace(/for\(int /g,'for(let ')
 .replace(/\*requested/g,'requested.length').replace(/\*code/g,'code.length').replace(/\*revision/g,'revision.length').replace(/\.length\(\)/g,'.length');
vm.runInContext('function apply(document){'+apply+'}',state);
const station={name:'New station',url:'https://radio.test/live',logo_url:'/static/logo.png',listener_code:'123456',requested_code:'123456',job_add:true,http_status:200};
assert(state.apply(station));assert.equal(state.stationCount,2);assert.equal(state.selected,1);assert(!state.uiPaused);assert.equal(state.uiPage,0);
assert(state.apply(station));assert.equal(state.stationCount,2,'duplicate code must not duplicate entry');
assert(state.apply({...station,url:'https://radio.test/new',job_add:false}));assert.equal(state.streamUrls[1],'https://radio.test/new');
assert(!state.apply({...station,listener_code:'654321'}));assert.equal(state.stationCount,2,'mismatched API code rejected');
assert(!state.apply({...station,http_status:404}));assert.equal(state.stationCount,2,'bad code must preserve installed stations');
state.stationAddCanceled=true;assert(!state.apply({...station,listener_code:'234567',requested_code:'234567',url:'https://other.test/live'}));
state.stationAddCanceled=false;state.saveStations=()=>false;
assert(!state.apply({...station,listener_code:'234567',requested_code:'234567',url:'https://other.test/live'}));
assert.equal(state.stationCount,2);assert.equal(state.streamUrls[1],'https://radio.test/new');
assert(!sketch.includes('https://www.radiolavoixdivine.com/api/stations'),'device must not download whole catalog');
assert(sketch.includes('station["listener_code"] = stationCodes[i]'),'codes must be saved with installed list');
console.log('PASS: 2-6 ASCII digits; actual station merge/deduplication, code integrity, bad-code/cancel/storage rollback, saved codes and metadata-only API.');
let connected=true,validClock=true;
const keypad={enteredStationCode:'',stationAddRequested:false,stationAddCanceled:false,uiPage:5,uiDirty:false,changed:false,
 stationCodeRequest:'',stationAddRequestedAt:0,codeLookupMessage:'',codeLookupBusy:()=>false,validListenerCode:ctx.validListenerCode,
 backToRadioHome:()=>{keypad.uiPage=0;keypad.uiDirty=true},WiFi:{status:()=>connected?3:0},WL_CONNECTED:3,time:()=>validClock?1800000000:0,nullptr:null,millis:()=>100};
let tap=body(read('station_code_ui.h'),'void tapStationCodePage(')
 .replace(/enteredStationCode.length\(\)/g,'enteredStationCode.length')
 .replace('enteredStationCode.c_str()','enteredStationCode')
 .replace("char('1'+key)",'String.fromCharCode(49+key)')
 .replace('enteredStationCode.remove(enteredStationCode.length-1)','enteredStationCode=enteredStationCode.slice(0,-1)')
 .replace('int col=(x-8)/103,row=(y-38)/38,key=row*3+col;','let col=Math.floor((x-8)/103),row=Math.floor((y-38)/38),key=row*3+col;');
vm.createContext(keypad);vm.runInContext('function tap(x,y){'+tap+'}',keypad);
for(let i=0;i<8;i++)keypad.tap(50,55);assert.equal(keypad.enteredStationCode,'111111');
keypad.tap(50,166);assert.equal(keypad.enteredStationCode,'11111');
keypad.tap(260,166);assert.equal(keypad.enteredStationCode,'');
keypad.tap(160,166);assert.equal(keypad.enteredStationCode,'0');
keypad.tap(108,55);keypad.tap(50,75);assert.equal(keypad.enteredStationCode,'0','key gaps do not enter digits');
keypad.tap(220,210);assert(!keypad.stationAddRequested,'short code cannot start lookup');
keypad.enteredStationCode='123456';connected=false;keypad.tap(220,210);assert(!keypad.stationAddRequested);
connected=true;validClock=false;keypad.tap(220,210);assert(!keypad.stationAddRequested);
validClock=true;keypad.tap(220,210);assert(keypad.stationAddRequested);assert.equal(keypad.stationCodeRequest,'123456');
keypad.tap(30,210);assert(!keypad.stationAddRequested);assert(keypad.stationAddCanceled);assert.equal(keypad.uiPage,0);
keypad.enteredStationCode='10';keypad.uiPage=5;keypad.tap(220,210);assert(keypad.stationAddRequested);assert.equal(keypad.stationCodeRequest,'10');
console.log('PASS: actual keypad caps at six, supports DEL/C/zero, rejects short/offline/unsynced requests, submits code and cancels with Back.');
if(process.argv[2]) {
 const fixture=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
 state.saveStations=()=>true;state.MAX_STATIONS=100;
 assert(state.apply({...fixture,requested_code:fixture.listener_code,job_add:true,http_status:200}));
 assert.equal(state.stations[state.selected],fixture.name);
 assert.equal(state.streamUrls[state.selected],fixture.url);
 console.log('PASS: actual Flask lookup response is accepted by the firmware station-merge function.');
}
