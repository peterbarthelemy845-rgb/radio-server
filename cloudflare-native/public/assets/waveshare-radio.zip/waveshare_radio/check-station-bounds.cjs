const fs=require('fs'),vm=require('vm'),assert=require('assert');
const complete=fs.readFileSync(__dirname+'/bounded_station_stream.h','utf8');
const source=complete.slice(complete.indexOf('class BoundedStationStream'));
function body(signature){let start=source.indexOf(signature);assert(start>=0,signature);start=source.indexOf('{',start);let depth=1,end=start+1;for(;depth;end++){if(source[end]==='{')depth++;if(source[end]==='}')depth--;}return source.slice(start+1,end-1);}
let now=100,bytes=[],delays=0;
const ctx={remaining_:32768,started_:100,millis:()=>now,delay:n=>{now+=n;delays++;},input_:{available:()=>bytes.length,read:()=>bytes.length?bytes.shift():-1,peek:()=>bytes.length?bytes[0]:-1},strlen:s=>s.length,strncmp:(s,p,n)=>s.slice(0,n)===p.slice(0,n)?0:1};
vm.createContext(ctx);
vm.runInContext('function exhausted(){'+body('bool exhausted() const')+'}\nfunction read(){'+body('int read() override').replace('int value =','let value =')+'}\nfunction peek(){'+body('int peek() override')+'}\nfunction validStationFields(name,url){'+body('bool validStationFields(').replace(/!\*(name|url)/g,'!$1.length')+'}',ctx);
assert.equal(ctx.read(),-1);assert.equal(delays,1);bytes=[65,66];assert.equal(ctx.peek(),65);assert.equal(ctx.remaining_,32768);assert.equal(ctx.read(),65);assert.equal(ctx.remaining_,32767);
ctx.remaining_=1;assert.equal(ctx.read(),66);bytes=[67];assert.equal(ctx.read(),-1);assert(ctx.exhausted());
ctx.remaining_=32768;ctx.started_=100;now=10100;assert(ctx.exhausted());assert.equal(ctx.read(),-1,'response deadline beats endless slow data');
assert(ctx.validStationFields('Radio','https://example.com/live'));assert(!ctx.validStationFields('','http://x'));assert(!ctx.validStationFields('X'.repeat(97),'http://x'));assert(!ctx.validStationFields('Radio','https://'+ 'x'.repeat(1024)));assert(!ctx.validStationFields('Radio','file:///local'));
console.log('PASS: station response byte cap, total deadline, nonblocking empty reads, peek accounting, name/URL bounds and allowed protocols.');
