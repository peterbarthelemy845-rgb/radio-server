#pragma once
// Waveshare V2 official PWR_Key: GPIO7 HIGH keeps battery supply enabled;
// GPIO6 reads the active-low BAT PWR key. USB power cannot be cut by this latch.
bool batteryKeyArmed=false, batteryKeyHeld=false, batteryShutdownHandled=false;
uint32_t batteryKeyStarted=0;
void initBatteryPower() {
  pinMode(7,OUTPUT);
  digitalWrite(7,HIGH);
  pinMode(6,INPUT);
}
void serviceBatteryPower() {
  bool pressed=digitalRead(6)==LOW;
  // The button may still be held from battery startup; wait for its release.
  if(!batteryKeyArmed) { if(!pressed) batteryKeyArmed=true; return; }
  if(!pressed) { batteryKeyHeld=false; batteryShutdownHandled=false; return; }
  if(!batteryKeyHeld) { batteryKeyHeld=true; batteryKeyStarted=millis(); }
  if(!batteryShutdownHandled && millis()-batteryKeyStarted>=2000) {
    batteryShutdownHandled=true;
    radioOn=false; saveVolumeIfDue(true); savePlaybackStateIfDue(true);
    cancelVoicePrompts(); if(audioReady) audio.stopSong();
    if(portalActive) { wifiManager.stopConfigPortal(); portalActive=false; }
    uiPage=0; showRadioOff();
    Set_Backlight(0); displaySleeping=true; offNoticeActive=false;
    digitalWrite(7,LOW);
  }
}
